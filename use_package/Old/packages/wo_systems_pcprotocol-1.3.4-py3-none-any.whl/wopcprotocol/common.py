"""Common definitions to be used by multiple modules of the package."""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from math import isclose
from typing import TYPE_CHECKING, ClassVar, Generic, TypeVar

if TYPE_CHECKING:
    from collections.abc import Iterator

    from typing_extensions import Self


T = TypeVar("T", bool, int, float)


@dataclass(frozen=True, kw_only=True)
class CommandResponse:
    """Response to a command sent to the electronics.

    Args:
        ack: True if the response is acknowledged, False otherwise
        command_id: ID of the command
        target: target of the command
        payload: payload of the response
    """

    ack: bool
    command_id: int
    target: int
    payload: bytes


@dataclass(frozen=True, kw_only=True)
class FirmwareVersion:
    """Represents the version of the firmware running on a controller.

    Args:
        major: major version number
        minor: minor version number
        patch: patch version number
        build_number: build number
        build_timestamp: timestamp of the build
        git_commit: git commit hash of the build
    """

    major: int
    minor: int
    patch: int
    build_number: int
    build_timestamp: str
    git_commit: str

    def __str__(self) -> str:
        return f"v{self.major}.{self.minor}.{self.patch}.{self.build_number}"


@dataclass(frozen=True)
class HardwareVersion:
    """Represents the version of the hardware.

    Args:
        major: major version number
        minor: minor version number
        serial_number: serial number of the hardware
    """

    major: int
    minor: int
    serial_number: bytes

    def __str__(self) -> str:
        try:
            sn = self.serial_number.decode("utf-8")
        except UnicodeDecodeError:
            sn = self.serial_number.hex()
        return f"v{self.major}.{self.minor}, serial_number: {sn}"


class Side(IntEnum):
    """Identifier for the side of a projector controller."""

    LEFT = 0
    """Left side"""
    RIGHT = 1
    """Right side"""

    @classmethod
    def from_string(cls, value: str) -> Side:
        """Convert a string to a `Side` enum.

        Args:
            value: case-insensitive string representation of the side. This could be either "L" or "LEFT" for the left side, or "R" or "RIGHT" for the right side

        Returns:
            `Side` enum
        """  # noqa: E501
        value = value.strip().upper()
        if value in ("L", "LEFT"):
            return cls.LEFT
        if value in ("R", "RIGHT"):
            return cls.RIGHT
        raise ValueError(f"unknown side {value}")


@dataclass(kw_only=True)
class OrientAlign:
    """Represents the orientation and alignment of a projector.

    Args:
        long_axis_flip: True if the long axis of the projector is flipped
        short_axis_flip: True if the short axis of the projector is flipped
        long_axis_shift: number of pixels to shift along the long axis
        short_axis_shift: number of pixels to shift along the short axis
    """

    long_axis_flip: bool
    short_axis_flip: bool
    long_axis_shift: int
    short_axis_shift: int

    MIN_SHIFT: ClassVar[int] = -128
    MAX_SHIFT: ClassVar[int] = 127

    def __post_init__(self) -> None:
        self._check_axis_shift_is_in_range(self.long_axis_shift)
        self._check_axis_shift_is_in_range(self.short_axis_shift)

    def _check_axis_shift_is_in_range(self, axis: int) -> None:
        if axis < self.MIN_SHIFT or axis > self.MAX_SHIFT:
            raise ValueError(f"axis_shift must be >= {self.MIN_SHIFT} and <= {self.MAX_SHIFT}")


class LedTuple(Generic[T]):
    """Generic container for a property of a tuple of LEDs.

    This is subclassed by objects representing concrete properties (e.g. brightness, current, voltage, etc.).

    Args:
        red: property of the red LED
        green: property of the green LED
        blue: property of the blue LED
        green2: property of the second green LED

    Note:
        All properties are optional and set to the class default if not provided.

    Warning:
        This class is not meant to be instantiated directly. Use one of the subclasses instead.

    Info:
        This class supports subscripting as it implements [`__getitem__`](https://docs.python.org/3/reference/datamodel.html#object.__getitem__), [`__setitem__`](https://docs.python.org/3/reference/datamodel.html#object.__setitem__), and [`__len__`](https://docs.python.org/3/reference/datamodel.html#object.__len__).
    """  # noqa: E501

    _DEFAULT_VALUE: T
    SIZE = 4
    """Number of LEDs in the tuple"""

    def __init__(
        self, red: T | None = None, green: T | None = None, blue: T | None = None, green2: T | None = None
    ) -> None:
        # Assign default values if none is provided
        self.red: T = self._DEFAULT_VALUE if red is None else red
        self.green: T = self._DEFAULT_VALUE if green is None else green
        self.blue: T = self._DEFAULT_VALUE if blue is None else blue
        self.green2: T = self._DEFAULT_VALUE if green2 is None else green2
        if hasattr(self, "__post_init__"):
            self.__post_init__()

    def __len__(self) -> int:
        return self.SIZE

    def __getitem__(self, index: int) -> T:
        if index == 0:
            return self.red
        if index == 1:
            return self.green
        if index == 2:
            return self.blue
        if index == 3:
            return self.green2
        raise IndexError("index out of range")

    def __setitem__(self, index: int, value: T) -> None:
        if index < 0 or index >= self.SIZE:
            raise IndexError("index out of range")
        if index == 0:
            self.red = value
        if index == 1:
            self.green = value
        if index == 2:
            self.blue = value
        if index == 3:
            self.green2 = value

    def __iter__(self) -> Iterator[T]:
        return iter([self.red, self.green, self.blue, self.green2])

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, self.__class__):
            raise TypeError(f"cannot compare {type(self)} with {type(other)}")
        return (
            self.red == other.red
            and self.green == other.green
            and self.blue == other.blue
            and self.green2 == other.green2
        )

    @classmethod
    def all(cls, value: T) -> Self:
        """Utility method to create a LedTuple with the same value for all LEDs.

        Args:
            value: value of the property

        Returns:
            `LedTuple` object with the same value for all LEDs
        """
        return cls(*[value] * cls.SIZE)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(red={self.red}, green={self.green}, blue={self.blue}, green2={self.green2})"


class LedState(LedTuple[bool]):
    """Represent the state of a tuple of LEDs.

    Note:
        As the properties are optional, the user can create a `LedState` object with only the LEDs that are relevant.
        E.g. `LedState(red=True)` will create a `LedState` object with only the red LED on.

    Info:
        The objects of this class support the bitwise operators `&`, `|`, and `~`.
        Moreover, evaluating an object as a boolean will return True if any of the LEDs is on.
    """

    _DEFAULT_VALUE = False

    @classmethod
    def on(cls) -> Self:
        """Utility method to create a LedState with all LEDs on.

        Returns:
            `LedState` object with all LEDs on
        """
        return cls.all(True)

    @classmethod
    def off(cls) -> Self:
        """Utility method to create a LedState with all LEDs off.

        Returns:
            `LedState` object with all LEDs off
        """
        return cls.all(False)

    def __bool__(self) -> bool:
        return any(list(self))

    def __and__(self, other: Self) -> Self:
        return self.__class__(*[a and b for a, b in zip(list(self), list(other), strict=False)])

    def __or__(self, other: Self) -> Self:
        return self.__class__(*[a or b for a, b in zip(list(self), list(other), strict=False)])

    def __invert__(self) -> Self:
        return self.__class__(*[not a for a in list(self)])


class LedBrightness(LedTuple[int]):
    """Brightness values for a tuple of LEDs. The values typically represent the register of an LED driver chip.

    Note:
        The objects of this class support the multiplication and division operators with a float
        to scale the brightness values. E.g. `LedBrightness(10, 20, 30) * 0.5` will return `LedBrightness(5, 10, 15)`.
    """

    _DEFAULT_VALUE = 0

    def __mul__(self, other: float) -> Self:
        return self.__class__(*[int(v * other) for v in list(self)])

    def __rmul__(self, other: float) -> Self:
        return self.__mul__(other)

    def __div__(self, other: float) -> Self:
        return self.__class__(*[int(v / other) for v in list(self)])

    def __truediv__(self, other: float) -> Self:
        return self.__div__(other)


class LedDutyCycle(LedTuple[float]):
    """Duty cycle of the PWM signals for a tuple of LEDs in percentage."""

    _DEFAULT_VALUE = 0.0
    _MAX_VALUE = 100.0

    def __post_init__(self) -> None:
        for v in list(self):
            if v < 0.0 or v > self._MAX_VALUE:
                raise ValueError("duty cycle must be >= 0.0 and <= 100.0")


@dataclass(frozen=True)
class ElectricalUnit:
    """Base class for electrical units.

    Args:
        name: name of the unit
        multiplier: multiplier to convert the unit to the base unit
    """

    name: str
    multiplier: float

    def __post_init__(self) -> None:
        if self.multiplier <= 0.0:
            raise ValueError("multiplier must be > 0.0")


class CurrentUnit:
    """Measurement unit for current."""

    A = ElectricalUnit("A", 1.0)
    """Ampere"""
    mA = ElectricalUnit("mA", 1 / 1000.0)  # noqa: N815
    """milliAmpere"""


class VoltageUnit:
    """Measurement unit for voltage."""

    V = ElectricalUnit("V", 1.0)
    """Volt"""
    mV = ElectricalUnit("mV", 1 / 1000.0)  # noqa: N815
    """milliVolt"""


class PowerUnit:
    """Measurement unit for electrical power."""

    W = ElectricalUnit("W", 1.0)
    """Watt"""
    mW = ElectricalUnit("mW", 1 / 1000.0)  # noqa: N815
    """milliWatt"""


class LedElectricalQuantity(LedTuple[float]):
    """Base class for generic electrical quantities of a tuple of LEDs.

    Args:
        unit: measurement unit of the quantity

    Note:
        The objects of this class support the multiplication and division operators with a float to scale all values.
    """

    _DEFAULT_VALUE = 0.0
    _DEFAULT_UNIT: ElectricalUnit
    _SUPPORTED_UNITS: tuple[ElectricalUnit, ...]
    _EQ_ABS_TOL = 0.5

    def __init__(
        self,
        red: float | None = None,
        green: float | None = None,
        blue: float | None = None,
        green2: float | None = None,
        unit: ElectricalUnit | None = None,
    ) -> None:
        self.unit = self._DEFAULT_UNIT if unit is None else unit
        super().__init__(red=red, green=green, blue=blue, green2=green2)

    def __post_init__(self) -> None:
        if self.unit is None:
            self.unit = self._DEFAULT_UNIT

    def convert(self, new_unit: ElectricalUnit) -> None:
        """Convert the measurement unit of the quantity.

        Args:
            new_unit: new measurement unit

        Raises:
            ValueError: if the new unit is not supported
        """
        if new_unit not in self._SUPPORTED_UNITS:
            raise ValueError(f"unsupported unit: {new_unit}")
        if self.unit != new_unit:
            multiplier = self.unit.multiplier / new_unit.multiplier
            for i in range(self.SIZE):
                self[i] = self[i] * multiplier
            self.unit = new_unit

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, LedCurrent):
            raise TypeError
        return all(isclose(a, b, abs_tol=self._EQ_ABS_TOL) for a, b in zip(list(self), list(other), strict=False))

    def __mul__(self, other: float) -> Self:
        for i in range(self.SIZE):
            self[i] = self[i] * other
        return self

    def __rmul__(self, other: float) -> Self:
        return self.__mul__(other)

    def __div__(self, other: float) -> Self:
        for i in range(self.SIZE):
            self[i] = self[i] / other
        return self

    def __truediv__(self, other: float) -> Self:
        return self.__div__(other)


class LedCurrent(LedElectricalQuantity):
    """Current values for a tuple of LEDs represented in the specified measurement unit."""

    _DEFAULT_UNIT = CurrentUnit.mA
    _SUPPORTED_UNITS = (CurrentUnit.A, CurrentUnit.mA)


class LedVoltage(LedElectricalQuantity):
    """Voltage values for a tuple of LEDs represented in the specified measurement unit."""

    _DEFAULT_UNIT = VoltageUnit.mV
    _SUPPORTED_UNITS = (VoltageUnit.V, VoltageUnit.mV)


class LedPower(LedElectricalQuantity):
    """Power values for a tuple of LEDs represented in the specified measurement unit."""

    _DEFAULT_UNIT: ElectricalUnit = PowerUnit.mW
    _SUPPORTED_UNITS = (PowerUnit.W, PowerUnit.mW)

    @classmethod
    def calculate(
        cls,
        voltage: LedVoltage,
        current: LedCurrent,
        duty_cycle: LedDutyCycle | None = None,
    ) -> Self:
        """Calculate the LED power from voltage, current, and duty cycle.

        Args:
            voltage: voltage drop across the LEDs
            current: current through the LEDs
            duty_cycle: duty cycle of the PWM driving the LEDs

        Returns:
            electrical power absorbed by the LEDs
        """
        if duty_cycle is None:
            duty_cycle = LedDutyCycle(red=100.0, green=100.0, blue=100.0, green2=100.0)
        v = voltage
        v.convert(VoltageUnit.V)
        i = current
        i.convert(CurrentUnit.mA)
        return cls(
            red=v.red * i.red * duty_cycle.red / 100.0,
            green=v.green * i.green * duty_cycle.green / 100.0,
            blue=v.blue * i.blue * duty_cycle.blue / 100.0,
            green2=v.green2 * i.green2 * duty_cycle.green2 / 100.0,
        )


class LedTemperature(LedTuple[float]):
    """Temperature values for a tern of RGB LEDs in Celsius."""

    _DEFAULT_VALUE = 0.0
