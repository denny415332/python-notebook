"""This is module is used to connect to WaveOptics devices at the protocol level and provide methods to send commands and receive responses.

Other modules in this package provide higher level APIs to interact with the device.

!!! example "Examples"
    === "List devices"
        ``` python
        from wopcprotocol.protocol import Protocol

        devices = Protocol.list_devices(fetch_info=True)
        for (index, device) in enumerate(devices):
            print(
                f"Device {index}: name={device.electronics.name} v{device.hardware_version.minor}, serial={device.serial_number}, firmware=v{device.firmware_version.major}.{device.firmware_version.minor}.{device.firmware_version.patch}"
            )
        ```

    === "Connect to a device"
        ``` python
        from wopcprotocol.protocol import Protocol

        device = Protocol(device_id=0)
        # device = Protocol(device_id="123456789") # serial number
        print(f"connected to device {device.usb_serial_number}")
        device.close()
        ```
"""  # noqa: E501

import logging
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import datetime
from enum import IntEnum
from struct import unpack
from typing import cast

import serial
import serial.tools.list_ports
from crc import Calculator, Crc16

from wopcprotocol.common import CommandResponse, FirmwareVersion, HardwareVersion
from wopcprotocol.errors import (
    CrcError,
    DeviceNotFoundError,
    NoResponseError,
    NotAcknowledgedError,
    OutOfSequenceError,
    PacketLengthError,
    ProtocolError,
)

logger = logging.getLogger(__name__)

#  ===  Packet Structure  ===
#
#  0                   1                   2                   3
#  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
#  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
#  |              Sync             |             Length            |
#  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
#  |Seq|Rxd|A|C|Res|           CommandID           |     Target    |
#  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
#  |                Payload (optional/variable_len)                |
#  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
#  |              CRC              |
#  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+


class Commands(IntEnum):
    SET_INPUT_SOURCE = 0x05
    GET_INPUT_SOURCE = 0x06
    SET_TEST_PATTERN = 0x0B
    GET_PWM_FREQUENCY = 0x24
    SET_PWM_FREQUENCY = 0x25
    GET_RGB_DUTY = 0x26
    SET_RGB_DUTY = 0x27
    SET_RGB_ENABLE = 0x52
    GET_RGB_ENABLE = 0x53
    SET_RGB_CURRENT = 0x54
    GET_RGB_CURRENT = 0x55
    READ_RGB_CURRENT = 0x56
    READ_RGB_PHOTODIODE = 0x57
    READ_RGB_VOLTAGE = 0x58
    RUN_LED_TEST = 0x59

    GET_SYSTEM_STATUS = 0x8005
    GET_SYSTEM_TEMPERATURES = 0x8006

    TEST_STATION_SET = 0x8800
    TEST_STATION_GET = 0x8801

    GET_LIGHT_ENGINE_TYPE = 0xFFD1
    SPI_PASSTHROUGH = 0xFFE0
    GET_REGRESSION_COEFF = 0xFFE4
    SET_REGRESSION_COEFF = 0xFFE5
    TEMPERATURE_CTRL = 0xFFE6
    I2C_RAW_ACCESS = 0xFFE8
    GET_RGB_CURRENT_FT = 0xFFEC
    SET_RGB_CURRENT_FT = 0xFFEE
    GET_ORIENT_ALIGN = 0xFFEF
    SET_ORIENT_ALIGN = 0xFFF0
    GET_BRIGHTNESS_LEVEL = 0xFFF1
    SET_BRIGHTNESS_LEVEL = 0xFFF2
    GET_HARDWARE_STATE = 0xFFF3
    SET_HARDWARE_STATE = 0xFFF4
    REQUEST_PERIODIC_UPDATES = 0xFFF5
    EEPROM_UPDATE = 0xFFF6
    GET_ADC_READINGS = 0xFFF7
    GET_STATUS = 0xFFF9
    FLASH_UPDATE = 0xFFFA
    I2C_PASSTHROUGH = 0xFFFB
    GET_DEVICE_VERSION = 0xFFFC
    REBOOT_DEVICE_DFU = 0xFFFD
    REBOOT_DEVICE = 0xFFFE


class Targets(IntEnum):
    LEFT = 0
    RIGHT = 1
    BOTH = 2
    SYSTEM = 0xFB
    DRIVER_BOARD = 0xFC
    DISPLAY = 0xFD
    MCU = 0xFE


class Hardware(IntEnum):
    DEFAULT = 0
    LED_DRIVER = 1
    LED_MODE = 2
    FAN_INTERNAL = 3
    LED_DRIVER_RLIM = 4
    PANEL_DRIVERS = 7
    FAN_EXTERNAL = 10
    GPIO_OUT = 10
    GPIO_IN = 11
    LED_FEEDBACK = 11
    GUI = 12
    DSI = 13
    NOVA_HAL = 14


class Electronics(IntEnum):
    """Name identifying the electronics."""

    UNKNOWN = 0x0
    """Unknown electronics."""
    PHANTOM = 0x1
    """Phantom."""
    CASPER = 0x2
    """Casper."""
    BLAZE = 0x3
    """Blaze."""
    SPECTRE = 0x4
    """Spectre."""
    SHADE = 0x5
    """Shade."""
    BANSHEE = 0x6
    """Banshee."""
    SHADOW = 0x7
    """Shadow."""
    BODACH = 0x8
    """Bodach."""
    AGNI = 0x9
    """Agni."""
    MYRIAD = 0xA
    """Myriad."""
    HADES = 0xB
    """Hades."""
    EVT = 0xC
    """EVT baseboard/robotboard."""

    @staticmethod
    def contains(index: int) -> bool:
        """Check if the index is a valid electronics type."""
        ret = True
        try:
            Electronics(index)
        except ValueError:
            ret = False
        return ret


@dataclass(frozen=True)
class DeviceInfo:
    """Information about a device.

    This is returned by the [`list_devices`][wopcprotocol.protocol.Protocol.list_devices] method.

    Args:
        port: the serial port of the device
        serial_number: the serial number of the device
        hardware_version: the hardware version of the device
        firmware_version: the firmware version of the device
        electronics: name identifying the electronics
    """

    port: str
    serial_number: str
    hardware_version: HardwareVersion | None = None
    firmware_version: FirmwareVersion | None = None
    electronics: Electronics | None = None


class Protocol:
    """Class to communicate with a WaveOptics device at the protocol level.

    The object holds a reference to the serial port connection and provides methods to send commands and receive responses.

    Args:
        device_id: the index (int) of the device in the list of connected devices or the serial number (str) of the device to connect
        timeout: the timeout of the serial port connection or `None` for blocking mode
    """  # noqa: E501

    NAK_RAISE_EXCEPTION = True
    HEADER = bytes([0x55, 0xAA])
    CURRENT_REG_MAX = 1023
    TIMEOUT_DEFAULT = 3.0
    VID = 0x0483
    PID = 0x5740

    @staticmethod
    def list_devices(*, fetch_info: bool = False) -> tuple[DeviceInfo, ...]:
        """List all the connected devices that match the VID and PID or the manufacturer string.

        Args:
            fetch_info: if `True` the port is temporarily opened to fetch hardware and firmware info

        Returns:
            a list of `DeviceInfo` objects

        Note:
            When `fetch_info` is `True` the method will open the port to fetch the hardware and firmware info.
            This may cause issues if the port is already opened by another process
        """

        def _get_device_info(port: serial.tools.list_ports_common.ListPortInfo) -> DeviceInfo:
            device = DeviceInfo(port=port.device, serial_number=cast(str, port.serial_number))
            if fetch_info:
                try:
                    comms = Protocol(device_id=cast(str, port.serial_number))
                    device = DeviceInfo(
                        port=port.device,
                        serial_number=comms.usb_serial_number,
                        hardware_version=comms.hardware_version,
                        firmware_version=comms.firmware_version,
                        electronics=comms.electronics,
                    )
                    comms.close()
                except serial.serialutil.SerialException as e:
                    logger.warning(f"error fetching info for device {port.serial_number}: {e}")
            return device

        return tuple(
            map(
                _get_device_info,
                filter(
                    lambda p: p.serial_number is not None
                    and (p.manufacturer == "WaveOptics" or (p.vid == Protocol.VID and p.pid == Protocol.PID)),
                    serial.tools.list_ports.comports(),
                ),
            )
        )

    @staticmethod
    def list_devices_by_electronics(electronics: Sequence[Electronics]) -> tuple[DeviceInfo, ...]:
        """List the connected devices matching the specified electronics.

        Args:
            electronics: types of electronics to look for

        Returns:
            a list of `DeviceInfo` objects

        Note:
            In order to read information on the type of electronics the port is temporarily opened,
            see note in [`list_devices`][wopcprotocol.protocol.Protocol.list_devices].
        """
        return tuple(
            filter(
                lambda d: d.electronics is not None and d.electronics in electronics,
                Protocol.list_devices(fetch_info=True),
            )
        )

    def __init__(self, device_id: int | str = 0, timeout: float | None = TIMEOUT_DEFAULT) -> None:
        self.calibration: dict[int, Sequence[float]] = {}
        devices = Protocol.list_devices()
        try:
            if isinstance(device_id, int):
                device = devices[device_id]
            elif isinstance(device_id, str):
                device = next(filter(lambda d: d.serial_number == device_id, devices))
        except (StopIteration, IndexError) as e:
            raise DeviceNotFoundError from e

        self._ser = serial.Serial(device.port, timeout=timeout)
        self._usb_serial_number = device.serial_number
        self._seq_no = 0
        self._rx_seq = 0
        self._last_ack = True
        # Disable notifications and purge old data from USB buffer, but first disable logger to avoid out of sync errors
        logger.disabled = True
        self.send(
            command=Commands.REQUEST_PERIODIC_UPDATES, target=Targets.MCU, payload=bytes([0x00, 0x00, 0x00, 0x00])
        )
        self.flush()
        logger.disabled = False
        # Get hardware and firmware info
        self._hardware_version, self._firmware_version = self._get_device_info()
        if Electronics.contains(self.hardware_version.major):
            self._electronics = Electronics(self.hardware_version.major)
        else:
            self._electronics = Electronics.UNKNOWN

    def __del__(self) -> None:
        if hasattr(self, "_ser"):
            self.close()

    def _send(self, command: int, target: int, payload: bytes = b"") -> None:
        status = self._seq_no | (self._rx_seq << 3)
        if self._last_ack:
            status |= 0x10
        packet = bytes([status]) + command.to_bytes(2, byteorder="little") + bytes([target]) + payload
        length = len(packet) + 6
        packet = self.HEADER + length.to_bytes(2, byteorder="little") + packet
        crc = Calculator(Crc16.IBM_3740.value).checksum(packet).to_bytes(2, byteorder="little")
        packet = packet + crc
        self._ser.write(packet)
        logger.debug(f"sent -> [{packet[4:-2].hex(',')}]")
        self._seq_no = (self._seq_no + 1) & 0x03

    def _receive(self, command: int, timeout: float | None = None) -> CommandResponse:
        ack = False
        read: bytes = b""
        self._last_ack = False

        # Custom timeout?
        original_timeout = self._ser.timeout
        if timeout is not None:
            self._ser.timeout = timeout

        error: ProtocolError | None = None
        try:
            # Read header and packet length
            read = self._ser.read(4)
            if len(read) != 4:
                raise NoResponseError
            if int.from_bytes(read[0:2], byteorder="little") != 0xAA55:
                raise ProtocolError("magic header not found")  # noqa: TRY301
            # Parse the packet length
            full_length = int.from_bytes(read[2:4], byteorder="little")
            length = full_length - 4
            # Read the rest of the packet
            read = self._ser.read(length)
            if len(read) != length:
                raise PacketLengthError
            # Check the command ID
            if command != int.from_bytes(read[1:3], byteorder="little"):
                raise OutOfSequenceError
            self._rx_seq = read[0] & 0x03
            # Calculate the CRC
            message = self.HEADER + full_length.to_bytes(2, byteorder="little") + read[0 : length - 2]
            crc = Calculator(Crc16.IBM_3740.value).checksum(message)
            # Check the CRC
            if crc != int.from_bytes(read[length - 2 :], byteorder="little"):
                raise CrcError
            read = read[: length - 2]
            if read[0] & 0x10:
                ack = True
            response = CommandResponse(
                ack=ack,
                command_id=int.from_bytes(read[1:3], byteorder="little"),
                target=read[3],
                payload=bytes(read[4:]),
            )
        except ProtocolError as e:
            error = e
        self._last_ack = ack
        # Custom timeout? Restore the original one
        if timeout is not None:
            self._ser.timeout = original_timeout
        logger.debug(f"recv <- [{read.hex(',')}]")
        # Raise and exception?
        if error is not None:
            raise error
        if not response.ack and self.NAK_RAISE_EXCEPTION:
            raise NotAcknowledgedError(response=response)
        return response

    def _get_device_info(self) -> tuple[HardwareVersion, FirmwareVersion]:
        response = self.send(command=Commands.GET_DEVICE_VERSION, target=Targets.MCU)
        data = unpack("<BBBBBBIHH12s", response.payload)
        hardware_version = HardwareVersion(major=data[0], minor=data[1], serial_number=data[9])
        firmware_version = FirmwareVersion(
            major=data[2],
            minor=data[3],
            patch=data[4],
            build_number=data[8],
            build_timestamp=datetime.fromtimestamp(data[6]).strftime("%Y-%m-%d %H:%M:%S"),
            git_commit=hex(data[7]),
        )
        return (hardware_version, firmware_version)

    @property
    def usb_serial_number(self) -> str:
        """USB serial number of the device."""
        return self._usb_serial_number

    @property
    def hardware_version(self) -> HardwareVersion:
        """Hardware version of the device."""
        return self._hardware_version

    @property
    def firmware_version(self) -> FirmwareVersion:
        """Firmware version of the device."""
        return self._firmware_version

    @property
    def electronics(self) -> Electronics:
        """Name identifying the electronics."""
        return self._electronics

    def flush(self) -> None:
        """Flush the serial port by reading all the available data."""
        timeout = self._ser.timeout
        self._ser.timeout = 0.25
        self._ser.read(0xFFFF)
        self._ser.timeout = timeout

    def send(self, *, command: int, target: int, payload: bytes = b"", timeout: float | None = None) -> CommandResponse:
        """Send a command to the device and wait for the response.

        Args:
            command: the command to send
            target: the target of the command
            payload: the payload of the command
            timeout: the timeout of the command or `None` to use the one set at the object creation

        Returns:
            the response to the command

        Raises:
            ProtocolError: if the response is not valid or not acknowledged
        """
        self._send(command=command, target=target, payload=payload)
        return self._receive(command, timeout)

    def close(self) -> None:
        """Close the serial port connection."""
        if self._ser.is_open:
            self._ser.close()
