"""This module provides functions to access the I2C bus(es) on the connected device."""

import logging
from enum import IntEnum
from struct import pack

from wopcprotocol.common import Side
from wopcprotocol.protocol import Commands, Protocol

logger = logging.getLogger(__name__)


class I2CCommands(IntEnum):
    I2C_READ = 0x00
    I2C_WRITE = 0x01


class I2C_Addresses(IntEnum):
    DP_DSI_CONVERTER_LT7911D = (0x56,)
    DMD_DRIVER_DLPC3433_LEFT = (0x36,)
    DMD_DRIVER_DLPC3433_RIGHT = (0x3A,)
    LED_DRIVER_ISL97901_LEFT = (0x50,)
    LED_DRIVER_ISL97901_RIGHT = (0x52,)
    I2C_EXPANDER_PCA9570GMH = (0x48,)
    I2C_EXPANDER_PI4IOE5V64 = (0x43,)
    I2C_1WIRE_BRIDGE_DS2482X = 0x18


def read(*, target: Side, addr: int, reg: int, size: int, comms: Protocol) -> bytes:
    """Read raw data from I2C device.

    Args:
        target: side identifying the I2C bus
        addr: I2C address of the device
        reg: register to read
        size: number of bytes to read
        comms: reference to the comms object

    Returns:
        data read from the device

    Note:
        The side argument is only relevant for devices having multiple I2C buses,
        and this normally happens in projectors-driving electronics.
    """
    payload = pack("<BHHH", I2CCommands.I2C_READ, addr, reg, size)
    response = comms.send(command=Commands.I2C_RAW_ACCESS, target=target, payload=payload)
    return response.payload[7:]


def write(*, target: Side, addr: int, reg: int, data: bytes, comms: Protocol) -> None:
    """Write raw data to I2C device.

    Args:
        target: side identifying the I2C bus
        addr: I2C address of the device
        reg: register to write
        data: data to write
        comms: reference to the comms object

    Note:
        See note in [`read`][wopcprotocol.raw_i2c.read].
    """
    payload = pack("<BHHH", I2CCommands.I2C_WRITE, addr, reg, len(data))
    payload += data
    comms.send(command=Commands.I2C_RAW_ACCESS, target=target, payload=payload)
