"""This module contains the definitions of the mount flex EEPROM structure for all the different versions, along with methods for serialising/deserialising data.

Moreover, few examples are provided to cover the most common scenarios.

!!! example "Examples"
    === "Serialisation"
        ``` python
        from wopcprotocol.mountflex_eeprom import MountFlexEEPROMv2
        import time

        mount_flex_eeprom = MountFlexEEPROMv2(previous_station=3,
                                      current_unit_connects=4,
                                      global_connects=30,
                                      lcos_connects_left=2,
                                      lcos_connects_right=62,
                                      first_use_timestamp=int(time.time()),
                                      lcos_id_left="lcos_lhs_id".encode(),
                                      lcos_id_right="lcos_rhs_id".encode(),
                                      oe_id="optical_engine_id".encode(),
                                      mount_id="mymount_id".encode())
        data = mount_flex_eeprom.pack()
        ```
    === "Deserialisation"
        ``` python
        from wopcprotocol.mountflex_eeprom import MountFlexEEPROM

        # Typically data is fetched from the electronics
        data = bytes([
            0x2, 0x0, 0x3, 0x0, 0x4, 0x0, 0x1e, 0x0, 0x2, 0x0, 0x3e, 0x0, 0x72, 0xcb,
            0xbf, 0x64, 0x6c, 0x63, 0x6f, 0x73, 0x5f, 0x6c, 0x68, 0x73, 0x5f, 0x69,
            0x64, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x6c, 0x63, 0x6f, 0x73, 0x5f, 0x72,
            0x68, 0x73, 0x5f, 0x69, 0x64, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x6f,
            0x70, 0x74, 0x69, 0x63, 0x61, 0x6c, 0x5f, 0x65, 0x6e, 0x67, 0x69, 0x6e,
            0x65, 0x5f, 0x69, 0x64, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x0, 0x0, 0x6d, 0x79, 0x6d, 0x6f, 0x75, 0x6e, 0x74, 0x5f,
            0x69, 0x64, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0
        ])
        mount_flex_eeprom = MountFlexEEPROM.unpack(data)
        print(f"version = {mount_flex_eeprom.header_ver}")
        print(mount_flex_eeprom)
        ```
"""

from __future__ import annotations

import logging
import struct
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, ClassVar

if TYPE_CHECKING:
    from typing_extensions import Self

###################################################################
########################### VERSION 1 #############################
###################################################################
#  0                   1                   2                   3
#  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |   Header_Ver  |    Reserved   |        Previous Station       |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |     Current Unit Connects     |        Global Connects        |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |        LHS LCoS connects      |        RHS LCoS connects      |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                       FirstUse Timestamp                      |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                          LHS LCoS uid                         +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                          RHS LCoS uid                         +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                              OE ID                            +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

###################################################################
########################### VERSION 2 #############################
###################################################################
#  0                   1                   2                   3
#  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |   Header_Ver  |    Reserved   |        Previous Station       |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |     Current Unit Connects     |        Global Connects        |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |        LHS LCoS connects      |        RHS LCoS connects      |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                       FirstUse Timestamp                      |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                          LHS LCoS uid                         +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                          RHS LCoS uid                         +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                              OE ID                            +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                            Mount ID                           +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

###################################################################
########################### VERSION 3 #############################
###################################################################
#  0                   1                   2                   3
#  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |   Header_Ver  |    Reserved   |        Previous Station       |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |     Current Unit Connects     |        Global Connects        |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |        LHS LCoS connects      |        RHS LCoS connects      |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                       FirstUse Timestamp                      |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                          LHS LCoS uid                         +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                          RHS LCoS uid                         +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                              OE ID                            +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                            Mount ID                           +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                             Flex ID                           +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +                                                               +
# |                                                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

# Firmware reserved EEPROM area. This resides at the very end of the EEPROM
#  0                   1                   2                   3
#  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |          LHS LCoS CRC         |        LHS LCoS connects      |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |          RHS LCoS CRC         |        RHS LCoS connects      |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

logger = logging.getLogger(__name__)


@dataclass
class FirmwareReserved:
    """Structure of the firmware-reserved EEPROM area.

    Args:
        lcos_id_crc_left: CRC of the LHS LCoS identifier
        lcos_connects_left: number of connections for the LHS LCoS
        lcos_id_crc_right: CRC of the RHS LCoS identifier
        lcos_connects_right: number of connections for the RHS LCoS
    """

    lcos_connects_left: int
    lcos_connects_right: int
    lcos_id_crc_left: int
    lcos_id_crc_right: int
    """Size of the serialised data"""
    SIZE: ClassVar[int] = 8

    @classmethod
    def unpack(cls, data: bytes) -> Self:
        """Deserialise EEPROM data.

        Args:
            data: a bytes stream of data typically fetched from the mount flex EEPROM
        """
        if len(data) != cls.SIZE:
            raise ValueError(f"unpack requires a buffer of {cls.SIZE} bytes")
        return cls(*struct.unpack("<HHHH", data))


@dataclass
class MountFlexEEPROM:
    """Base class for the structure of the mount flex EEPROM.

    Args:
        header_ver: version of the EEPROM structure
        previous_station: identify the previous test station where the mount flex was used
        current_unit_connects: number of connections for the current optical engine
        global_connects: total number of connections for the mount flex
        lcos_connects_left: number of connections for the LHS LCoS
        lcos_connects_right: number of connections for the RHS LCoS
        first_use_timestamp:
        lcos_id_left: identifier for the LHS LCoS of the current optical engine
        lcos_id_right: identifier for the RHS LCoS of the current optical engine
        oe_id: identifier of the optical engine
    """

    header_ver: int
    previous_station: int
    current_unit_connects: int
    global_connects: int
    lcos_connects_left: int
    lcos_connects_right: int
    first_use_timestamp: int
    lcos_id_left: bytes
    lcos_id_right: bytes
    oe_id: bytes

    LCOS_ID_MAX_SIZE: ClassVar[int] = 48
    """Maximum size for the LCoS identifier"""
    OE_ID_MAX_SIZE: ClassVar[int] = 32
    """Maximum size for the optical engine identifier"""
    SIZE: ClassVar[int] = 144
    """Size of the serialised EEPROM data"""

    @staticmethod
    def _rstrip(array: bytes) -> bytes:
        _array = bytearray(array)
        while len(_array) > 0 and _array[-1] == 0:
            del _array[-1]
        return bytes(_array)

    def pack(self) -> bytes:
        """Serialise EEPROM data.

        Raises:
            NotImplementedError: the base class does not implement this

        Returns:
            byte stream of data obtained after serialising the instance
        """
        raise NotImplementedError

    @classmethod
    def unpack(cls, data: bytes) -> MountFlexEEPROM:
        """Deserialise EEPROM data.

        Args:
            data: a bytes stream of data typically fetched from the mount flex EEPROM

        Raises:
            ValueError: if the header version is not recognised

        Returns:
            instance of the class parsed from the input byte stream
        """
        header_version = data[0]
        if header_version == MountFlexEEPROMv1.VERSION_NUMBER:
            return MountFlexEEPROMv1.unpack(data)
        if header_version == MountFlexEEPROMv2.VERSION_NUMBER:
            return MountFlexEEPROMv2.unpack(data)
        if header_version == MountFlexEEPROMv3.VERSION_NUMBER:
            return MountFlexEEPROMv3.unpack(data)
        raise ValueError("Mount Flex EEPROM header version not recognised")


@dataclass
class MountFlexEEPROMv1(MountFlexEEPROM):
    """Version 1 of the mount flex EEPROM structure."""

    header_ver: int = field(init=False, default=1)

    VERSION_NUMBER: ClassVar[int] = 1
    """Version of the mount flex EEPROM structure"""

    def pack(self) -> bytes:
        """Serialise EEPROM data.

        Returns:
            byte stream of data obtained after serialising the instance
        """
        data = struct.pack(
            "<BBHHHHHI",
            self.header_ver,
            0,
            self.previous_station,
            self.current_unit_connects,
            self.global_connects,
            self.lcos_connects_left,
            self.lcos_connects_right,
            self.first_use_timestamp,
        )
        data += struct.pack(
            f"<{MountFlexEEPROM.LCOS_ID_MAX_SIZE}s{MountFlexEEPROM.LCOS_ID_MAX_SIZE}s{MountFlexEEPROM.OE_ID_MAX_SIZE}s",
            self.lcos_id_left,
            self.lcos_id_right,
            self.oe_id,
        )
        return bytes(data)

    @classmethod
    def unpack(cls, data: bytes) -> MountFlexEEPROM:
        """Deserialise EEPROM data.

        Args:
            data: a bytes stream of data typically fetched from the mount flex EEPROM

        Raises:
            ValueError: if the header version does not match `VERSION_NUMBER` or if the length of the byte stream is not equal to `SIZE`

        Returns:
            instance of the class parsed from the input byte stream
        """  # noqa: E501
        if len(data) != cls.SIZE:
            raise ValueError(f"unpack requires a buffer of {cls.SIZE} bytes")
        # Check header version
        if data[0] != cls.VERSION_NUMBER:
            raise ValueError(f"wrong version number: got {data[0]}, expected {cls.VERSION_NUMBER}")
        mount_flex_eeprom = cls(
            *struct.unpack(
                f"<xxHHHHHI{MountFlexEEPROM.LCOS_ID_MAX_SIZE}s{MountFlexEEPROM.LCOS_ID_MAX_SIZE}s{MountFlexEEPROM.OE_ID_MAX_SIZE}s",
                data,
            )
        )
        # Strip trailing zeros
        mount_flex_eeprom.lcos_id_left = cls._rstrip(mount_flex_eeprom.lcos_id_left)
        mount_flex_eeprom.lcos_id_right = cls._rstrip(mount_flex_eeprom.lcos_id_right)
        mount_flex_eeprom.oe_id = cls._rstrip(mount_flex_eeprom.oe_id)
        return mount_flex_eeprom


@dataclass
class MountFlexEEPROMv2(MountFlexEEPROM):
    """Version 2 of the mount flex EEPROM structure.

    Args:
        mount_id: identifier of the mount
    """

    header_ver: int = field(init=False, default=2)
    mount_id: bytes

    VERSION_NUMBER: ClassVar[int] = 2
    """Version of the mount flex EEPROM structure"""
    MOUNT_ID_MAX_SIZE: ClassVar[int] = 32
    """Maximum size for the mount identifier"""
    SIZE: ClassVar[int] = 176
    """Size of the serialised EEPROM data"""

    def pack(self) -> bytes:
        """Serialise EEPROM data.

        Returns:
            byte stream of data obtained after serialising the instance
        """
        data = struct.pack(
            "<BBHHHHHI",
            self.header_ver,
            0,
            self.previous_station,
            self.current_unit_connects,
            self.global_connects,
            self.lcos_connects_left,
            self.lcos_connects_right,
            self.first_use_timestamp,
        )
        data += struct.pack(
            f"<{MountFlexEEPROM.LCOS_ID_MAX_SIZE}s{MountFlexEEPROM.LCOS_ID_MAX_SIZE}s{MountFlexEEPROM.OE_ID_MAX_SIZE}s",
            self.lcos_id_left,
            self.lcos_id_right,
            self.oe_id,
        )
        data += struct.pack(f"<{self.MOUNT_ID_MAX_SIZE}s", self.mount_id)
        return bytes(data)

    @classmethod
    def unpack(cls, data: bytes) -> Self:
        """Deserialise EEPROM data.

        Args:
            data: a bytes stream of data typically fetched from the mount flex EEPROM

        Raises:
            ValueError: if the header version does not match `VERSION_NUMBER` or if the length of the byte stream is not equal to `SIZE`

        Returns:
            instance of the class parsed from the input byte stream
        """  # noqa: E501
        if len(data) != cls.SIZE:
            raise ValueError(f"unpack requires a buffer of {cls.SIZE} bytes")
        # Check header version
        if data[0] != cls.VERSION_NUMBER:
            raise ValueError(f"wrong version number: got {data[0]}, expected {cls.VERSION_NUMBER}")

        mount_flex_eeprom = cls(
            *struct.unpack(
                f"<xxHHHHHI{cls.LCOS_ID_MAX_SIZE}s{cls.LCOS_ID_MAX_SIZE}s{cls.OE_ID_MAX_SIZE}s{cls.MOUNT_ID_MAX_SIZE}s",
                data,
            )
        )
        # Strip trailing zeros
        mount_flex_eeprom.lcos_id_left = cls._rstrip(mount_flex_eeprom.lcos_id_left)
        mount_flex_eeprom.lcos_id_right = cls._rstrip(mount_flex_eeprom.lcos_id_right)
        mount_flex_eeprom.oe_id = cls._rstrip(mount_flex_eeprom.oe_id)
        mount_flex_eeprom.mount_id = cls._rstrip(mount_flex_eeprom.mount_id)
        return mount_flex_eeprom


@dataclass
class MountFlexEEPROMv3(MountFlexEEPROMv2):
    """Version 3 of the mount flex EEPROM structure.

    Args:
        flex_id: identifier of the mount flex
    """

    header_ver: int = field(init=False, default=3)
    flex_id: bytes

    VERSION_NUMBER: ClassVar[int] = 3
    """Version of the mount flex EEPROM structure"""
    FLEX_ID_MAX_SIZE: ClassVar[int] = 32
    """Maximum size for the mount identifier"""
    SIZE: ClassVar[int] = 208
    """Size of the serialised EEPROM data"""

    def pack(self) -> bytes:
        """Serialise EEPROM data.

        Returns:
            byte stream of data obtained after serialising the instance
        """
        data = super().pack()
        data += struct.pack(f"<{self.FLEX_ID_MAX_SIZE}s", self.flex_id)
        return bytes(data)

    @classmethod
    def unpack(cls, data: bytes) -> Self:
        """Deserialise EEPROM data.

        Args:
            data: a bytes stream of data typically fetched from the mount flex EEPROM

        Raises:
            ValueError: if the header version does not match `VERSION_NUMBER` or if the length of the byte stream is not equal to `SIZE`

        Returns:
            instance of the class parsed from the input byte stream
        """  # noqa: E501
        if len(data) != cls.SIZE:
            raise ValueError(f"unpack requires a buffer of {cls.SIZE} bytes")
        # Check header version
        if data[0] != cls.VERSION_NUMBER:
            raise ValueError(f"wrong version number: got {data[0]}, expected {cls.VERSION_NUMBER}")

        # Make a copy and artificially set the header version to v2 to use parent class unpack
        _data = bytes([super().VERSION_NUMBER]) + data[1 : super().SIZE]
        mount_flex_eeprom_v2 = MountFlexEEPROMv2.unpack(bytes(_data))
        # Now unpack the rest of the info...
        (flex_id,) = struct.unpack(f"{cls.FLEX_ID_MAX_SIZE}s", data[super().SIZE :])
        # ... and create the instance
        mount_flex_eeprom = cls(**mount_flex_eeprom_v2.__dict__, flex_id=flex_id)
        mount_flex_eeprom.flex_id = cls._rstrip(mount_flex_eeprom.flex_id)
        return mount_flex_eeprom
