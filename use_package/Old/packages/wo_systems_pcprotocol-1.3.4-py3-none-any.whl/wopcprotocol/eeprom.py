"""This modules includes functions to read and write to the EEPROM."""

import time
from enum import IntEnum
from struct import pack, unpack

from wopcprotocol.common import CommandResponse
from wopcprotocol.protocol import Commands, Protocol, Targets


class EEPROMCommands(IntEnum):
    EEPROM_READ = 0x00
    EEPROM_WRITE = 0x01
    EEPROM_READ_ARRAY = 0x02
    EEPROM_WRITE_ARRAY = 0x03
    EEPROM_READ_ID = 0x04
    EEPROM_INVALIDATE = 0x05


_MAX_LENGTH: int = 16


def _parse_eeprom_read(response: CommandResponse) -> bytes:
    data: bytes = b""
    if len(response.payload) == 20:
        data = unpack("<BHB16s", response.payload)[-1]
    else:
        data = unpack("<BHB8s", response.payload)[-1]
    return data


def read_eeprom_id(target: Targets, comms: Protocol) -> bytes:
    """Reads the ID of the EEPROM.

    Args:
        target: the target EEPROM to read from
        comms: reference to the com port object to use

    Returns:
        the ID of the EEPROM

    Note:
        The target is used to pick which EEPROM to read from.
        Some boards have only one EEPROM so the target is ignored in firmware.
    """
    payload = bytes([EEPROMCommands.EEPROM_READ_ID])
    response = comms.send(command=Commands.EEPROM_UPDATE, target=target, payload=payload)
    return _parse_eeprom_read(response)


def read_eeprom_array(*, target: Targets, address: int, length: int, comms: Protocol) -> bytes:
    """Reads a block of data from the EEPROM.

    Args:
        target: the target EEPROM to read from
        address: the address to read from
        length: the number of bytes to read
        comms: reference to the com port object to use

    Returns:
        the data read from the EEPROM

    Raises:
        ValueError: if `address` is less than 0 or `length` is less than or equal to 0

    Note:
        See note in [`read_eeprom_id`][wopcprotocol.eeprom.read_eeprom_id].
    """
    if address < 0:
        raise ValueError("address must be >= 0")
    if length <= 0:
        raise ValueError("length must be > 0")
    data = b""
    bytes_read = 0
    while bytes_read < length:
        chunk_length = min(length - bytes_read, _MAX_LENGTH)
        payload = bytes([EEPROMCommands.EEPROM_READ_ARRAY])
        payload += bytes(pack("<H", address))
        payload += bytes([chunk_length])
        response = comms.send(command=Commands.EEPROM_UPDATE, target=target, payload=payload)
        chunk = _parse_eeprom_read(response)
        data += chunk[:chunk_length]
        bytes_read += chunk_length
        address += chunk_length
    return data


def write_eeprom_array(*, target: Targets, address: int, data: bytes, comms: Protocol) -> None:
    """Writes a block of data to the EEPROM.

    Args:
        target: the target to write to
        address: the address to write to
        data: the data to write
        comms: reference to the com port object to use

    Raises:
        ValueError: if `address` is less than 0 or `len(data)` is equal to 0

    Note:
        See note in [`read_eeprom_id`][wopcprotocol.eeprom.read_eeprom_id].
    """
    if address < 0:
        raise ValueError("address must be >= 0")
    if len(data) == 0:
        raise ValueError("len(data) must be > 0")
    bytes_written = 0
    while bytes_written < len(data):
        chunk_size = min(len(data) - bytes_written, _MAX_LENGTH)
        chunk = data[bytes_written : bytes_written + chunk_size]
        payload = bytes([EEPROMCommands.EEPROM_WRITE_ARRAY])
        payload += bytes(pack("<H", address))
        payload += bytes([chunk_size])
        payload += bytes(chunk)
        comms.send(command=Commands.EEPROM_UPDATE, target=target, payload=payload)
        # Wait for the write to complete
        time.sleep(0.1)
        bytes_written += chunk_size
        address += chunk_size
