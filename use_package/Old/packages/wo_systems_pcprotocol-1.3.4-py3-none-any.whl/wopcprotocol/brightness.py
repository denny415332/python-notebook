"""Module for controlling most of the LED-related features of a projector or led driver.

!!! example "Examples"
    === "Set LEDs state and current"
        ``` python
        import time
        from wopcprotocol.protocol import Protocol
        from wopcprotocol.common import Side, LedState, LedCurrent
        from wopcprotocol.brightness import *

        comms = Protocol()

        # Set all LEDs on both sides to 50 mA
        for side in Side:
            set_led_state(side=side, state=LedState.on(), comms=comms)
            set_led_current(side=side,
                            current=LedCurrent.all(50.0),
                            use_nvm=False,
                            comms=comms)

        # Wait
        time.sleep(3)

        # Set the left side to 150 mA red
        set_led_state(side=Side.LEFT,
              state=LedState(red=True, green=False, blue=False, green2=False),
              comms=comms)
        set_led_current(side=Side.LEFT,
                        current=LedCurrent(red=150.0, green=0.0, blue=0.0, green2=0.0),
                        use_nvm=False,
                        comms=comms)
        ```
"""

import logging
from collections.abc import Sequence
from enum import IntEnum
from math import isclose, sqrt
from struct import pack, unpack

from wopcprotocol.common import LedBrightness, LedCurrent, LedDutyCycle, LedState, LedVoltage, Side, VoltageUnit
from wopcprotocol.errors import NotAcknowledgedError, UncalibratedElectronicsError
from wopcprotocol.protocol import Commands, Electronics, Hardware, Protocol, Targets

logger = logging.getLogger(__name__)


class Rlim(IntEnum):
    """Limiting resistor value for the LED driver."""

    RLIM_100 = 0
    """100 mΩ"""
    RLIM_200 = 1
    """200 mΩ"""
    RLIM_300 = 2
    """300 mΩ"""
    RLIM_400 = 3
    """400 mΩ"""
    RLIM_500 = 4
    """500 mΩ"""
    RLIM_600 = 5
    """600 mΩ"""
    RLIM_700 = 6
    """700 mΩ"""
    RLIM_800 = 7
    """800 mΩ"""


def _current_to_reg(current_ma: float, target: int, comms: Protocol) -> int:
    coefficients = get_calibration(target, comms)
    reg = round(coefficients[0] + coefficients[1] * current_ma + coefficients[2] * current_ma**2)
    reg = min(reg, Protocol.CURRENT_REG_MAX)
    return max(reg, 0)


def _reg_to_current(reg: int, target: int, comms: Protocol) -> float:
    def _invert_regression_function(coefficients: Sequence[float], reg: int) -> float:
        c, b, a = coefficients
        # 1st order approximation
        if isclose(a, 0.0):
            if isclose(b, 0.0):
                raise ValueError("invalid coefficients")
            return (reg - c) / b
        # 2nd order approximation
        sqrt_arg = b**2 - 4 * a * (c - reg)
        if sqrt_arg < 0:
            raise ValueError("sqrt arg is negative")
        res = (sqrt(sqrt_arg) - b) / (2 * a)
        if res < 0:
            res = (-sqrt(sqrt_arg) - b) / (2 * a)
        return res

    if reg < 0 or reg > Protocol.CURRENT_REG_MAX:
        raise ValueError(f"reg must be in [0, {Protocol.CURRENT_REG_MAX}]")
    coefficients = get_calibration(target, comms)
    current_ma = _invert_regression_function(coefficients, reg=reg)
    return max(current_ma, 0.0)


def set_led_driver(side: Side, enable: bool, comms: Protocol) -> None:
    """Set the state of the LED driver.

    Args:
        side: the side of the projector (if applicable)
        enable: True to enable the LED driver, False to disable it
        comms: reference to the com port object to use
    """
    payload = pack("<BB", Hardware.LED_DRIVER, 1 if enable else 0)
    comms.send(command=Commands.SET_HARDWARE_STATE, target=side, payload=payload)


def get_led_driver(side: Side, comms: Protocol) -> bool:
    """Get the state of the LED driver.

    Args:
        side: the side of the projector (if applicable)
        comms: reference to the com port object to use

    Returns:
        True if the LED driver is enabled, False otherwise
    """
    response = comms.send(command=Commands.GET_HARDWARE_STATE, target=side, payload=bytes([Hardware.LED_DRIVER]))
    return bool(response.payload[1] & 0x1)


def set_led_brightness(
    *,
    side: Side,
    brightness: LedBrightness,
    use_nvm: bool,
    comms: Protocol,
) -> None:
    """Set the brightness of the LEDs.

    Args:
        side: the side of the projector (if applicable)
        brightness: the brightness to set
        use_nvm: True to permanently store the brightness in NVM, False otherwise
        comms: reference to the com port object to use

    Note:
        In general, only projectors-driving electronics supports NVM storage.
        Other electronics supports the API regardless of the `use_nvm` flag but do not store the values.

    Warning:
        Unless specifically needed, it is recommended to not use NVM storage as it wears out the flash memory.
    """
    payload = pack("<HHHHB", brightness.red, brightness.blue, brightness.green, brightness.green2, 0)
    comms.send(
        command=Commands.SET_RGB_CURRENT if use_nvm else Commands.SET_RGB_CURRENT_FT, target=side, payload=payload
    )


def get_led_brightness(side: Side, use_nvm: bool, comms: Protocol) -> LedBrightness:
    """Get the brightness of the LEDs.

    Args:
        side: the side of the projector (if applicable)
        use_nvm: True to read the brightness from NVM, False otherwise
        comms: reference to the com port object to use

    Returns:
        the brightness of the LEDs
    """
    response = comms.send(command=Commands.GET_RGB_CURRENT if use_nvm else Commands.GET_RGB_CURRENT_FT, target=side)
    values = unpack("<HHHH", response.payload[:8])
    return LedBrightness(red=values[0], green=values[2], blue=values[1], green2=values[3])


def get_calibration(target: int, comms: Protocol, force_read: bool = False) -> Sequence[float]:
    """Get the current-to-register calibration data for a specific electronics-dependent target.

    Args:
        target: the target to get the calibration data for
        comms: reference to the com port object to use
        force_read: True forces reading the calibration data from the device, False uses the cached data if available

    Returns:
        the calibration data for the target

    Raises:
        UncalibratedElectronicsError: if the electronics is not calibrated

    Info:
        The calibration data is a list of `n` (usually 3) floats representing the coefficients of a `n-th` order
        polynomial regression function to convert a current in mA to a register value.
        The calibration data is unique for every electronics and is stored in NVM. The targets are generic indexes
        mapped to specific electronics-dependent characteristics, e.g. led driver channel, side, etc.
        The data is read from the device the first time it is requested and then cached. The cache is invalidated when
        the [`set_led_driver_rlim`][wopcprotocol.brightness.set_led_driver_rlim] function is called.
    """
    if target not in comms.calibration or force_read:
        try:
            response = comms.send(command=Commands.GET_REGRESSION_COEFF, target=target)
            coefficients: Sequence[float] = unpack("<fff", response.payload)
            comms.calibration[target] = coefficients
        except NotAcknowledgedError as e:
            raise UncalibratedElectronicsError("failed to read calibration data") from e
    else:
        logger.info("using cached calibration data")
        # Get the cached data
        coefficients = comms.calibration[target]
    return coefficients


def set_calibration(target: int, coefficients: Sequence[float], comms: Protocol) -> None:
    """Set the current-to-register calibration data for a specific electronics-dependent target.

    Args:
        target: the target to set the calibration data for
        coefficients: `n` (usually 3) floats representing the coefficients of a `n-th` order polynomial regression
        comms: reference to the com port object to use

    Raises:
        ValueError: if the coefficients list is not the correct length

    Info:
        See note for [`get_calibration`][wopcprotocol.brightness.get_calibration].
    """
    if len(coefficients) != 3:
        raise ValueError("coefficients must be a list of 3 floats")
    payload = pack("<fff", *coefficients)
    comms.send(command=Commands.SET_REGRESSION_COEFF, target=target, payload=payload)


def set_led_current(*, side: Side, current: LedCurrent, use_nvm: bool, comms: Protocol) -> None:
    """Set the current of the LEDs.

    Args:
        side: the side of the projector (if applicable)
        current: the current to set
        use_nvm: True to permanently store the current in NVM, False otherwise
        comms: reference to the com port object to use

    Raises:
        UncalibratedElectronicsError: if the electronics is not calibrated

    Note:
        See note for [`set_led_brightness`][wopcprotocol.brightness.set_led_brightness].
    """
    if comms.electronics == Electronics.AGNI:
        brightness = LedBrightness(
            red=_current_to_reg(current.red, 0, comms),
            green=_current_to_reg(current.green, 1, comms),
            blue=_current_to_reg(current.blue, 2, comms),
        )
    elif comms.electronics == Electronics.BLAZE:
        # Blaze 4 supports 2nd green
        green2 = None
        if comms.hardware_version.minor >= 4:
            green2 = _current_to_reg(current.green2, 1, comms)
        brightness = LedBrightness(
            red=_current_to_reg(current.red, 0, comms),
            green=_current_to_reg(current.green, 0, comms),
            blue=_current_to_reg(current.blue, 0, comms),
            green2=green2,
        )
    else:
        brightness = LedBrightness(
            red=_current_to_reg(current.red, side, comms),
            green=_current_to_reg(current.green, side, comms),
            blue=_current_to_reg(current.blue, side, comms),
        )

    set_led_brightness(side=side, brightness=brightness, use_nvm=use_nvm, comms=comms)


def get_led_current(side: Side, use_nvm: bool, comms: Protocol) -> LedCurrent:
    """Get the current of the LEDs.

    Args:
        side: the side of the projector (if applicable)
        use_nvm: True to read the current from NVM, False otherwise
        comms: reference to the com port object to use

    Returns:
        the current of the LEDs

    Raises:
        UncalibratedElectronicsError: if the electronics is not calibrated
    """
    brightness = get_led_brightness(side=side, use_nvm=use_nvm, comms=comms)
    if comms.electronics == Electronics.AGNI:
        current = LedCurrent(
            red=_reg_to_current(brightness.red, 0, comms),
            green=_reg_to_current(brightness.green, 1, comms),
            blue=_reg_to_current(brightness.blue, 2, comms),
        )
    elif comms.electronics == Electronics.BLAZE:
        green2 = None
        if comms.hardware_version.minor >= 4:
            green2 = _reg_to_current(brightness.green2, 1, comms)
        current = LedCurrent(
            red=_reg_to_current(brightness.red, 0, comms),
            green=_reg_to_current(brightness.green, 0, comms),
            blue=_reg_to_current(brightness.blue, 0, comms),
            green2=green2,
        )
    else:
        current = LedCurrent(
            red=_reg_to_current(brightness.red, side, comms),
            green=_reg_to_current(brightness.green, side, comms),
            blue=_reg_to_current(brightness.blue, side, comms),
        )
    return current


def get_brightness_level_max(comms: Protocol) -> int:
    """Get the maximum brightness level for electronics supporting level control.

    Args:
        comms: reference to the com port object to use

    Returns:
        the maximum brightness level

    Info:
        Only projectors-driving electronics support level control.
    """
    response = comms.send(command=Commands.GET_BRIGHTNESS_LEVEL, target=Targets.MCU)
    return int(unpack("<xB", response.payload)[0])


def get_brightness_level(comms: Protocol) -> int:
    """Get the current brightness level for electronics supporting level control.

    Args:
        comms: reference to the com port object to use

    Returns:
        the current brightness level

    Info:
        See note for [`get_brightness_level_max`][wopcprotocol.brightness.get_brightness_level_max].
    """
    response = comms.send(command=Commands.GET_BRIGHTNESS_LEVEL, target=Targets.MCU)
    return int(unpack("<Bx", response.payload)[0])


def set_brightness_level(level: int, comms: Protocol) -> None:
    """Set the brightness level for electronics supporting level control.

    Args:
        level: the brightness level to set. The value must be in [0, [`get_brightness_level_max`][wopcprotocol.brightness.get_brightness_level_max])
        comms: reference to the com port object to use

    Note:
        See note for [`get_brightness_level_max`][wopcprotocol.brightness.get_brightness_level_max].
    """  # noqa: E501
    payload = pack("<B", level)
    comms.send(command=Commands.SET_BRIGHTNESS_LEVEL, target=Targets.MCU, payload=payload)


def get_led_state(side: Side, comms: Protocol) -> LedState:
    """Get the state of the LEDs.

    Args:
        side: the side of the projector (if applicable)
        comms: reference to the com port object to use

    Returns:
        the state of the LEDs
    """
    response = comms.send(command=Commands.GET_RGB_ENABLE, target=side)
    return LedState(
        red=(response.payload[0] & 0x1) != 0,
        green=(response.payload[0] & 0x2) != 0,
        blue=(response.payload[0] & 0x4) != 0,
        green2=(response.payload[0] & 0x8) != 0,
    )


def set_led_state(side: Side, state: LedState, comms: Protocol) -> None:
    """Set the state of the LEDs.

    Args:
        side: the side of the projector (if applicable)
        state: the state to set
        comms: reference to the com port object to use
    """
    payload = (int(state.red) << 0) | (int(state.green) << 1) | (int(state.blue) << 2) | (int(state.green2) << 3)
    comms.send(command=Commands.SET_RGB_ENABLE, target=side, payload=bytes([payload]))


def set_led_driver_rlim(side: Side, rlim: Rlim, comms: Protocol) -> None:
    """Set the active limiting resistor value for the LED driver.

    Args:
        side: the side of the projector (if applicable)
        rlim: the limiting resistor value to set
        comms: reference to the com port object to use

    Note:
        Every resistor value is associated to unique current-to-register calibration data.
        It is however possible that calibration data for some resistor values is not available
        as only a handful of common values are calibrated in production.

    Warning:
        Changing the limiting resistor value might raise the current consumption of the LEDs and damage them!
    """
    payload = pack("<BB", Hardware.LED_DRIVER_RLIM, rlim.value << 5)
    comms.send(command=Commands.SET_HARDWARE_STATE, target=side, payload=payload)
    # Invalidate the cached calibration data
    if side in comms.calibration:
        del comms.calibration[side]


def get_led_driver_rlim(side: Side, comms: Protocol) -> Rlim:
    """Get the active limiting resistor value for the LED driver.

    Args:
        side: the side of the projector (if applicable)
        comms: reference to the com port object to use

    Returns:
        the active limiting resistor value
    """
    response = comms.send(command=Commands.GET_HARDWARE_STATE, target=side, payload=bytes([Hardware.LED_DRIVER_RLIM]))
    # Payload is a set of bytes, shifting the 2nd byte by 5 leaves only the three most significant bits
    return Rlim(response.payload[1] >> 5)


def set_led_pwm_frequency(side: Side, frequency: int, comms: Protocol) -> None:
    """Set the PWM frequency for the LED driver.

    Args:
        side: the side of the projector (if applicable)
        frequency: the PWM frequency to set specified in Hz
        comms: reference to the com port object to use

    Note:
        This is generally not supported by projectors-driving electronics.
    """
    payload = pack("<H", frequency)
    comms.send(command=Commands.SET_PWM_FREQUENCY, target=side, payload=payload)


def get_led_pwm_frequency(side: Side, comms: Protocol) -> int:
    """Get the PWM frequency of the LED driver.

    Args:
        side: the side of the projector (if applicable)
        comms: reference to the com port object to use

    Returns:
        the PWM frequency in Hz

    Note:
        See note for [`set_led_pwm_frequency`][wopcprotocol.brightness.set_led_pwm_frequency].
    """
    response = comms.send(command=Commands.GET_PWM_FREQUENCY, target=side)
    return int(unpack("<H", response.payload[:2])[0])


def get_led_duty_cycle(side: Side, comms: Protocol) -> LedDutyCycle:
    """Get the duty cycle of the LEDs.

    Args:
        side: the side of the projector (if applicable)
        comms: reference to the com port object to use

    Returns:
        the duty cycle of the LEDs
    """
    response = comms.send(command=Commands.GET_RGB_DUTY, target=side)
    values = [float(v) for v in unpack("<BBBxxB", response.payload)]
    return LedDutyCycle(red=values[0], green=values[2], blue=values[1], green2=values[3])


def set_led_duty_cycle(side: Side, duty_cycle: LedDutyCycle, comms: Protocol) -> None:
    """Set the duty cycle of the LEDs.

    Args:
        side: the side of the projector (if applicable)
        duty_cycle: the duty cycle to set
        comms: reference to the com port object to use

    Note:
        See note for [`get_led_duty_cycle`][wopcprotocol.brightness.get_led_duty_cycle].
    """
    payload = pack(
        "<BBBxxB", round(duty_cycle.red), round(duty_cycle.blue), round(duty_cycle.green), round(duty_cycle.green2)
    )
    comms.send(command=Commands.SET_RGB_DUTY, target=side, payload=payload)


def read_led_current(side: Side, comms: Protocol) -> LedCurrent:
    """Measure the current through the LEDs.

    Args:
        side: the side of the projector (if applicable)
        comms: reference to the com port object to use

    Returns:
        the current through the LEDs

    Note:
        This function is not supported by all electronics.
    """
    response = comms.send(command=Commands.READ_RGB_CURRENT, target=side)
    values = [float(v) for v in unpack("<" + "H" * (len(response.payload) // 2), response.payload)]
    return LedCurrent(red=values[0], green=values[2], blue=values[1], green2=values[3] if len(values) >= 4 else None)


def read_led_voltage(side: Side, comms: Protocol) -> LedVoltage:
    """Measure the voltage across the LEDs.

    Args:
        side: the side of the projector (if applicable)
        comms: reference to the com port object to use

    Returns:
        the voltage across the LEDs

    Note:
        See note for [`read_led_current`][wopcprotocol.brightness.read_led_current].
    """
    response = comms.send(command=Commands.READ_RGB_VOLTAGE, target=side)
    values = [float(v) for v in unpack("<" + "H" * (len(response.payload) // 2), response.payload)]
    return LedVoltage(
        red=values[0],
        green=values[1],
        blue=values[2],
        green2=values[3] if len(values) >= 4 else 0.0,
        unit=VoltageUnit.mV,
    )


def run_led_test(side: Side, comms: Protocol) -> LedState:
    """Run a built-in test on the LEDs.

    Args:
        side: the side of the projector (if applicable)
        comms: reference to the com port object to use

    Returns:
        test result for the LEDs

    Note:
        See note for [`read_led_current`][wopcprotocol.brightness.read_led_current].

    Warning:
        The electronics will turn all LEDs on at a specific current for a short period of time
        until the test is completed. So be careful not to look directly at the LEDs or point them at something
        that could be damaged by the light.
    """
    response = comms.send(command=Commands.RUN_LED_TEST, target=side, timeout=2000)
    status = response.payload[0]
    return LedState(
        red=(status & 0x1) != 0, green=(status & 0x2) != 0, blue=(status & 0x4) != 0, green2=(status & 0x8) != 0
    )
