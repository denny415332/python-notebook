from dataclasses import dataclass
from enum import IntEnum
from struct import pack
from typing import ClassVar

from wopcprotocol.common import Side
from wopcprotocol.protocol import Commands, Hardware, Protocol, Targets
from wopcprotocol.raw_spi import SPIDevices
from wopcprotocol.raw_spi import write as spi_write


class NovaHalMode(IntEnum):
    """Mode of operation of the firmware in regards to Nova HAL."""

    UNKNOWN = 0
    """Unknown mode"""
    SPLASH_SCREEN = 1
    """The firmware is pushing predefined images to the panel w/o Nova HAL running"""
    NOVA_HAL = 2
    """The firmware is running Nova HAL"""


@dataclass
class NovaVoltages:
    """Nova voltages configuration.

    Args:
        v1: V1 voltage
        vpixel: Vpixel voltage
        color: color for which to set the voltages
    """

    class Color(IntEnum):
        """Color for which to set the voltages."""

        RED = 0
        """Red color"""
        GREEN = 1
        """Green color"""
        BLUE = 2
        """Blue color"""

    v1: float
    vpixel: float
    color: Color

    VCOM_MIN: ClassVar[float] = -4.684
    VCOM_RANGE: ClassVar[float] = 12.732
    VCOM_SCALE: ClassVar[float] = 2048
    VCOM_REG_CMD: ClassVar[int] = 0x0C000000

    VPIXEL_MIN: ClassVar[float] = 2.78
    VPIXEL_RANGE: ClassVar[float] = 2.2378
    VPIXEL_SCALE: ClassVar[float] = 256
    VPIXEL_REG_CMD: ClassVar[int] = 0x10000000

    @property
    def vcom_low(self) -> float:
        """Vcom low voltage."""
        return -self.v1

    @property
    def vcom_high(self) -> float:
        """Vcom high voltage."""
        return self.v1 + self.vpixel

    @property
    def _vcom_low_offset(self) -> int:
        return self.color.value * 2 + 4

    @property
    def _vcom_high_offset(self) -> int:
        return self.color.value * 2 + 3

    @property
    def _vpixel_offset(self) -> int:
        return self.color.value

    @classmethod
    def _calc_vcom_mem_reg(cls, vcom: float) -> int:
        step_1 = int((vcom - cls.VCOM_MIN) / cls.VCOM_RANGE * cls.VCOM_SCALE - 1)
        step_2 = step_1 << 8
        return step_2 + cls.VCOM_REG_CMD

    @classmethod
    def _calc_vpixel_mem_reg(cls, vpixel: float) -> int:
        step_1 = int((vpixel - cls.VPIXEL_MIN) / cls.VPIXEL_RANGE * cls.VPIXEL_SCALE)
        step_2 = step_1 << 8
        return step_2 + cls.VPIXEL_REG_CMD


def get_nova_hal_mode(comms: Protocol) -> NovaHalMode:
    """Returns the current mode of operation of the firmware in regards to Nova HAL.

    Args:
        comms: reference to the com port object to use

    Returns:
        mode of operation
    """
    response = comms.send(command=Commands.GET_HARDWARE_STATE, target=Targets.MCU, payload=bytes([Hardware.NOVA_HAL]))
    return NovaHalMode(response.payload[1])


def set_nova_hal_mode(mode: NovaHalMode, comms: Protocol) -> None:
    """Set the mode of operation of the firmware in regards to Nova HAL.

    Args:
        mode: the mode of operation to set
        comms: reference to the com port object to use

    Raises:
        ValueError: if the mode is not in `[NovaHalMode.SPLASH_SCREEN, NovaHalMode.NOVA_HAL]`
    """
    if mode not in [NovaHalMode.SPLASH_SCREEN, NovaHalMode.NOVA_HAL]:
        raise ValueError("invalid mode")
    comms.send(command=Commands.SET_HARDWARE_STATE, target=Targets.MCU, payload=bytes([Hardware.NOVA_HAL, mode.value]))


def set_nova_reg(*, side: Side, addr: int, data: int, comms: Protocol) -> None:
    """Set a register on Nova.

    Args:
        side: identifies the projector to set the register on
        addr: the address of the register to set
        data: the data to write to the register
        comms: reference to the com port object to use
    """
    spi_write(
        target=side,
        device=SPIDevices.PANEL_NOVA,
        addr=addr,
        data=pack("<I", data),
        comms=comms,
    )


def _nova_write_spimem1(*, comms: Protocol, side: Side, mem_addr: int, data1: int, data0: int) -> None:
    NOVA_SPIMEM_CH1_CTRL_ADDR = 0x5614
    NOVA_SPIMEM_CH1_DATA0_ADDR = 0x5620
    NOVA_SPIMEM_CH1_DATA1_ADDR = 0x5624
    # write data first and addr/ctrl last; write both instances
    set_nova_reg(comms=comms, side=side, addr=NOVA_SPIMEM_CH1_DATA1_ADDR, data=data1)
    set_nova_reg(comms=comms, side=side, addr=NOVA_SPIMEM_CH1_DATA0_ADDR, data=data0)
    set_nova_reg(comms=comms, side=side, addr=NOVA_SPIMEM_CH1_CTRL_ADDR, data=(mem_addr << 2) + 2)
    set_nova_reg(comms=comms, side=side, addr=NOVA_SPIMEM_CH1_CTRL_ADDR, data=(mem_addr << 2) + 0)


def set_nova_voltages(side: Side, voltages: NovaVoltages, comms: Protocol) -> None:
    """Set the voltages on Nova.

    Args:
        side: identifies the projector to set the voltages on
        voltages: the voltages to set
        comms: reference to the com port object to use
    """
    SPI_SEL_AURORA = 0xF
    # Vpixel
    _nova_write_spimem1(
        comms=comms,
        side=side,
        mem_addr=voltages._vpixel_offset,
        data1=SPI_SEL_AURORA,
        data0=NovaVoltages._calc_vpixel_mem_reg(voltages.vpixel),
    )
    # Vcom high
    _nova_write_spimem1(
        comms=comms,
        side=side,
        mem_addr=voltages._vcom_high_offset,
        data1=SPI_SEL_AURORA,
        data0=NovaVoltages._calc_vcom_mem_reg(voltages.vcom_high),
    )
    # Vcom low
    _nova_write_spimem1(
        comms=comms,
        side=side,
        mem_addr=voltages._vcom_low_offset,
        data1=SPI_SEL_AURORA,
        data0=NovaVoltages._calc_vcom_mem_reg(voltages.vcom_low),
    )
