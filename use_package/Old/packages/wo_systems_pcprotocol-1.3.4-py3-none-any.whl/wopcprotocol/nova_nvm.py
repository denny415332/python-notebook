"""This module contains the definitions of the nova NVM structure for all the different versions, along with methods for serialising/deserialising data.

!!! example "Examples"
    === "Write"
        ``` python
        from wopcprotocol.protocol import Protocol
        from wopcprotocol.common import Side
        from wopcprotocol.nova_nvm import nvm_get_customer_block_address, CPNvmV2, WhitePoint, SequenceType, BrtLevel, OpticalEngine, nvm_write
        import time

        comms = Protocol()
        page = nvm_get_customer_block_address(0)
        side = Side.RIGHT
        led_flex_id = 12345
        alignHoriz = 0
        alignVert = 0
        brt_levels = [
            BrtLevel(nits=0,
                    white_point=WhitePoint.SNAP_V3,
                    sequence=SequenceType.PROTOA_V2_1008P,
                    red_current=100,
                    green_current=100,
                    blue_current=100),
            BrtLevel(nits=0,
                    white_point=WhitePoint.SNAP_V3,
                    sequence=SequenceType.PROTOA_V2_1008P,
                    red_current=100,
                    green_current=100,
                    blue_current=100),
            BrtLevel(nits=0,
                    white_point=WhitePoint.SNAP_V3,
                    sequence=SequenceType.PROTOA_V2_1008P,
                    red_current=100,
                    green_current=100,
                    blue_current=100),
            BrtLevel(nits=0,
                    white_point=WhitePoint.SNAP_V3,
                    sequence=SequenceType.PROTOA_V2_1008P,
                    red_current=100,
                    green_current=100,
                    blue_current=100),
            BrtLevel(nits=0,
                    white_point=WhitePoint.SNAP_V3,
                    sequence=SequenceType.PROTOA_V2_1008P,
                    red_current=100,
                    green_current=100,
                    blue_current=100)
        ]

        color_coordinates = {
            'red_led_x': 0.0,
            'red_led_y': 0.0,
            'green_led_x': 0.0,
            'green_led_y': 0.0,
            'blue_led_x': 0.0,
            'blue_led_y': 0.0
        }
        nvm = CPNvmV2(oe_ver=OpticalEngine.PROTOA_AVALON_CONFIG1,
                    alignH=alignHoriz,
                    alignV=alignVert,
                    time_tag=time.time(),
                    led_flex_id=led_flex_id,
                    brt_levels=brt_levels,
                    **color_coordinates)
        nvm_write(page=page, side=side, data=nvm.pack(), comms=comms)
        comms.close()
        ```

    === "Read"
        ``` python
        from wopcprotocol.protocol import Protocol
        from wopcprotocol.common import Side
        from wopcprotocol.nova_nvm import CPNvm, nvm_get_customer_block_address, nvm_read

        comms = Protocol()
        page = nvm_get_customer_block_address(0)
        side = Side.RIGHT

        nvm = CPNvm.unpack(nvm_read(page=page, side=side, length=124, comms=comms))
        print(nvm)
        comms.close()
        ```

    === "Read Serial Number"
        ``` python
        from wopcprotocol.protocol import Protocol
        from wopcprotocol.common import Side
        from wopcprotocol.nova_nvm import nvm_read_serial_number

        print(nvm_read_serial_number(side=Side.RIGHT, comms=Protocol()))
        ```
"""  # noqa: E501

from __future__ import annotations

import contextlib
import logging
import struct
from collections.abc import Sequence  # noqa: TCH003
from dataclasses import dataclass, field
from enum import IntEnum
from math import isclose
from typing import TYPE_CHECKING, ClassVar

from wopcprotocol.common import CommandResponse, Side  # noqa: TCH001
from wopcprotocol.eeprom import EEPROMCommands
from wopcprotocol.errors import NotAcknowledgedError, WOPCProtocolError
from wopcprotocol.protocol import Commands, Electronics, Protocol

if TYPE_CHECKING:
    from typing_extensions import Self

###################################################################
########################### VERSION 2 #############################
###################################################################

#  0                   1                   2                   3
#  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |   Header_Ver  |   OEVersion   |     AlignH    |     AlignV    |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                           BuildTime                           |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                       LED Flex Serial No                      |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |  Nits (lvl4)  | WPoint| SeqNo |          Red Current          |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |         Green Current         |          Blue Current         |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |  Nits (lvl3)  | WPoint| SeqNo |          Red Current          |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |         Green Current         |          Blue Current         |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |  Nits (lvl2)  | WPoint| SeqNo |          Red Current          |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |         Green Current         |          Blue Current         |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |  Nits (lvl1)  | WPoint| SeqNo |          Red Current          |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |         Green Current         |          Blue Current         |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |  Nits (lvl0)  | WPoint| SeqNo |          Red Current          |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |         Green Current         |          Blue Current         |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                            Reserved                           |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                            Reserved                           |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                          Red LED 'x'                          |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                          Red LED 'y'                          |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                         Green LED 'x'                         |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                         Green LED 'y'                         |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                          Blue LED 'x'                         |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                          Blue LED 'y'                         |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

###################################################################
########################### VERSION 1 #############################
###################################################################
# Note: the original definition had 6 brightness levels, but only 5
# were ever used so..

#  0                   1                   2                   3
#  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |   Header_Ver  |   OEVersion   |     AlignH    |     AlignV    |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                           BuildTime                           |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                          Projector ID                         |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |      Nits     | WPoint| SeqNo |              Red              |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |             Green             |              Blue             |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |      Nits     | WPoint| SeqNo |              Red              |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |             Green             |              Blue             |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |      Nits     | WPoint| SeqNo |              Red              |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |             Green             |              Blue             |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |      Nits     | WPoint| SeqNo |              Red              |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |             Green             |              Blue             |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |      Nits     | WPoint| SeqNo |              Red              |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |             Green             |              Blue             |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

logger = logging.getLogger(__name__)

NVM_CUSTOMER_BLOCK = 0x80
"""The page address of the customer block in the NVM"""
NVM_MANUFACTURER_BLOCK = 0x20
"""The page address of the manufacturer block in the NVM"""


class NovaError(WOPCProtocolError):
    """Exception raised when an error occurs in Nova HAL."""

    class NovaStatusCode(IntEnum):
        """Nova HAL error codes. For the full description of each error code, see the Nova HAL documentation."""

        NOT_RETURNED = -1
        NVM_READ_PARAM_INVALID = 65
        NVM_WRITE_PARAM_INVALID = 66
        NVM_WRITE_NO_KEY_FAILED = 67
        NVM_WRITE_FAILED = 68
        NVM_READ_TIMEOUT = 69
        NVM_WRITE_TIMEOUT = 70
        NVM_READ_BUSY = 71
        NVM_WRITE_BUSY = 72
        NVM_NOT_INITIALIZED = 73

    def __init__(self, status_code: int) -> None:
        self.status_code = status_code
        try:
            super().__init__(f"{self.NovaStatusCode(status_code).name}")
        except ValueError:
            super().__init__(f"error code {status_code}")


class OpticalEngine(IntEnum):
    """The optical engine version."""

    COMPONENT_BUILD_SATURN_ILLUMINATION = 0x00
    """Saturn illumination for component build"""
    COMPONENT_BUILD_AVALON_ILLUMINATION = 0x01
    """Avalon illumination for component build"""
    PROTOA_AVALON_CONFIG1 = 0x02
    """Avalon config 1 for protoA"""
    PROTOA_AVALON = 0x02
    """Avalon for protoA (alias of `PROTOA_AVALON_CONFIG1`)"""
    UNDEFINED = 0xFF
    """Undefined"""


class WhitePoint(IntEnum):
    """The type of white point used during calibration."""

    D65 = 0x00
    """D65"""
    SNAP_CB = 0x01
    """Snap for component build"""
    SNAP_V2 = 0x02
    """Snap v2"""
    SNAP_V3 = 0x03
    """Snap v3"""
    UNDEFINED = 0xF
    """Undefined"""


class SequenceType(IntEnum):
    """The sequence used during calibration."""

    MERCURY = 0x00
    """Mercury"""
    CB_1007P = 0x01
    """Component build 1007p"""
    PROTOA_V2_1008P = 0x02
    """ProtoA v2 1008p"""
    PROTOA_V6_1008P = 0x03
    """ProtoA v6 1008p"""
    PROTOA_V7_1008P = 0x04
    """ProtoA v7 1008p"""
    PROTOA_V8_1008P = 0x05
    """ProtoA v8 1008p"""


def nvm_get_customer_block_address(block: int) -> int:
    """Returns the address of the specified block in the customer blocks.

    Args:
        block: block number

    Returns:
        int: address of the specified block
    """
    return NVM_CUSTOMER_BLOCK + block


def nvm_get_manufacturer_block_address(block: int) -> int:
    """Returns the address of the specified block in the manufacturer blocks.

    Args:
        block: block number

    Returns:
        int: address of the specified block
    """
    return NVM_MANUFACTURER_BLOCK + block


@dataclass(kw_only=True)
class BrtLevel:
    """Object representing a brightness level in the NVM.

    Args:
        nits: brightness in nits multiplied by 10
        white_point: white point used during calibration
        sequence: sequence used during calibration
        red_current: red current in mA multiplied by 100
        green_current: green current in mA multiplied by 100
        blue_current: blue current in mA multiplied by 100
    """

    nits: int
    white_point: WhitePoint
    sequence: SequenceType
    red_current: int
    green_current: int
    blue_current: int

    # Size when packed
    SIZE: ClassVar[int] = 8

    def pack(self) -> bytes:
        """Serialises the object into a byte stream.

        Returns:
            serialised object
        """
        return struct.pack(
            "<BBHHH",
            self.nits,
            (self.white_point & 0x0F) | (self.sequence << 4),
            self.red_current,
            self.green_current,
            self.blue_current,
        )

    @classmethod
    def unpack(cls, data: bytes) -> Self:
        """Deserialises a byte stream into an object.

        Args:
            data: byte stream to deserialise

        Returns:
            deserialised object

        Raises:
            ValueError: if the byte stream is not the correct size
        """
        if len(data) != cls.SIZE:
            raise ValueError(f"unpack requires a buffer of {cls.SIZE} bytes")
        parsed_data = struct.unpack("<BBHHH", data)
        return cls(
            nits=parsed_data[0],
            white_point=WhitePoint(parsed_data[1] & 0x0F),
            sequence=SequenceType(parsed_data[1] >> 4),
            red_current=parsed_data[2],
            green_current=parsed_data[3],
            blue_current=parsed_data[4],
        )

    @classmethod
    def pack_multiple(cls, brt_levels: Sequence[Self], levels: int) -> bytes:
        """Serialises a list of brightness levels into a byte stream.

        Args:
            brt_levels: list of brightness levels
            levels: number of brightness levels

        Returns:
            serialised object

        Raises:
            ValueError: if the number of brightness levels is not equal to `levels`
        """
        if len(brt_levels) != levels:
            raise ValueError(f"the number of brightness levels must be {levels}")
        data = b""
        for level in brt_levels:
            data += level.pack()
        return data

    @classmethod
    def unpack_multiple(cls, data: bytes, levels: int) -> list[Self]:
        """Deserialises a byte stream into a list of brightness levels.

        Args:
            data: byte stream to deserialise
            levels: number of brightness levels

        Returns:
            list of brightness level objects
        """
        if len(data) != levels * cls.SIZE:
            raise ValueError(f"unpack requires a buffer of {levels * cls.SIZE} bytes")
        return [cls.unpack(data[i * cls.SIZE : (i + 1) * cls.SIZE]) for i in range(levels)]


@dataclass
class CPNvm:
    """Base class for the object representing the memory layout of the nova NVM.

    Args:
        header_ver: version of the memory layout
        oe_ver: optical engine version
        alignH: horizontal alignment
        alignV: vertical alignment
        time_tag: time when the NVM was written
        brt_levels: list of brightness levels

    """

    header_ver: int
    oe_ver: OpticalEngine
    alignH: int
    alignV: int
    time_tag: int
    brt_levels: list[BrtLevel]

    def pack(self) -> bytes:
        """Serialises the object into a byte stream.

        Returns:
            serialised object

        Raises:
            NotImplementedError: the base class does not implement this method
        """
        raise NotImplementedError

    @classmethod
    def unpack(cls, data: bytes) -> CPNvm:
        """Deserialises a byte stream into an object.

        Args:
            data: byte stream to deserialise

        Raises:
            ValueError: if the header version is not recognised
        """
        header_version = data[0]
        if header_version == CPNvmV1.VERSION_NUMBER:
            return CPNvmV1.unpack(data)
        if header_version == CPNvmV2.VERSION_NUMBER:
            return CPNvmV2.unpack(data)
        raise ValueError("nvm header version not recognised")


@dataclass
class CPNvmV1(CPNvm):
    """Version 1 of the nova NVM.

    Args:
        projector_id: projector ID

    """

    header_ver: int = field(init=False, default=1)
    projector_id: int

    # Constants
    VERSION_NUMBER: ClassVar[int] = 1
    BRT_LEVELS: ClassVar[int] = 5
    # 12 = (Header_Ver | OEVersion | AlignH | AlignV) + BuildTime + ProjectorID
    SIZE: ClassVar[int] = 12 + BrtLevel.SIZE * BRT_LEVELS

    def pack(self) -> bytes:
        """Serialises the object into a byte stream.

        Returns:
            serialised object
        """
        data = struct.pack(
            "<BBbbLL", self.header_ver, self.oe_ver, self.alignH, self.alignV, int(self.time_tag), self.projector_id
        )
        data += BrtLevel.pack_multiple(self.brt_levels, self.BRT_LEVELS)
        return data

    @classmethod
    def unpack(cls, data: bytes) -> Self:
        """Deserialises a byte stream into an object.

        Args:
            data: byte stream to deserialise

        Raises:
            ValueError: if the header version is not recognised or the byte stream is not the correct size
        """
        # Check size
        if len(data) != cls.SIZE:
            raise ValueError(f"unpack requires a buffer of {cls.SIZE} bytes")
        # Check header version
        if data[0] != cls.VERSION_NUMBER:
            raise ValueError(f"wrong version number: got {data[0]}, expected {cls.VERSION_NUMBER}")

        data_unpacked = struct.unpack("<BBbbLL", data[:12])
        brt_levels = BrtLevel.unpack_multiple(data[12:], cls.BRT_LEVELS)
        return cls(
            oe_ver=OpticalEngine(data_unpacked[1]),
            alignH=data_unpacked[2],
            alignV=data_unpacked[3],
            time_tag=int(data_unpacked[4]),
            projector_id=data_unpacked[5],
            brt_levels=brt_levels,
        )


@dataclass
class CPNvmV2(CPNvm):
    """Version 2 of the nova NVM.

    Args:
        led_flex_id: LED flex serial number
        red_led_x: x coordinate of the red LED
        red_led_y: y coordinate of the red LED
        green_led_x: x coordinate of the green LED
        green_led_y: y coordinate of the green LED
        blue_led_x: x coordinate of the blue LED
        blue_led_y: y coordinate of the blue LED

    """

    header_ver: int = field(init=False, default=2)
    led_flex_id: int
    red_led_x: float
    red_led_y: float
    green_led_x: float
    green_led_y: float
    blue_led_x: float
    blue_led_y: float

    # Constants
    VERSION_NUMBER: ClassVar[int] = 2
    BRT_LEVELS: ClassVar[int] = 5
    # 12 = (Header_Ver | OEVersion | AlignH | AlignV) + BuildTime + ProjectorID
    # 32 = Reserved Word + Reserved Word + Red_x + Red_y + Green_x + Green_y + Blue_x + Blue_y
    SIZE: ClassVar[int] = 12 + BrtLevel.SIZE * BRT_LEVELS + 32

    def pack(self) -> bytes:
        """Serialises the object into a byte stream.

        Returns:
            serialised object
        """
        data = bytes(
            struct.pack(
                "<BBbbLL", self.header_ver, self.oe_ver, self.alignH, self.alignV, int(self.time_tag), self.led_flex_id
            )
        )
        data += BrtLevel.pack_multiple(self.brt_levels, self.BRT_LEVELS)
        # 8 reserved bytes
        data += struct.pack("<II", 0xFFFFFFFF, 0xFFFFFFFF)
        # Color coordinates
        data += struct.pack(
            "<ffffff",
            self.red_led_x,
            self.red_led_y,
            self.green_led_x,
            self.green_led_y,
            self.blue_led_x,
            self.blue_led_y,
        )
        return data

    @classmethod
    def unpack(cls, data: bytes) -> Self:
        """Deserialises a byte stream into an object.

        Args:
            data: byte stream to deserialise

        Raises:
            ValueError: if the header version is not recognised or the byte stream is not the correct size
        """
        if len(data) != cls.SIZE:
            raise ValueError(f"unpack requires a buffer of {cls.SIZE} bytes")
        # Check header version
        if data[0] != cls.VERSION_NUMBER:
            raise ValueError(f"wrong version number: got {data[0]}, expected {cls.VERSION_NUMBER}")

        # Unpack data before and after brightness levels
        data_unpacked_0 = struct.unpack("<BBbbLL", data[:12])
        data_unpacked_1 = struct.unpack("<ffffff", data[12 + cls.BRT_LEVELS * BrtLevel.SIZE + 8 :])

        # Parse brightness levels
        brt_levels = BrtLevel.unpack_multiple(data[12 : 12 + cls.BRT_LEVELS * BrtLevel.SIZE], cls.BRT_LEVELS)

        return cls(
            oe_ver=OpticalEngine(data_unpacked_0[1]),
            alignH=data_unpacked_0[2],
            alignV=data_unpacked_0[3],
            time_tag=int(data_unpacked_0[4]),
            led_flex_id=data_unpacked_0[5],
            brt_levels=brt_levels,
            red_led_x=data_unpacked_1[0],
            red_led_y=data_unpacked_1[1],
            green_led_x=data_unpacked_1[2],
            green_led_y=data_unpacked_1[3],
            blue_led_x=data_unpacked_1[4],
            blue_led_y=data_unpacked_1[5],
        )

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, CPNvmV2):
            raise TypeError
        return (
            self.oe_ver == other.oe_ver
            and self.alignH == other.alignH
            and self.alignV == other.alignV
            and self.time_tag == other.time_tag
            and self.led_flex_id == other.led_flex_id
            and self.brt_levels == other.brt_levels
            and isclose(self.red_led_x, other.red_led_x, abs_tol=1e-6)
            and isclose(self.red_led_y, other.red_led_y, abs_tol=1e-6)
            and isclose(self.green_led_x, other.green_led_x, abs_tol=1e-6)
            and isclose(self.green_led_y, other.green_led_y, abs_tol=1e-6)
            and isclose(self.blue_led_x, other.blue_led_x, abs_tol=1e-6)
            and isclose(self.blue_led_y, other.blue_led_y, abs_tol=1e-6)
        )


@dataclass
class CPNvmLatest(CPNvmV2):
    """Latest version of the nova NVM."""


# payload format:
# [0]: read = 0x02, write=0x03
# [1]: 0x00 = Master, 0x20 = Mfg, 0x40 = Uniformity, 0x80~0x9f = Customer
# [3]: 0x00
# [4]: length
# write nvm


def _nvm_use_new_format(comms: Protocol) -> bool:
    # For fw <= 0.12.11 (build number 1048) of spectre the format of the payload is different
    return not (
        comms.electronics == Electronics.SPECTRE
        and comms.firmware_version.build_number > 0
        and comms.firmware_version.build_number <= 1048
    )


def _nvm_access(*, page: int, side: Side, data: bytes | None, length: int | None, comms: Protocol) -> CommandResponse:
    if data is not None:
        # write
        payload = bytes([EEPROMCommands.EEPROM_WRITE_ARRAY])
        if _nvm_use_new_format(comms):
            payload += struct.pack("<BBH", page, len(data), 0)
        else:
            payload += struct.pack("<HB", page, len(data))
        payload += data
    elif length is not None:
        # read
        payload = bytes([EEPROMCommands.EEPROM_READ_ARRAY])
        if _nvm_use_new_format(comms):
            payload += struct.pack("<BBH", page, length, 0)
        else:
            payload += struct.pack("<HB", page, length)
    else:
        # invalidate
        payload = bytes([EEPROMCommands.EEPROM_INVALIDATE])
        payload += struct.pack("<B", page)
    try:
        return comms.send(command=Commands.EEPROM_UPDATE, target=side | 0x80, payload=payload)
    except NotAcknowledgedError as e:
        # The new format includes an error code in the response
        if _nvm_use_new_format(comms):
            raise NovaError(
                NovaError.NovaStatusCode.NOT_RETURNED
                if e.response is None
                else int.from_bytes(e.response.payload[3:5], byteorder="little")
            ) from e
        raise


def nvm_write(*, page: int, side: Side, data: bytes, comms: Protocol) -> None:
    """Writes data to the NVM.

    Args:
        page: address of the page to write to
        side: identify the projector to write to
        data: data to write
        comms: reference to the comms object

    Raises:
        NovaError: if the NVM write fails
    """
    _nvm_access(page=page, side=side, data=data, length=len(data), comms=comms)


def nvm_read(*, page: int, side: Side, length: int, comms: Protocol) -> bytes:
    """Reads data from the NVM.

    Args:
        page: address of the page to read from
        side: identify the projector to read from
        length: number of bytes to read
        comms: reference to the comms object

    Returns:
        data read from the NVM

    Raises:
        NovaError: if the NVM read fails
    """
    response = _nvm_access(page=page, side=side, data=None, length=length, comms=comms)
    data = response.payload[5:] if _nvm_use_new_format(comms) else response.payload[4:]
    logger.debug(f"nvm read: [{data.hex(',')}]")
    return data


def nvm_invalidate(page: int, side: Side, comms: Protocol) -> None:
    """Invalidates a NVM page.

    Args:
        page: address of the page to invalidate
        side: identify the projector to invalidate the page for
        comms: reference to the comms object

    Raises:
        NovaError: if the NVM invalidate fails

    Warning:
        The function fails if the page has not been written before or already invalidated
    """
    _nvm_access(page=page, side=side, data=None, length=None, comms=comms)


def nvm_read_serial_number(side: Side, comms: Protocol) -> bytes:
    """Reads the serial number from the NVM.

    Args:
        side: identify the projector to read from
        comms: reference to the comms object

    Returns:
        serial number
    """
    data = nvm_read(page=nvm_get_manufacturer_block_address(3), side=side, length=124, comms=comms)
    return data[6:]


def nvm_read_scribe_id(side: Side, comms: Protocol) -> bytes:
    """Reads the scribe ID from the NVM.

    Args:
        side: identify the projector to read from
        comms: reference to the comms object

    Returns:
        scribe ID
    """
    data = nvm_read(page=nvm_get_manufacturer_block_address(0), side=side, length=124, comms=comms)
    # From V2 onwards the scrive ID is 11 characters long, before it was 8
    header = int(data[4:6])
    return data[-11:] if header >= 2 else data[-8:]


def nvm_read_panel_uid(side: Side, comms: Protocol) -> bytes:
    """Reads the panel Unique ID (UID) from the NVM.

    Args:
        side: identify the projector to read from
        comms: reference to the comms object

    Returns:
        panel UID

    Note:
        The panel UID is made of the concatenation of the serial number and the scribe ID
    """
    serial_number = b""

    with contextlib.suppress(NovaError, NotAcknowledgedError):
        serial_number = nvm_read_serial_number(side=side, comms=comms)
    return serial_number + nvm_read_scribe_id(side=side, comms=comms)
