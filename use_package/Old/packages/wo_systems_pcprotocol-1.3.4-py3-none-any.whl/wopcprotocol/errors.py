"""This module contains the exceptions used in the package."""

from wopcprotocol.common import CommandResponse


class WOPCProtocolError(Exception):
    """Base class for exceptions in this module."""


class DeviceNotFoundError(WOPCProtocolError):
    """Raised when the device is not found."""


class UncalibratedElectronicsError(WOPCProtocolError):
    """Raised when pulling register/current data from an uncalibrated electronics."""


class SequenceNotFoundError(WOPCProtocolError):
    """Raised when meta information for the sequence cannot be retrieved."""


class ProtocolError(WOPCProtocolError):
    """Raised when an error is detected in the serial communication protocol."""


class NoResponseError(ProtocolError):
    """Raised when no response is received from the electronics."""


class NotAcknowledgedError(ProtocolError):
    """Raised when the electronics returns a NACK."""

    def __init__(self, response: CommandResponse | None = None, message: str = "") -> None:
        super().__init__(message)
        self.response = response


class OutOfSequenceError(ProtocolError):
    """Raised when the received command does not match the expected command."""


class PacketLengthError(ProtocolError):
    """Raised when the length of the received packet does not match the expected length."""


class CrcError(ProtocolError):
    """Raised when the received CRC does not match the expected CRC."""
