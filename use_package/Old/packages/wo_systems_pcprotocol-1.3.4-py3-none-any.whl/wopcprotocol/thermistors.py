import math
from dataclasses import dataclass


def ohm_to_celsius(
    *,
    resistance: float,
    temperature_nominal: float = 25.0,
    resistance_nominal: float = 10000.0,
    bcoefficient: float = 3435.0,
) -> float:
    """Convert resistance to temperature in Celsius using the Steinhart-Hart equation.

    Args:
        resistance: resistance of the thermistor
        temperature_nominal: temperature for nominal resistance
        resistance_nominal: nominal resistance of the thermistor
        bcoefficient: beta coefficient of the thermistor
    """
    if resistance <= 0:
        raise ValueError("resistance must be >= 0")
    # using https://en.wikipedia.org/wiki/Thermistor#B_or_%CE%B2_parameter_equation
    # temp. for nominal resistance (almost always 25 C)
    # The beta coefficient of the thermistor (usually 3000-4000)
    # Default refers to ERTJ0EG103FA B25/85
    steinhart = resistance / resistance_nominal
    steinhart = math.log(steinhart)
    steinhart /= bcoefficient
    steinhart += 1 / (temperature_nominal + 273.15)  # + (1/To)
    steinhart = 1 / steinhart  # Invert
    steinhart -= 273.15  # convert to C
    return steinhart


@dataclass(frozen=True, kw_only=True)
class Thermistor:
    """Dataclass describing a thermistor.

    Args:
        name: name of the thermistor
        beta: beta coefficient of the thermistor
        temperature_nominal: temperature for nominal resistance
        resistance_nominal: nominal resistance of the thermistor
    """

    name: str
    beta: float
    temperature_nominal: float
    resistance_nominal: float

    def ohm_to_celsius(self, resistance: float) -> float:
        """Convert resistance to temperature in Celsius using the Steinhart-Hart equation.

        Args:
            resistance: resistance of the thermistor
        """
        return ohm_to_celsius(
            resistance=resistance,
            temperature_nominal=self.temperature_nominal,
            resistance_nominal=self.resistance_nominal,
            bcoefficient=self.beta,
        )


THERMISTORS = {
    "ERTJ0EG103FA": Thermistor(name="ERTJ0EG103FA", beta=3435.0, temperature_nominal=25.0, resistance_nominal=10000.0),
    "NTCG064EF104FTBX": Thermistor(
        name="NTCG064EF104FTBX", beta=4308.0, temperature_nominal=25.0, resistance_nominal=100000.0
    ),
}
