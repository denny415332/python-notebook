"""This module provides functions to set the splash screen and test patterns on the connected projector."""

import logging
from enum import IntEnum

from wopcprotocol.common import Side
from wopcprotocol.protocol import Commands, Protocol

logger = logging.getLogger(__name__)


class SplashScreen(IntEnum):
    """The splash screens available on the projector."""

    VIDEO_IN = 0x00
    """Show video input"""
    DEFAULT = 0x02
    """Default splash screen"""
    MTF_1 = 0x03
    """MTF test pattern 1"""
    MTF_2 = 0x04
    """MTF test pattern 2"""
    CROSS_1 = 0x05
    """Cross test pattern 1"""
    CROSS_2 = 0x06
    """Cross test pattern 2"""
    MTF_GRID = 0x07
    """MTF grid"""
    CROSS_1_CENTRE = 0x08
    """Centered cross 1"""
    CROSS_2_CENTRE = 0x09
    """Centered cross 2"""
    CROSS_1_3DEG_ALIGN = 0x0A
    """3 degree aligned cross 1"""
    CROSS_2_3DEG_ALIGN = 0x0B
    """3 degree aligned cross 2"""
    WHITE = 0x10
    """Flat white"""
    BLACK = 0x11
    """Flat black"""
    ANSI = 0x12
    """ANSI test pattern"""
    MTFH2 = 0x13
    """MTF horizontal 2"""
    MTFV2 = 0x14
    """MTF vertical 2"""
    MICHELSON = 0x15
    """Michelson contrast pattern"""
    CROSS = 0x16
    """Cross test pattern"""


class TestPatterns(IntEnum):
    """The test patterns available on the projector."""

    WHITE = 0x01
    """Flat white"""
    RED = 0x02
    """Flat red"""
    GREEN = 0x03
    """Flat green"""
    BLUE = 0x04
    """Flat blue"""
    BLACK = 0x08
    """Flat black"""
    CYAN = 0x09
    """Flat cyan"""
    YELLOW = 0x0A
    """Flat yellow"""
    COLOR_BARS = 0x00
    """Color bars"""
    RAMP_HORIZ = 0x05
    """Gradient from black to white horizontally"""
    RAMP_VERT = 0x0B
    """Gradient from black to white vertically"""
    LINES_HORIZ = 0x0C
    """Horizontal lines"""
    LINES_VERT = 0x0D
    """Vertical lines"""
    LINES_DIAG = 0x0E
    """Diagonal lines"""
    GRID = 0x06
    """Grid"""
    CHECKERBOARD = 0x07
    """Checkerboard"""
    CHECKERBOARD2 = 0xFF
    """Checkerboard 2"""


def set_splash_screen(side: Side, splash_screen: SplashScreen | int, comms: Protocol) -> None:
    """Set the splash screen on the projector.

    Args:
        side: the side of the projector to set
        splash_screen: the splash screen to set
        comms: reference to the com port object to use

    Note:
        The splash screen can be set by index or by name (enum).
        However, names might change between firmware versions and loaded sequences.
    """
    comms.send(command=Commands.SET_INPUT_SOURCE, target=side, payload=bytes([splash_screen]))


def set_test_pattern(*, side: Side, pattern: TestPatterns | int, comms: Protocol) -> None:
    """Set the test pattern on the projector.

    Args:
        side: the side of the projector to set
        pattern: the test pattern to set
        comms: reference to the com port object to use

    Warning:
        The test pattern can be set by index or by name (enum).
        However, names might change between firmware versions and only a subset of the patterns might be available.
    """
    comms.send(command=Commands.SET_TEST_PATTERN, target=side, payload=bytes([pattern]))
