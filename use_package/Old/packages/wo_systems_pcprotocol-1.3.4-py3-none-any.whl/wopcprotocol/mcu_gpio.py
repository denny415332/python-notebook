"""This module defines the GPIO pins available on the MCU and provides functions to read and write to them.

Note that the direction of the pins is set in the firmware and cannot be changed from the host.

!!! example "Examples"
    === "Read"
        ``` python
        import wopcprotocol.mcu_gpio import McuPin, mcu_gpio_read_pin

        # Open the com port
        comms = Protocol()

        pin = McuPin.PB_2
        if mcu_gpio_read_pin(pin, comms):
            print(f"{pin} is high")
        else:
            print(f"{pin} is low")

        ```
    === "Write"
        ``` python
        from wopcprotocol.mcu_gpio import McuPin, mcu_gpio_write_pin
        from wopcprotocol.protocol import Protocol

        # Open the com port
        comms = Protocol()

        pin = McuPin.PA_0
        mcu_gpio_write_pin(pin, True, comms)
        ```
"""

from dataclasses import dataclass
from enum import Enum, IntEnum

from wopcprotocol.protocol import Commands, Hardware, Protocol, Targets


class _McuGPIOPort(IntEnum):
    PORTA = 0
    PORTB = 1
    PORTC = 2
    PORTD = 3
    PORTE = 4
    PORTF = 5
    PORTG = 6
    PORTH = 7


@dataclass(frozen=True)
class _McuGPIOPin:
    port: _McuGPIOPort
    pin: int


class McuPin(Enum):
    """Defines the pins available on the MCU."""

    # PORTA
    PA_0 = _McuGPIOPin(_McuGPIOPort.PORTA, 0)
    PA_1 = _McuGPIOPin(_McuGPIOPort.PORTA, 1)
    PA_2 = _McuGPIOPin(_McuGPIOPort.PORTA, 2)
    PA_3 = _McuGPIOPin(_McuGPIOPort.PORTA, 3)
    PA_4 = _McuGPIOPin(_McuGPIOPort.PORTA, 4)
    PA_5 = _McuGPIOPin(_McuGPIOPort.PORTA, 5)
    PA_6 = _McuGPIOPin(_McuGPIOPort.PORTA, 6)
    PA_7 = _McuGPIOPin(_McuGPIOPort.PORTA, 7)
    PA_8 = _McuGPIOPin(_McuGPIOPort.PORTA, 8)
    PA_9 = _McuGPIOPin(_McuGPIOPort.PORTA, 9)
    PA_10 = _McuGPIOPin(_McuGPIOPort.PORTA, 10)
    PA_11 = _McuGPIOPin(_McuGPIOPort.PORTA, 11)
    PA_12 = _McuGPIOPin(_McuGPIOPort.PORTA, 12)
    PA_13 = _McuGPIOPin(_McuGPIOPort.PORTA, 13)
    PA_14 = _McuGPIOPin(_McuGPIOPort.PORTA, 14)
    PA_15 = _McuGPIOPin(_McuGPIOPort.PORTA, 15)
    # PORTB
    PB_0 = _McuGPIOPin(_McuGPIOPort.PORTB, 0)
    PB_1 = _McuGPIOPin(_McuGPIOPort.PORTB, 1)
    PB_2 = _McuGPIOPin(_McuGPIOPort.PORTB, 2)
    PB_3 = _McuGPIOPin(_McuGPIOPort.PORTB, 3)
    PB_4 = _McuGPIOPin(_McuGPIOPort.PORTB, 4)
    PB_5 = _McuGPIOPin(_McuGPIOPort.PORTB, 5)
    PB_6 = _McuGPIOPin(_McuGPIOPort.PORTB, 6)
    PB_7 = _McuGPIOPin(_McuGPIOPort.PORTB, 7)
    PB_8 = _McuGPIOPin(_McuGPIOPort.PORTB, 8)
    PB_9 = _McuGPIOPin(_McuGPIOPort.PORTB, 9)
    PB_10 = _McuGPIOPin(_McuGPIOPort.PORTB, 10)
    PB_11 = _McuGPIOPin(_McuGPIOPort.PORTB, 11)
    PB_12 = _McuGPIOPin(_McuGPIOPort.PORTB, 12)
    PB_13 = _McuGPIOPin(_McuGPIOPort.PORTB, 13)
    PB_14 = _McuGPIOPin(_McuGPIOPort.PORTB, 14)
    PB_15 = _McuGPIOPin(_McuGPIOPort.PORTB, 15)
    # PORTC
    PC_0 = _McuGPIOPin(_McuGPIOPort.PORTC, 0)
    PC_1 = _McuGPIOPin(_McuGPIOPort.PORTC, 1)
    PC_2 = _McuGPIOPin(_McuGPIOPort.PORTC, 2)
    PC_3 = _McuGPIOPin(_McuGPIOPort.PORTC, 3)
    PC_4 = _McuGPIOPin(_McuGPIOPort.PORTC, 4)
    PC_5 = _McuGPIOPin(_McuGPIOPort.PORTC, 5)
    PC_6 = _McuGPIOPin(_McuGPIOPort.PORTC, 6)
    PC_7 = _McuGPIOPin(_McuGPIOPort.PORTC, 7)
    PC_8 = _McuGPIOPin(_McuGPIOPort.PORTC, 8)
    PC_9 = _McuGPIOPin(_McuGPIOPort.PORTC, 9)
    PC_10 = _McuGPIOPin(_McuGPIOPort.PORTC, 10)
    PC_11 = _McuGPIOPin(_McuGPIOPort.PORTC, 11)
    PC_12 = _McuGPIOPin(_McuGPIOPort.PORTC, 12)
    PC_13 = _McuGPIOPin(_McuGPIOPort.PORTC, 13)
    PC_14 = _McuGPIOPin(_McuGPIOPort.PORTC, 14)
    PC_15 = _McuGPIOPin(_McuGPIOPort.PORTC, 15)
    # PORTD
    PD_0 = _McuGPIOPin(_McuGPIOPort.PORTD, 0)
    PD_1 = _McuGPIOPin(_McuGPIOPort.PORTD, 1)
    PD_2 = _McuGPIOPin(_McuGPIOPort.PORTD, 2)
    PD_3 = _McuGPIOPin(_McuGPIOPort.PORTD, 3)
    PD_4 = _McuGPIOPin(_McuGPIOPort.PORTD, 4)
    PD_5 = _McuGPIOPin(_McuGPIOPort.PORTD, 5)
    PD_6 = _McuGPIOPin(_McuGPIOPort.PORTD, 6)
    PD_7 = _McuGPIOPin(_McuGPIOPort.PORTD, 7)
    PD_8 = _McuGPIOPin(_McuGPIOPort.PORTD, 8)
    PD_9 = _McuGPIOPin(_McuGPIOPort.PORTD, 9)
    PD_10 = _McuGPIOPin(_McuGPIOPort.PORTD, 10)
    PD_11 = _McuGPIOPin(_McuGPIOPort.PORTD, 11)
    PD_12 = _McuGPIOPin(_McuGPIOPort.PORTD, 12)
    PD_13 = _McuGPIOPin(_McuGPIOPort.PORTD, 13)
    PD_14 = _McuGPIOPin(_McuGPIOPort.PORTD, 14)
    PD_15 = _McuGPIOPin(_McuGPIOPort.PORTD, 15)
    # PORTE
    PE_0 = _McuGPIOPin(_McuGPIOPort.PORTE, 0)
    PE_1 = _McuGPIOPin(_McuGPIOPort.PORTE, 1)
    PE_2 = _McuGPIOPin(_McuGPIOPort.PORTE, 2)
    PE_3 = _McuGPIOPin(_McuGPIOPort.PORTE, 3)
    PE_4 = _McuGPIOPin(_McuGPIOPort.PORTE, 4)
    PE_5 = _McuGPIOPin(_McuGPIOPort.PORTE, 5)
    PE_6 = _McuGPIOPin(_McuGPIOPort.PORTE, 6)
    PE_7 = _McuGPIOPin(_McuGPIOPort.PORTE, 7)
    PE_8 = _McuGPIOPin(_McuGPIOPort.PORTE, 8)
    PE_9 = _McuGPIOPin(_McuGPIOPort.PORTE, 9)
    PE_10 = _McuGPIOPin(_McuGPIOPort.PORTE, 10)
    PE_11 = _McuGPIOPin(_McuGPIOPort.PORTE, 11)
    PE_12 = _McuGPIOPin(_McuGPIOPort.PORTE, 12)
    PE_13 = _McuGPIOPin(_McuGPIOPort.PORTE, 13)
    PE_14 = _McuGPIOPin(_McuGPIOPort.PORTE, 14)
    PE_15 = _McuGPIOPin(_McuGPIOPort.PORTE, 15)
    # PORTH
    PH_0 = _McuGPIOPin(_McuGPIOPort.PORTH, 0)
    PH_1 = _McuGPIOPin(_McuGPIOPort.PORTH, 1)
    PH_3 = _McuGPIOPin(_McuGPIOPort.PORTH, 3)


def mcu_gpio_read_pin(pin: McuPin, comms: Protocol) -> bool:
    """Reads the value of a GPIO pin on the MCU.

    Args:
        pin: the pin to read
        comms: reference to the com port object to use

    Returns:
        the state of the pin
    """
    response = comms.send(
        command=Commands.GET_HARDWARE_STATE,
        target=Targets.MCU,
        payload=bytes([Hardware.GPIO_IN, (pin.value.port & 7) << 4 | (pin.value.pin & 0xF)]),
    )
    # The state of the most significant bit in the last byte of the payload is the state of the pin
    return bool(response.payload[-1] >> 7 & 0x01)


def mcu_gpio_write_pin(pin: McuPin, value: bool, comms: Protocol) -> None:
    """Writes the value of a GPIO pin on the MCU.

    Args:
        pin: the pin to write
        value: the value to write to the pin
        comms: reference to the com port object to use

    Raises:
        RuntimeError: if the pin value was not set correctly
    """
    response = comms.send(
        command=Commands.SET_HARDWARE_STATE,
        target=Targets.MCU,
        payload=bytes(
            [Hardware.GPIO_OUT, (int(value) & 0x01) << 7 | (pin.value.port & 7) << 4 | (pin.value.pin & 0xF)]
        ),
    )

    if bool(response.payload[-1] >> 7 & 0x01) is not value:
        raise RuntimeError("Failed to set GPIO pin")
