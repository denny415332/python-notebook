"""This module provides functions to access the SPI bus(es) on the connected electronics and allows targeting specific devices on the bus."""  # noqa: E501

from enum import IntEnum
from struct import pack

from wopcprotocol.common import Side
from wopcprotocol.protocol import Commands, Protocol


class SPICommands(IntEnum):
    SPI_READ = 0x00
    SPI_WRITE = 0x01


class SPIDevices(IntEnum):
    """Supported SPI devices."""

    FLASH_MX25 = 0x00
    """SPI flash memory"""
    PANEL_LCOS = 0x01
    """LCOS panel"""
    PANEL_NOVA = 0x02
    """Nova chip"""
    PANEL_AURORA = 0x03
    """Aurora chip"""


def read(*, target: Side, device: SPIDevices, addr: int, size: int, comms: Protocol) -> bytes:
    """Read from a SPI device.

    Args:
        target: side identifying the SPI bus
        device: device to read from
        addr: address/register to read
        size: number of bytes to read
        comms: reference to the comms object

    Returns:
        data read from the device
    """
    payload = pack("<BBHH", SPICommands.SPI_READ, device, size, addr)
    response = comms.send(command=Commands.SPI_PASSTHROUGH, target=target, payload=payload)
    return response.payload[6:]


def write(*, target: Side, device: SPIDevices, addr: int, data: bytes, comms: Protocol) -> None:
    """Write to a SPI device.

    Args:
        target: side identifying the SPI bus
        device: device to write to
        addr: address/register to write
        data: data to write
        comms: reference to the comms object
    """
    payload = pack("<BBHH", SPICommands.SPI_WRITE, device, len(data), addr)
    payload += data
    comms.send(command=Commands.SPI_PASSTHROUGH, target=target, payload=payload)


def _read_register(*, side: Side, device: SPIDevices, reg: int, comms: Protocol) -> int:
    data = read(target=side, device=device, addr=reg, size=8, comms=comms)[:2]
    return int.from_bytes(data, byteorder="little", signed=False)


def read_nova_register(side: Side, reg: int, comms: Protocol) -> int:
    """Read a register of the Nova chip in a panel.

    Args:
        side: side identifying the panel
        reg: register to read
        comms: reference to the comms object

    Returns:
        value of the register
    """
    return _read_register(side=side, device=SPIDevices.PANEL_NOVA, reg=reg, comms=comms)


def read_lcos_register(side: Side, reg: int, comms: Protocol) -> int:
    """Read a register of the LCoS panel.

    Args:
        side: side identifying the panel
        reg: register to read
        comms: reference to the comms object

    Returns:
        value of the register
    """
    return _read_register(side=side, device=SPIDevices.PANEL_LCOS, reg=reg, comms=comms)
