"""This module contains classes, methods, and definitions to control a generic test station.

Refer to the [Installation](index.md#Installation) section to install the package and the system's requirements.
Also few examples are provided to cover the most common scenarios.

!!! example "Examples"
    === "Station Info"
        ``` python
        from wopcprotocol.test_station import TestStation

        station = TestStation()
        # Print controllers info
        for index, controller in enumerate(station.controllers):
            print(f"{index + 1}. {controller.type.name}")
            print(f"  hardware rev: {controller.hardware_version}")
            print(f"  firmware rev: {controller.firmware_version}")
            print(f"  serial number: {controller.serial_number}")
        # Print the sides available (projector controllers)
        print(station.sides)
        # Check if the mount is connected
        print(f"mount is {'' if station.is_mount_attached else 'NOT'} connected")
        # Print panels info and available test images
        if len(station.sides) > 0:
            print("panels info:")
            for side in station.sides:
                print(f"  {side.name}: panel type: {station.panels[side].type.name}, panel fw: {station.panels[side].firmware_version}")
            print("test images info:")
            for side in station.sides:
                print(f"  {side.name}: {station.get_available_test_images(side)}")
        station.close()
        ```
    === "LEDs Control"
        ``` python
        from wopcprotocol.test_station import TestStation
        from wopcprotocol.common import LedState, LedCurrent
        import time

        LED_CURRENTS = [10.0, 20.0, 30.0, 40.0, 50.0]
        LED_STATES = [
            LedState(red=True, green=False, blue=False),
            LedState(red=False, green=True, blue=False),
            LedState(red=False, green=False, blue=True),
            LedState(red=True, green=True, blue=True),
        ]

        station = TestStation()
        if len(station.sides) == 0:
            raise RuntimeError("no projector controllers available")
        for side in station.sides:
            print(f"side: {side.name}")
            for current in LED_CURRENTS:
                print(f"  setting led current to {current}")
                station.set_led_current(side, LedCurrent.all(current))
                time.sleep(1)
            for led_state in LED_STATES:
                print(f"  setting led state to {led_state}")
                station.set_led_state(side, led_state)
                time.sleep(1)

        ```

    === "Test Images"
        ``` python
        from wopcprotocol.test_station import TestStation
        import time

        station = TestStation()
        if len(station.sides) == 0:
            raise RuntimeError("no projector controllers available")
        for side in station.sides:
            print(f"side: {side.name}")
            test_images = station.get_available_test_images(side)
            for test_image in test_images:
                print(f"\tsetting test image to '{test_image}'")
                station.set_test_image(side, test_image)
                time.sleep(1)
        ```

    === "Connect/Disconnect Projectors"
        ``` python
        import sys
        from wopcprotocol.test_station import TestStation
        import time

        station = TestStation()
        while len(station.sides) == 0:
            print("no projectors found")
            time.sleep(1)
            try:
                input("connect a panel and press enter")
                print("connecting...")
                station.connect_projectors()
            except KeyboardInterrupt:
                print("user aborted")
                sys.exit(0)
        print(f"found {station.sides} projectors")
        ```
"""  # noqa: E501, EXE002

from __future__ import annotations

import logging
import struct
import time
import warnings
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from enum import IntEnum, auto
from math import ceil
from typing import Any, ClassVar, TypeVar, cast

from serial import SerialException

import wopcprotocol.brightness as bt
from wopcprotocol.common import (
    FirmwareVersion,
    HardwareVersion,
    LedCurrent,
    LedDutyCycle,
    LedPower,
    LedState,
    LedTemperature,
    LedVoltage,
    OrientAlign,
    Side,
)
from wopcprotocol.cp_sequence import CPPanelData, CPTestImages, get_sequence
from wopcprotocol.errors import (
    DeviceNotFoundError,
    NotAcknowledgedError,
    ProtocolError,
    SequenceNotFoundError,
    WOPCProtocolError,
)
from wopcprotocol.mcu_gpio import McuPin, mcu_gpio_read_pin, mcu_gpio_write_pin
from wopcprotocol.nova_nvm import (
    CPNvm,
    CPNvmLatest,
    NovaError,
    nvm_get_customer_block_address,
    nvm_read,
    nvm_read_panel_uid,
    nvm_write,
)
from wopcprotocol.nova_utils import NovaHalMode, get_nova_hal_mode, set_nova_hal_mode
from wopcprotocol.protocol import Commands, Electronics, Protocol, Targets
from wopcprotocol.test_patterns import set_splash_screen
from wopcprotocol.utils import (
    disable_lcos_power,
    get_mcu_status,
    get_orient_align,
    get_panel_temperatures,
    reboot_mcu,
    run_panel_ee_screening,
    set_orient_align,
)

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


# To be used as decorator to check side argument
def check_side(func: F) -> F:
    def wrapper(self: TestStation, side: Side, *args: Any, **kwargs: Any) -> Any:
        if side not in self.sides:
            raise ValueError(f"side {side.name} is not valid")
        return func(self, side, *args, **kwargs)

    return cast(F, wrapper)


class PanelType(IntEnum):
    """Type of panel."""

    UNKNOWN = 0
    """Unknown panel"""
    NOVA = 1
    """Avalon panel"""
    COMET = 2
    """Comet panel"""

    @classmethod
    def from_hardware_version(cls, major: int, minor: int) -> PanelType:
        if major == 3 and minor == 4:
            return cls.NOVA
        if major == 4 and minor == 1:
            return cls.COMET
        raise ValueError(f"unknown panel type {major}.{minor}")


@dataclass
class Panel:
    type: PanelType
    """Type of panel"""
    firmware_version: FirmwareVersion
    """Firmware version"""
    data: CPPanelData
    """Panel data"""


class TestStation:
    """Generic test station class to control the test station.

    The constructor will automatically detect the connected controllers and will create a dictionary
    of projector controllers indexed by side. The user can then transparently send commands to the desired `side`
    without having to worry about the controller.

    Raises:
        RuntimeError: if no controllers are found or two are found for the same side

    Info:
        A test station can be composed of multiple controllers, some of which are projector controllers
        (i.e. connected and able to driver a panel). The constructor will identify all available controllers first
        and then identify the projector controllers among them (if any). At any time, the user can call the
        [`connect_projectors`][wopcprotocol.test_station.TestStation.connect_projectors] method
        to discover newly connected projectors. This is particularly useful in test stations
        where the projectors (or panels) can be connected/disconnected at runtime.
    """

    # This avoid getting pytest confused
    __test__ = False

    class _Cmd(IntEnum):
        INFO = 0
        ADC = 1
        IO_CTRL = 2
        ERR = 3
        BASE_EEPPROM = 4
        MOUNT_EEPROM = 5
        PERIPHERAL = 6

    class _Peripheral(IntEnum):
        LCOS_RELEASE = 0
        LAMP = 1
        LED_ENABLE_SELECT = 2

    @dataclass
    class _Resistance:
        red: float
        green: float
        blue: float

    @dataclass
    class _DigitalPinDefinition:
        controllers: Sequence[TestStation.ControllerType]

    @dataclass
    class _McuPinDefinition(_DigitalPinDefinition):
        mcu_pin: McuPin

    @dataclass
    class _IoExpanderPinDefinition(_DigitalPinDefinition):
        port: int
        pin: int
        target: Targets

    class ControllerType(IntEnum):
        """The type of controller supported."""

        STANDALONE_PUCK = 0
        """Just a puck on its own"""
        PROTOA_ALIGNMENT_BOARD = 1
        """Alignment board used for ProtoA"""
        PROTOA_SPLIT_BOARD = 2
        """Split board used for ProtoA"""
        PROTOA_SINGLE_BOARD = 3
        """Single board used for ProtoA"""
        PROTOA_DEMO_BOARD = 4
        """Demo board used for ProtoA"""
        EVT_ROBOT_BOARD_LEFT = 5
        """Board attached to the LHS robot arm used for EVT"""
        EVT_ROBOT_BOARD_RIGHT = 6
        """Board attached to the LHS robot arm used for EVT"""
        EVT_BASEBOARD = 7
        """Main PCB comprising connections for module mount and alignment boards used for EVT"""

        @staticmethod
        def get_type(electronics: Electronics, hardware_type: int) -> TestStation.ControllerType:
            """Get the controller type based on the electronics and hardware type.

            Args:
                electronics: the electronics type
                hardware_type: the hardware type
            """
            if electronics == Electronics.SPECTRE:
                return TestStation.ControllerType(hardware_type)
            if electronics == Electronics.EVT:
                return TestStation.ControllerType((hardware_type - 1) + TestStation.ControllerType.EVT_ROBOT_BOARD_LEFT)
            raise ValueError("invalid electronics type")

    @dataclass(kw_only=True)
    class Controller:
        """Class to hold the controller information and reference to the com port object to handle IO.

        Args:
            type: type of controller
            comms: reference to the com port object to handle IO
        """

        type: TestStation.ControllerType
        comms: Protocol

        @property
        def hardware_version(self) -> HardwareVersion:
            """Returns the hardware version of the controller."""
            return self.comms.hardware_version

        @property
        def firmware_version(self) -> FirmwareVersion:
            """Returns the firmware version of the controller."""
            return self.comms.firmware_version

        @property
        def serial_number(self) -> bytes:
            """Returns the serial number of the controller."""
            return self.comms.hardware_version.serial_number

        def __eq__(self, other: object) -> bool:
            if not isinstance(other, TestStation.Controller):
                raise TypeError
            return bool(self.comms.usb_serial_number == other.comms.usb_serial_number)

    class AlarmTarget(IntEnum):
        """Target for the alarm."""

        RED_LED = 0
        """Red LED of the projector"""
        GREEN_LED = 1
        """Green LED of the projector"""
        BLUE_LED = 2
        """Blue LED of the projector"""
        LCOS_PANEL = 3
        """LCoS panel of the projector"""

    class AlarmType(IntEnum):
        """Type of alarm."""

        HIGH_TEMPERATURE = 0
        """The temperature is too high"""
        LOW_TEMPERATURE = 1
        """The temperature is too low"""
        HIGH_VF = 2
        """The forward voltage is too high"""
        LOW_VF = 3
        """The forward voltage is too low"""

    @dataclass
    class Alarm:
        """Alarm class to hold the alarm information.

        Args:
            target: target of the alarm
            type: type of the alarm
        """

        target: TestStation.AlarmTarget
        type: TestStation.AlarmType | None

    class DigitalOutput(IntEnum):
        """Digital output controllable by the test station."""

        BEACON_1 = auto()
        """Beacon output 1"""
        BEACON_2 = auto()
        """Beacon output 2"""
        BEACON_3 = auto()
        """Beacon output 3"""
        BEACON_4 = auto()
        """Beacon output 4"""
        EXTERNAL = auto()
        """External output"""
        # Aliases
        BEACON_RED = BEACON_1
        """Alias for `BEACON_1`"""
        BEACON_YELLOW = BEACON_2
        """Alias for `BEACON_2`"""
        BEACON_GREEN = BEACON_3
        """Alias for `BEACON_3`"""
        BEACON_BLUE = BEACON_4
        """Alias for `BEACON_4`"""

    _STATION_RESISTANCE_MAP: ClassVar[dict[ControllerType, _Resistance]] = {
        ControllerType.PROTOA_ALIGNMENT_BOARD: _Resistance(red=0.894, green=0.903, blue=0.922),
        ControllerType.PROTOA_SPLIT_BOARD: _Resistance(red=0.894, green=0.903, blue=0.922),
        ControllerType.PROTOA_SINGLE_BOARD: _Resistance(red=0.894, green=0.903, blue=0.922),
        ControllerType.PROTOA_DEMO_BOARD: _Resistance(red=0.894, green=0.903, blue=0.922),
        ControllerType.EVT_ROBOT_BOARD_LEFT: _Resistance(red=0.894, green=0.903, blue=0.922),
        ControllerType.EVT_ROBOT_BOARD_RIGHT: _Resistance(red=0.894, green=0.903, blue=0.922),
        ControllerType.EVT_BASEBOARD: _Resistance(red=0.894, green=0.903, blue=0.922),
    }

    # Pins definitions
    _INTERLOCK_INPUT_PIN: ClassVar[_DigitalPinDefinition] = _McuPinDefinition(
        controllers=[ControllerType.EVT_BASEBOARD], mcu_pin=McuPin.PC_7
    )

    _VACUUM_INPUT_PINS: ClassVar[dict[Side, _DigitalPinDefinition]] = {
        Side.LEFT: _IoExpanderPinDefinition(
            controllers=[ControllerType.EVT_ROBOT_BOARD_LEFT, ControllerType.EVT_BASEBOARD],
            port=1,
            pin=2,
            target=Targets.LEFT,
        ),
        Side.RIGHT: _IoExpanderPinDefinition(
            controllers=[ControllerType.EVT_ROBOT_BOARD_RIGHT, ControllerType.EVT_BASEBOARD],
            port=1,
            pin=2,
            target=Targets.RIGHT,
        ),
    }

    _LED_STAND_INPUT_PINS: ClassVar[dict[Side, _DigitalPinDefinition]] = {
        Side.LEFT: _IoExpanderPinDefinition(
            controllers=[ControllerType.EVT_ROBOT_BOARD_LEFT, ControllerType.EVT_BASEBOARD],
            port=1,
            pin=0,
            target=Targets.LEFT,
        ),
        Side.RIGHT: _IoExpanderPinDefinition(
            controllers=[ControllerType.EVT_ROBOT_BOARD_RIGHT, ControllerType.EVT_BASEBOARD],
            port=1,
            pin=0,
            target=Targets.RIGHT,
        ),
    }

    _OUTPUT_PINS: ClassVar[dict[DigitalOutput, list[_DigitalPinDefinition]]] = {
        DigitalOutput.BEACON_1: [
            _IoExpanderPinDefinition(
                port=1,
                pin=4,
                target=Targets.LEFT,
                controllers=[ControllerType.EVT_ROBOT_BOARD_LEFT, ControllerType.EVT_BASEBOARD],
            ),
            _IoExpanderPinDefinition(
                port=1,
                pin=4,
                target=Targets.RIGHT,
                controllers=[ControllerType.EVT_ROBOT_BOARD_RIGHT, ControllerType.EVT_BASEBOARD],
            ),
        ],
        DigitalOutput.BEACON_2: [
            _IoExpanderPinDefinition(
                port=1,
                pin=5,
                target=Targets.LEFT,
                controllers=[ControllerType.EVT_ROBOT_BOARD_LEFT, ControllerType.EVT_BASEBOARD],
            ),
            _IoExpanderPinDefinition(
                port=1,
                pin=5,
                target=Targets.RIGHT,
                controllers=[ControllerType.EVT_ROBOT_BOARD_RIGHT, ControllerType.EVT_BASEBOARD],
            ),
        ],
        DigitalOutput.BEACON_3: [
            _IoExpanderPinDefinition(
                port=1,
                pin=6,
                target=Targets.LEFT,
                controllers=[ControllerType.EVT_ROBOT_BOARD_LEFT, ControllerType.EVT_BASEBOARD],
            ),
            _IoExpanderPinDefinition(
                port=1,
                pin=6,
                target=Targets.RIGHT,
                controllers=[ControllerType.EVT_ROBOT_BOARD_RIGHT, ControllerType.EVT_BASEBOARD],
            ),
        ],
        DigitalOutput.BEACON_4: [
            _IoExpanderPinDefinition(
                port=1,
                pin=7,
                target=Targets.LEFT,
                controllers=[ControllerType.EVT_ROBOT_BOARD_LEFT, ControllerType.EVT_BASEBOARD],
            ),
            _IoExpanderPinDefinition(
                port=1,
                pin=7,
                target=Targets.RIGHT,
                controllers=[ControllerType.EVT_ROBOT_BOARD_RIGHT, ControllerType.EVT_BASEBOARD],
            ),
        ],
        DigitalOutput.EXTERNAL: [_McuPinDefinition(mcu_pin=McuPin.PC_15, controllers=[ControllerType.EVT_BASEBOARD])],
    }

    RECONNECT_TIME_MAX_DEFAULT: ClassVar[float] = 10.0
    """Maximum time to wait for the controllers to reconnect after a power cycle"""
    BASE_EEPROM_SIZE: ClassVar[int] = 256
    """Size of the base EEPROM in bytes"""
    MOUNT_EEPROM_SIZE: ClassVar[int] = 256
    """Size of the mount EEPROM in bytes"""

    # Check the for a valid range of the address and size
    @staticmethod
    def _check_eeprom_address(address: int, size: int, eeprom_size: int) -> None:
        if address < 0:
            raise ValueError("address must be an integer >= 0")
        if address + size > eeprom_size:
            raise ValueError(f"the end address ({address + size}) is greater than the eeprom size ({eeprom_size})")

    def __init__(self, timeout: float | None = Protocol.TIMEOUT_DEFAULT, *, allow_pucks: bool = False) -> None:
        self._controllers: list[TestStation.Controller] = []
        self._projectors: dict[Side, TestStation.Controller] = {}
        self._panels: dict[Side, Panel] = {}
        self._mount_serial_number: bytes = bytes([])
        self._allow_pucks = allow_pucks
        self._timeout = timeout
        self._connect_controllers()
        self._connect_projectors()

    # Generic set function for the test station APIs
    def _set(self, *, comms: Protocol, target: Targets, cmd: _Cmd, data: bytes) -> None:
        comms.send(command=Commands.TEST_STATION_SET, target=target, payload=bytes([cmd]) + data)

    # Generic get function for the test station APIs
    def _get(self, *, comms: Protocol, target: Targets, cmd: _Cmd, data: bytes = b"") -> bytes:
        response = comms.send(command=Commands.TEST_STATION_GET, target=target, payload=bytes([cmd]) + data)
        return response.payload[1:]

    # Connects to all controllers of type Spectre or EVT
    def _connect_controllers(self) -> None:
        devices = Protocol.list_devices_by_electronics([Electronics.SPECTRE, Electronics.EVT])
        for i, device in enumerate(devices):
            comms = Protocol(device.serial_number, timeout=self._timeout)
            try:
                data = self._get(comms=comms, target=Targets.MCU, cmd=self._Cmd.INFO)
                data_format = "<8x8sBx"
                mount_serial_number, hardware_type = struct.unpack(data_format, data[: struct.calcsize(data_format)])
                controller_type = self.ControllerType.get_type(comms.electronics, hardware_type)
                # If not already, get the mount ID
                if not self.is_mount_attached and any(x not in (0, 0xFF) for x in mount_serial_number):
                    self._mount_serial_number = mount_serial_number
            except NotAcknowledgedError as e:
                # If the MCU NAKs the command then it might be a puck with an old firmware
                # Pucks allowed?
                if comms.electronics == Electronics.SPECTRE and self._allow_pucks:
                    controller_type = self.ControllerType.STANDALONE_PUCK
                else:
                    raise WOPCProtocolError(
                        "standalone pucks are not allowed. If using a baseboard check the connection between the puck and the baseboard. If using a standalone puck, set allow_pucks=True when creating the TestStation instance"  # noqa: E501
                    ) from e
            # Add controller to list
            self._controllers += [self.Controller(type=controller_type, comms=comms)]
            logger.debug(f"controller {i}: {self._controllers[-1]}")

        # Check if you have at least one controller
        if len(self._controllers) == 0:
            raise DeviceNotFoundError("no controllers were found")

    # identify the projectors among the controllers based on the panel status
    def _connect_projectors(self) -> None:
        def add_projector(side: Side, controller: TestStation.Controller) -> None:
            if side in self._projectors:
                raise RuntimeError(f"two controllers were found for side {side.name}")
            self._projectors[side] = controller
            logger.debug(f"projector {side.name}: {controller}")
            # Read panel fw version and sequence/test images CRC
            response = controller.comms.send(command=Commands.GET_DEVICE_VERSION, target=side)
            fw_version_int, build_number, _, crc = struct.unpack("<IIII", response.payload)
            # Read LE type
            response = self.projectors[side].comms.send(command=Commands.GET_LIGHT_ENGINE_TYPE, target=side)
            minor, major = response.payload
            self._panels[side] = Panel(
                type=PanelType.from_hardware_version(major, minor),
                firmware_version=FirmwareVersion(
                    major=(fw_version_int >> 16) & 0xFF,
                    minor=(fw_version_int >> 8) & 0xFF,
                    patch=fw_version_int & 0xFF,
                    build_number=build_number,
                    build_timestamp="",
                    git_commit="",
                ),
                data=get_sequence(crc),
            )

        # Only try with controllers not connected to a projector already
        controllers = list(filter(lambda c: c not in self._projectors.values(), self._controllers))
        for controller in controllers:
            status = get_mcu_status(controller.comms)
            for side in Side:
                if status.panels[side]:
                    add_projector(side, controller)

    # Utility function to return a controller filtering by type with descending priority
    def _get_controller(self, *types: TestStation.ControllerType) -> Controller:
        for controller_type in types:
            try:
                return next(filter(lambda controller: controller.type == controller_type, self._controllers))
            except StopIteration:  # noqa: PERF203
                pass
        raise StopIteration

    def _reboot_controllers(self, controllers: list[Controller], reconnect_time_max: float) -> None:
        # If the baseboard is among the controllers then don't bother rebooting the EVT chuck boards
        # as the baseboard MCU will take care of it
        controllers_to_reboot = controllers
        if any(c.type == self.ControllerType.EVT_BASEBOARD for c in controllers_to_reboot):
            controllers_to_reboot = list(
                filter(
                    lambda c: c.type
                    not in (self.ControllerType.EVT_ROBOT_BOARD_LEFT, self.ControllerType.EVT_ROBOT_BOARD_RIGHT),
                    controllers_to_reboot,
                )
            )
        # Reboot first
        logger.debug(f"rebooting controllers: {controllers_to_reboot}")
        for controller in controllers_to_reboot:
            reboot_mcu(controller.comms)
            time.sleep(0.25)
        for controller in controllers:
            controller.comms.close()
        time.sleep(2)
        # Reconnect comms
        attempts = ceil(reconnect_time_max)
        for controller in controllers:
            while attempts > 0:
                try:
                    controller.comms = Protocol(controller.comms.usb_serial_number, timeout=self._timeout)
                    break
                except (DeviceNotFoundError, SerialException, ProtocolError):
                    pass
                time.sleep(1)
                attempts -= 1
        if attempts == 0:
            raise DeviceNotFoundError("cannot find controllers after reboot")

    def _set_digital_output(self, pin_def: _DigitalPinDefinition, value: bool) -> None:
        error: Exception | None = None
        for controller_type in pin_def.controllers:
            error = None
            try:
                controller = self._get_controller(controller_type)
                if isinstance(pin_def, self._McuPinDefinition):
                    mcu_gpio_write_pin(pin=pin_def.mcu_pin, value=value, comms=controller.comms)
                elif isinstance(pin_def, self._IoExpanderPinDefinition):
                    # Read the current state of the port
                    data = bytearray(self._get(comms=controller.comms, target=pin_def.target, cmd=self._Cmd.IO_CTRL))
                    # Set the pin value
                    if value:
                        data[pin_def.port] |= 1 << pin_def.pin
                    else:
                        data[pin_def.port] &= ~(1 << pin_def.pin)
                    # Write the new port value
                    self._set(
                        comms=controller.comms, target=Targets(pin_def.target), cmd=self._Cmd.IO_CTRL, data=bytes(data)
                    )
                else:
                    raise NotImplementedError(f"unsupported pin definition {pin_def}")
                break
            except StopIteration:
                error = NotImplementedError("digital output is not supported by the hardware")
            except NotAcknowledgedError as e:
                error = e
        if error:
            raise error

    def _get_digital_input(self, pin_def: _DigitalPinDefinition) -> bool:
        def get_input(controller: TestStation.Controller) -> bool:
            if isinstance(pin_def, self._McuPinDefinition):
                return mcu_gpio_read_pin(pin_def.mcu_pin, controller.comms)
            if isinstance(pin_def, self._IoExpanderPinDefinition):
                data = self._get(comms=controller.comms, target=pin_def.target, cmd=self._Cmd.IO_CTRL)
                return bool(data[pin_def.port] & (1 << pin_def.pin) != 0)
            raise NotImplementedError(f"unsupported pin definition {pin_def}")

        error: Exception | None = None
        digital_input = False
        for controller_type in pin_def.controllers:
            error = None
            try:
                controller = self._get_controller(controller_type)
                digital_input = get_input(controller)
                break
            except StopIteration:
                error = NotImplementedError("digital input is not supported by the hardware")
            except NotAcknowledgedError as e:
                error = e
        if error:
            raise error
        return digital_input

    @property
    def controller_types(self) -> list[ControllerType]:
        """Returns the list of controller types found in the test station.

        Returns:
            list of controller types found in the test station
        """
        return [controller.type for controller in self._controllers]

    @property
    def controllers(self) -> list[Controller]:
        """Returns the list of controllers found in the test station.

        Returns:
            list of controllers found in the test station
        """
        return self._controllers.copy()

    @property
    def projectors(self) -> dict[Side, Controller]:
        """Returns a dictionary of projector controllers found in the test station indexed by side.

        Returns:
            dictionary of projector controllers found in the test station indexed by side

        Info:
            A projector controller is a controller that is connected to a projector (or panel).
            This is a subset of the controllers returned by the
            [`controllers`][wopcprotocol.test_station.TestStation.controllers] property.
        """
        return self._projectors.copy()

    @property
    def panels(self) -> dict[Side, Panel]:
        """Returns a dictionary of panels found in the test station indexed by side.

        Returns:
            dictionary of panels found in the test station indexed by side
        """
        return self._panels.copy()

    @property
    def sides(self) -> list[Side]:
        """Returns the list of sides for which a projector controller was found.

        Returns:
            list of supported sides
        """
        return list(self._projectors.keys())

    @property
    def is_mount_attached(self) -> bool:
        """Returns True if a mount is attached to the test station.

        Returns:
            True if a mount is attached to the test station
        """
        return any(self._mount_serial_number)

    @property
    def mount_serial_number(self) -> bytes:
        """Returns the serial number of the mount attached to the test station.

        Returns:
            serial number of the mount attached to the test station
        """
        return self._mount_serial_number

    def connect_projectors(self, connect_time_max: float = RECONNECT_TIME_MAX_DEFAULT) -> list[Side]:
        """Connects the projector controllers to the test station.

        Args:
            connect_time_max: maximum time to wait for the controllers to detect the projectors

        Returns:
            list of sides for which a projector controller was found

        Info:
            The projectors are automatically connected when creating the instance, but this method can be called again
            to discover newly connected projectors. This is particularly useful in test stations
            where the projectors (or panels) can be connected/disconnected at runtime.
        """
        # Only try with controllers not connected to a projector already...
        controllers = list(filter(lambda c: c not in self._projectors.values(), self._controllers))
        # ... but if a chuck board is among the projector controllers then don't reboot the EVT baseboard
        if any(
            c.type in (self.ControllerType.EVT_ROBOT_BOARD_LEFT, self.ControllerType.EVT_ROBOT_BOARD_RIGHT)
            for c in self._projectors.values()
        ):
            controllers = list(filter(lambda c: c.type != self.ControllerType.EVT_BASEBOARD, controllers))
        self._reboot_controllers(controllers, connect_time_max)
        self._connect_projectors()
        return self.sides

    def disconnect_projectors(self) -> None:
        """Disconnects the projector controllers from the test station and issue a power off command to the panels."""
        for side in self.sides:
            disable_lcos_power(self._projectors[side].comms)
        self._projectors = {}
        self._panels = {}

    @check_side
    def get_available_test_images(self, side: Side) -> list[str]:
        """Returns the list of available test images for the specified side.

        Args:
            side: side for which to get the list of available test images

        Returns:
            list of available test images

        Info:
            Information on the test images is parsed from the sequence stored in the controller/panel flash memory.
            The constructor will request the ID of the sequence to the controller,
            and meta information on the sequence is then downloaded from a public registry and parsed.
        """
        return (
            [test_image.printable_name for test_image in cast(CPTestImages, self._panels[side].data.test_images).images]
            if self._panels[side].data.test_images is not None
            else []
        )

    @check_side
    def get_available_splash_screens(self, side: Side) -> list[str]:
        """Returns the list of available splash screens for the specified side.

        Args:
            side: side for which to get the list of available splash screens

        Returns:
            list of available splash screens

        Warning:
            This method is deprecated and will be removed in future releases.
            Use [`get_available_test_images`][wopcprotocol.test_station.TestStation.get_available_test_images] instead.
        """
        warnings.warn(
            "get_available_splash_screens is deprecated, use get_available_test_images instead",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.get_available_test_images(side)

    def close(self) -> None:
        """Closes the com port connection for all the controllers."""
        for controller in self._controllers:
            controller.comms.close()
        self._controllers = []
        self._projectors = {}
        self._panels = {}

    def reboot(self, reconnect_time_max: float = RECONNECT_TIME_MAX_DEFAULT) -> None:
        """Reboots the controllers and reconnects to the projectors.

        Args:
            reconnect_time_max: maximum time to wait for the controllers to be found after reboot
        """
        self.disconnect_projectors()
        self._reboot_controllers(self._controllers, reconnect_time_max)
        self._connect_projectors()

    @check_side
    def get_led_state(self, side: Side) -> LedState:
        """Returns the state of the LEDs for the specified side.

        Args:
            side: side for which to get the LED state

        Returns:
            `LedState` object with the state of the LEDs
        """
        return bt.get_led_state(side, self._projectors[side].comms)

    @check_side
    def set_led_state(self, side: Side, state: LedState) -> None:
        """Sets the state of the LEDs for the specified side.

        Args:
            side: side for which to set the LED state
            state: state of the LEDs
        """
        bt.set_led_state(side=side, state=state, comms=self._projectors[side].comms)

    def set_led_state_cw(self, side: Side, state: LedState) -> None:
        """Drives the LEDs in Continuous Wave (CW) mode for the specified side.

        Args:
            side: side for which to set the LED drive to CW
            state: state of the LEDs

        Warning:
            The hardware will be set to isolate the panels (if any) from the LEDs.
            A [reboot][wopcprotocol.test_station.TestStation.reboot] is required to restore the normal LED drive mode.
        """
        # Check at most one LED is enabled
        if sum(list(state)) > 1:
            raise ValueError("only one LED can be enabled at a time")

        error: Exception | None = None
        for controller_type in [
            self.ControllerType.EVT_ROBOT_BOARD_LEFT
            if side == Side.LEFT
            else self.ControllerType.EVT_ROBOT_BOARD_RIGHT,
            self.ControllerType.EVT_BASEBOARD,
        ]:
            error = None
            try:
                controller = self._get_controller(controller_type)
                value = 3 + (state.red << 4) + (state.green << 5) + (state.blue << 6)
                self._set(
                    comms=controller.comms,
                    target=Targets(side.value),
                    cmd=self._Cmd.PERIPHERAL,
                    data=bytes([self._Peripheral.LED_ENABLE_SELECT, value]),
                )
                break
            except StopIteration:
                error = NotImplementedError("LED CW drive is not supported by the hardware")
            except NotAcknowledgedError as e:
                error = e
        if error:
            raise error

    @check_side
    def run_led_test(self, side: Side, save_status: bool = True) -> LedState:
        """Runs a self test on the LEDs for the specified side.

        Args:
            side: side for which to run the LED test
            save_status: if True, the current LED state will be saved and restored after the test

        Returns:
            `LedState` object representing the result of the test
        """
        if save_status:
            old_led_state = self.get_led_state(side)
        # Enable all LEDs
        self.set_led_state(side, LedState(red=True, green=True, blue=True))
        result = bt.run_led_test(side, self._projectors[side].comms)
        if save_status:
            self.set_led_state(side, old_led_state)
        return result

    @check_side
    def set_led_current(self, side: Side, current: LedCurrent) -> None:
        """Sets the current of the LEDs for the specified side.

        Args:
            side: side for which to set the LED current
            current: current of the LEDs
        """
        bt.set_led_current(side=side, current=current, use_nvm=False, comms=self._projectors[side].comms)

    @check_side
    def get_led_current(self, side: Side) -> LedCurrent:
        """Returns the current of the LEDs for the specified side.

        Args:
            side: side for which to get the LED current

        Returns:
            `LedCurrent` object with the current of the LEDs

        Note:
            The status of the LEDs is considered so if the LEDs are disabled, the returned current will be 0.
        """
        current = bt.get_led_current(side=side, use_nvm=False, comms=self._projectors[side].comms)
        led = self.get_led_state(side)
        return LedCurrent(
            red=current[0] if led.red else 0.0,
            green=current[1] if led.green else 0.0,
            blue=current[2] if led.blue else 0.0,
        )

    @check_side
    def set_brightness_level(self, side: Side, level: int) -> None:
        """Sets the brightness level of the projector for the specified side.

        Args:
            side: side for which to set the brightness level
            level: brightness level to set

        Note:
            The firmware API actually set the brightness for both sides, so the affected sides depends on the hardware configuration.
            For example, if a test station has two projectors and a single controller (puck or EVT electronics) then the brightness level will be set for both sides.
            Otherwise, if there is one controller per side then the brightness level will be set for the specified side only.
        """  # noqa: E501
        bt.set_brightness_level(level, self._projectors[side].comms)

    @check_side
    def get_brightness_level(self, side: Side) -> int:
        """Returns the brightness level of the projector for the specified side.

        Args:
            side: side for which to get the brightness level

        Returns:
            brightness level of the projector

        Note:
            See note for [`set_brightness_level`][wopcprotocol.test_station.TestStation.set_brightness_level].
        """
        return bt.get_brightness_level(self._projectors[side].comms)

    @check_side
    def get_led_voltage(self, side: Side, apply_compensation: bool = True) -> LedVoltage:
        """Returns the forward voltage of the LEDs for the specified side.

        Args:
            side: side for which to get the LED voltage
            apply_compensation: if True, the voltage will be compensated for ohmic losses

        Returns:
            `LedVoltage` object with the voltage of the LEDs

        Note:
            The status of the LEDs is considered so if the LEDs are disabled, the returned voltage will be 0.
        """

        def compensate_led_voltage(voltage: float, current: float, resistance: float) -> float:
            return max(voltage - resistance * current, 0)

        led_voltage = bt.read_led_voltage(side, self._projectors[side].comms)
        led = self.get_led_state(side)
        voltage = LedVoltage(
            red=led_voltage.red if led.red else 0.0,
            green=led_voltage.green if led.green else 0.0,
            blue=led_voltage.blue if led.blue else 0.0,
        )
        if not led_voltage:
            raise RuntimeError("error reading led voltage")
        if apply_compensation:
            current = self.get_led_current(side)
            resistance = self._STATION_RESISTANCE_MAP[self._projectors[side].type]
            voltage = LedVoltage(
                red=compensate_led_voltage(voltage=voltage.red, current=current.red, resistance=resistance.red),
                green=compensate_led_voltage(voltage=voltage.green, current=current.green, resistance=resistance.green),
                blue=compensate_led_voltage(voltage=voltage.blue, current=current.blue, resistance=resistance.blue),
            )
        return voltage

    @check_side
    def get_led_duty_cycle(self, side: Side) -> LedDutyCycle:
        """Returns the duty cycle of the LEDs for the specified side.

        Args:
            side: side for which to get the LED duty cycle

        Returns:
            `DutyCycle` object with the duty cycle of the LEDs

        Info:
            For panels directly supporting the API, the duty cycle is read from the panel itself.
            Otherwise, the duty cycle is parsed from the metadata of the sequence.
        """
        try:
            duty_cycle = bt.get_led_duty_cycle(side, self._projectors[side].comms)
        except NotAcknowledgedError as e:
            sequences = self._panels[side].data.sequences
            if len(sequences) > 0:
                # TODO: which index?? Fetch "look"?? Hardcoded to first sequence for now
                duty_cycle = sequences[0].duty_cycle
            else:
                raise SequenceNotFoundError("no sequence found when fetching duty cycle information") from e
        return duty_cycle

    @check_side
    def get_led_power(self, side: Side, apply_voltage_compensation: bool = True) -> LedPower:
        """Returns the power of the LEDs for the specified side.

        Args:
            side: side for which to get the LED power
            apply_voltage_compensation: if True, the power will be compensated for ohmic losses

        Returns:
            `LedPower` object with the power of the LEDs

        Info:
            The power is calculated as the product of the voltage, current, and duty cycle of the LEDs.
            If the voltage compensation is applied, the power will be compensated for ohmic losses.
        """
        current = self.get_led_current(side)
        voltage = self.get_led_voltage(side, apply_voltage_compensation)
        duty_cycle = self.get_led_duty_cycle(side)
        return LedPower.calculate(voltage=voltage, current=current, duty_cycle=duty_cycle)

    @check_side
    def get_led_temperature(self, side: Side) -> LedTemperature:
        """Returns the temperature of the LEDs for the specified side.

        Args:
            side: side for which to get the LED temperature

        Returns:
            `LedTemperature` object with the temperature of the LEDs
        """

        def adc_to_celsius(value: int) -> float:
            return value / 16.0

        data = self._get(comms=self._projectors[side].comms, target=Targets.MCU, cmd=self._Cmd.ADC)
        adc_data = struct.unpack("<" + "H" * (len(data) // 2), data)
        if self._projectors[side].type in [
            self.ControllerType.EVT_ROBOT_BOARD_LEFT,
            self.ControllerType.EVT_ROBOT_BOARD_RIGHT,
            self.ControllerType.EVT_BASEBOARD,
        ]:
            if self._panels[side].type == PanelType.COMET:
                temp = adc_to_celsius(adc_data[4 if side == Side.LEFT else 12])
                return LedTemperature(red=temp, green=temp, blue=temp, green2=temp)
            return LedTemperature(
                red=adc_to_celsius(adc_data[5 if side == Side.LEFT else 13]),
                green=adc_to_celsius(adc_data[4 if side == Side.LEFT else 12]),
                blue=adc_to_celsius(adc_data[5 if side == Side.LEFT else 13]),
            )
        return LedTemperature(
            red=adc_to_celsius(adc_data[9 if side == Side.LEFT else 11]),
            green=adc_to_celsius(adc_data[8 if side == Side.LEFT else 10]),
            blue=adc_to_celsius(adc_data[9 if side == Side.LEFT else 11]),
        )

    @check_side
    def set_test_image(self, side: Side, test_image_name: str) -> None:
        """Sets the test image for the specified side.

        Args:
            side: side for which to set the test image
            test_image_name: name of the test image to set

        Raises:
            ValueError: if the specified test image is not supported

        Info:
            The available test images can be retrieved with the
            [`get_available_test_images`][wopcprotocol.test_station.TestStation.get_available_test_images] method.
        """
        if self._panels[side].data.test_images is None:
            raise ValueError("no test images found")
        try:
            test_image = next(
                filter(
                    lambda item: item.printable_name.lower() == test_image_name.lower(),
                    cast(CPTestImages, self._panels[side].data.test_images).images,
                )
            )
            set_splash_screen(side=side, splash_screen=test_image.index, comms=self._projectors[side].comms)
        except StopIteration as e:
            raise ValueError(f"{test_image_name} test image is not supported") from e

    @check_side
    def set_splash_screen(self, side: Side, splash_screen_name: str) -> None:
        """Sets the splash screen for the specified side.

        Args:
            side: side for which to set the splash screen
            splash_screen_name: name of the splash screen to set

        Raises:
            ValueError: if the specified splash screen is not supported

        Warning:
            This method is deprecated and will be removed in future releases.
            Use [`set_test_image`][wopcprotocol.test_station.TestStation.set_test_image] instead.
        """
        warnings.warn("set_splash_screen is deprecated, use set_test_image instead", DeprecationWarning, stacklevel=2)
        self.set_test_image(side, splash_screen_name)

    @check_side
    def set_orient_align(self, side: Side, orient_align: OrientAlign) -> None:
        """Sets the orientation and alignment for the specified side.

        Args:
            side: side for which to set the orientation and alignment
            orient_align: orientation and alignment to set
        """
        set_orient_align(side=side, orient_align=orient_align, comms=self._projectors[side].comms)

    @check_side
    def get_orient_align(self, side: Side) -> OrientAlign:
        """Returns the orientation and alignment for the specified side.

        Args:
            side: side for which to get the orientation and alignment

        Returns:
            `OrientAlign` object with the orientation and alignment
        """
        return get_orient_align(side, self._projectors[side].comms)

    @check_side
    def set_long_axis_flip(self, side: Side, flipped: bool) -> None:
        """Sets the long axis flip for the specified side.

        Args:
            side: side for which to set the long axis flip
            flipped: True if the long axis is flipped, False otherwise
        """
        # Fetch the current settings
        orient_align = self.get_orient_align(side=side)
        orient_align.long_axis_flip = flipped
        self.set_orient_align(side, orient_align)

    @check_side
    def set_short_axis_flip(self, side: Side, flipped: bool) -> None:
        """Sets the short axis flip for the specified side.

        Args:
            side: side for which to set the short axis flip
            flipped: True if the short axis is flipped, False otherwise
        """
        # Fetch the current settings
        orient_align = self.get_orient_align(side=side)
        orient_align.short_axis_flip = flipped
        self.set_orient_align(side, orient_align)

    def get_interlock_status(self) -> bool:
        """Returns the interlock status for the baseboard.

        Returns:
            True if the interlock detects a safe-to-run condition, False otherwise

        Raises:
            NotImplementedError: if the interlock is not supported by the hardware
        """
        return self._get_digital_input(self._INTERLOCK_INPUT_PIN)

    def set_uv_state(self, side: Side, state: bool) -> None:
        """Sets the state of the UV LED for the specified side.

        Args:
            side: side for which to set the UV LED state
            state: state of the UV LED

        Raises:
            NotImplementedError: if the UV LED is not supported by the hardware
        """
        try:
            controller = self._get_controller(
                self.ControllerType.EVT_ROBOT_BOARD_LEFT
                if side == Side.LEFT
                else self.ControllerType.EVT_ROBOT_BOARD_RIGHT
            )
            self._set(
                comms=controller.comms,
                target=Targets(side.value),
                cmd=self._Cmd.PERIPHERAL,
                data=bytes([self._Peripheral.LAMP, 1 if state else 0]),
            )
        except StopIteration as e:
            raise NotImplementedError("UV LED is not supported by the hardware") from e

    def uv_on(self, side: Side) -> None:
        """Turns on the UV LED for the specified side.

        Args:
            side: side for which to turn on the UV LED

        Note:
            This is a wrapper around [`set_uv_state`][wopcprotocol.test_station.TestStation.set_uv_state]
        """
        self.set_uv_state(side, True)

    def uv_off(self, side: Side) -> None:
        """Turns off the UV LED for the specified side.

        Args:
            side: side for which to turn off the UV LED

        Note:
            This is a wrapper around [`set_uv_state`][wopcprotocol.test_station.TestStation.set_uv_state]
        """
        self.set_uv_state(side, False)

    def get_uv_state(self, side: Side) -> bool:
        """Returns the state of the UV LED for the specified side.

        Args:
            side: side for which to get the UV LED state

        Returns:
            True if the UV LED is on, False otherwise

        Raises:
            NotImplementedError: if the UV LED is not supported by the hardware
        """
        try:
            controller = self._get_controller(
                self.ControllerType.EVT_ROBOT_BOARD_LEFT
                if side == Side.LEFT
                else self.ControllerType.EVT_ROBOT_BOARD_RIGHT
            )
            data = self._get(
                comms=controller.comms,
                target=Targets.MCU,
                cmd=self._Cmd.PERIPHERAL,
                data=bytes([self._Peripheral.LAMP]),
            )
            return data[1] != 0
        except StopIteration as e:
            raise NotImplementedError("UV LED is not supported by the hardware") from e

    def set_ring_light_state(self, state: bool) -> None:
        """Set the state of the ring light.

        Args:
            state (bool): True if the ring light should be on, False otherwise

        Raises:
            NotImplementedError: if the ring light is not supported by the hardware
        """
        try:
            controller = self._get_controller(self.ControllerType.EVT_BASEBOARD)
            self._set(
                comms=controller.comms,
                target=Targets.MCU,
                cmd=self._Cmd.PERIPHERAL,
                data=bytes([self._Peripheral.LAMP, 1 if state else 0]),
            )
        except StopIteration as e:
            raise NotImplementedError("ring light is not supported by the hardware") from e

    def ring_light_on(self) -> None:
        """Turns on the ring light.

        Note:
            This is a wrapper around
            [`set_ring_light_state`][wopcprotocol.test_station.TestStation.set_ring_light_state]
        """
        self.set_ring_light_state(True)

    def ring_light_off(self) -> None:
        """Turns off the ring light.

        Note:
            This is a wrapper around
            [`set_ring_light_state`][wopcprotocol.test_station.TestStation.set_ring_light_state]
        """
        self.set_ring_light_state(False)

    def get_ring_light_state(self) -> bool:
        """Returns the state of the ring light.

        Raises:
            NotImplementedError: if the ring light is not supported by the hardware
        """
        try:
            controller = self._get_controller(self.ControllerType.EVT_BASEBOARD)
            data = self._get(
                comms=controller.comms,
                target=Targets.MCU,
                cmd=self._Cmd.PERIPHERAL,
                data=bytes([self._Peripheral.LAMP]),
            )
            return data[1] != 0
        except StopIteration as e:
            raise NotImplementedError("ring light is not supported by the hardware") from e

    def read_base_eeprom(self, side: Side, address: int, size: int) -> bytes:
        """Reads the base EEPROM for the specified side.

        Args:
            side: side for which to read the base EEPROM
            address: start address of the EEPROM to read
            size: number of bytes to read

        Returns:
            data read from the EEPROM

        Raises:
            ValueError: if the address is invalid or `(address+size) > eeprom_size`
        """

        try:
            # Try to use the controller attached to the robot arm or alternatively the baseboard
            controller = self._get_controller(
                self.ControllerType.EVT_ROBOT_BOARD_LEFT
                if side == Side.LEFT
                else self.ControllerType.EVT_ROBOT_BOARD_RIGHT,
                self.ControllerType.EVT_BASEBOARD,
            )
        except StopIteration:
            # If not available, use any controller
            controller = self._controllers[0]

        self._check_eeprom_address(address, size, self.BASE_EEPROM_SIZE)
        payload = struct.pack("<BH", address, size)

        data = self._get(comms=controller.comms, target=Targets(side.value), cmd=self._Cmd.BASE_EEPPROM, data=payload)
        return data[3:]

    def write_base_eeprom(self, side: Side, address: int, data: bytes) -> None:
        """Writes the base EEPROM for the specified side.

        Args:
            side: side for which to write the base EEPROM
            address: start address of the EEPROM to write
            data: data to write to the EEPROM

        Raises:
            ValueError: if the address is invalid or `(address+size) > eeprom_size`
        """
        try:
            # Try to use the controller attached to the robot arm or alternatively the baseboard
            controller = self._get_controller(
                self.ControllerType.EVT_ROBOT_BOARD_LEFT
                if side == Side.LEFT
                else self.ControllerType.EVT_ROBOT_BOARD_RIGHT,
                self.ControllerType.EVT_BASEBOARD,
            )
        except StopIteration:
            # If not available, use any controller
            controller = self._controllers[0]

        self._check_eeprom_address(address, len(data), self.BASE_EEPROM_SIZE)
        payload = struct.pack("<BH", address, len(data)) + bytes(data)
        self._set(comms=controller.comms, target=Targets(side.value), cmd=self._Cmd.BASE_EEPPROM, data=payload)

    def read_mount_eeprom(self, address: int, size: int) -> bytes:
        """Reads the mount EEPROM for the specified side.

        Args:
            address: start address of the EEPROM to read
            size: number of bytes to read

        Returns:
            data read from the EEPROM

        Raises:
            RuntimeError: if no mount is attached to the test station
            ValueError: if the address is invalid or `(address+size) > eeprom_size`
        """
        if not self.is_mount_attached:
            raise RuntimeError("no mount attached to the test station")
        # Get the controller
        try:
            # Try to use the controller attached to the robot arm or alternatively the baseboard
            controller = self._get_controller(
                self.ControllerType.EVT_ROBOT_BOARD_LEFT, self.ControllerType.EVT_BASEBOARD
            )
        except StopIteration:
            # If not available, use any controller
            controller = self._controllers[0]
        self._check_eeprom_address(address, size, self.MOUNT_EEPROM_SIZE)
        payload = struct.pack("<BH", address, size)
        data = self._get(comms=controller.comms, target=Targets.MCU, cmd=self._Cmd.MOUNT_EEPROM, data=payload)
        return data[3:]

    def write_mount_eeprom(self, address: int, data: bytes) -> None:
        """Writes the mount EEPROM for the specified side.

        Args:
            address: start address of the EEPROM to write
            data: data to write to the EEPROM

        Raises:
            RuntimeError: if no mount is attached to the test station
            ValueError: if the address is invalid or `(address+size) > eeprom_size`
        """
        if not self.is_mount_attached:
            raise RuntimeError("no mount attached to the test station")
        # Get the controller
        try:
            # Try to use the controller attached to the robot arm or alternatively the baseboard
            controller = self._get_controller(
                self.ControllerType.EVT_ROBOT_BOARD_LEFT, self.ControllerType.EVT_BASEBOARD
            )
        except StopIteration:
            # If not available, use any controller
            controller = self._controllers[0]
        self._check_eeprom_address(address, len(data), self.MOUNT_EEPROM_SIZE)
        payload = struct.pack("<BH", address, len(data)) + data
        # Use any controller to write the mount EEPROM
        self._set(comms=controller.comms, target=Targets.MCU, cmd=self._Cmd.MOUNT_EEPROM, data=payload)

    def release_door(self, side: Side) -> None:
        """Releases the door for the specified side.

        Args:
            side: side for which to release the door
        """
        try:
            controller = self._get_controller(
                self.ControllerType.EVT_ROBOT_BOARD_LEFT
                if side == Side.LEFT
                else self.ControllerType.EVT_ROBOT_BOARD_RIGHT
            )
            self._set(
                comms=controller.comms,
                target=Targets.MCU,
                cmd=self._Cmd.PERIPHERAL,
                data=bytes([self._Peripheral.LCOS_RELEASE, 0x01]),
            )
        except StopIteration as e:
            raise NotImplementedError("door release is not supported by the hardware") from e

    @check_side
    def nvm_read_raw(self, side: Side, page: int, length: int) -> bytes:
        """Reads the NVM raw data for the specified side.

        Args:
            side: side for which to read the NVM
            page: address of the NVM page to read
            length: number of bytes to read

        Returns:
            data read from the NVM

        Raises:
            NovaError: if Nova HAL raise an error while reading the NVM
        """
        return nvm_read(page=page, side=side, length=length, comms=self._projectors[side].comms)

    @check_side
    def nvm_read(
        self, side: Side, page: int = nvm_get_customer_block_address(0), length: int = CPNvmLatest.SIZE
    ) -> CPNvm:
        """Reads the NVM for the specified side.

        Args:
            side: side for which to read the NVM
            page: address of the NVM page to read
            length: number of bytes to read

        Returns:
            decoded `CPNvm` object with the data read from the NVM

        Raises:
            NovaError: if Nova HAL raise an error while reading the NVM
        """
        return CPNvm.unpack(self.nvm_read_raw(side=side, page=page, length=length))

    @check_side
    def nvm_write_raw(self, side: Side, data: bytes, page: int = nvm_get_customer_block_address(0)) -> None:
        """Writes raw data to the NVM for the specified side.

        Args:
            side: side for which to write the NVM
            data: data to write to the NVM
            page: address of the NVM page to write

        Raises:
            NovaError: if Nova HAL raise an error while writing the NVM

        Note:
            Currently the NVM can only be written if Nova HAL is running. So for splash-screen sequences
            the projector controller will be rebooted in Nova HAL mode, the NVM will be written and
            then the projector controller will be rebooted in splash-screen mode.
        """
        error: Exception | None = None
        # Check if the electronics is in Nova HAL mode
        try:
            nova_hal_mode = get_nova_hal_mode(self._projectors[side].comms)
        except NotAcknowledgedError:
            # Assume it's an old firmware if the API is not supported/NAK'd
            nova_hal_mode = NovaHalMode.NOVA_HAL

        if nova_hal_mode != NovaHalMode.NOVA_HAL:
            # Save state
            led_state = self.get_led_state(side)
            # TODO: should also save current splash screen
            # Set Nova HAL mode and reboot
            set_nova_hal_mode(NovaHalMode.NOVA_HAL, self._projectors[side].comms)
            self._reboot_controllers([self._projectors[side]], self.RECONNECT_TIME_MAX_DEFAULT)
        # Write to NVM
        try:
            nvm_write(page=page, side=side, data=data, comms=self._projectors[side].comms)
        except NovaError as e:
            error = e
        if nova_hal_mode != NovaHalMode.NOVA_HAL:
            # Set splash screen mode and reboot
            set_nova_hal_mode(NovaHalMode.SPLASH_SCREEN, self._projectors[side].comms)
            self._reboot_controllers([self._projectors[side]], self.RECONNECT_TIME_MAX_DEFAULT)
            # Restore state
            self.set_led_state(side, led_state)
            # TODO: should also restore the splash screen
        # Reraise error if any
        if error:
            raise error

    @check_side
    def nvm_write(self, side: Side, nvm: CPNvm, page: int = nvm_get_customer_block_address(0)) -> None:
        """Writes the NVM for the specified side.

        Args:
            side: side for which to write the NVM
            nvm: `CPNvm` object with the data to write to the NVM
            page: address of the NVM page to write

        Raises:
            NovaError: if Nova HAL raise an error while writing the NVM

        Note:
            See note for [`nvm_write_raw`][wopcprotocol.test_station.TestStation.nvm_write_raw].
        """
        self.nvm_write_raw(side, nvm.pack(), page)

    @check_side
    def nvm_read_panel_uid(self, side: Side) -> bytes:
        """Reads the panel UID for the specified side.

        Args:
            side: side for which to read the panel UID

        Returns:
            bytes with the panel UID
        """
        return nvm_read_panel_uid(side=side, comms=self._projectors[side].comms)

    @check_side
    def get_panel_temperature(self, side: Side) -> float:
        """Returns the temperature of the panel for the specified side.

        Args:
            side: side for which to get the panel temperature

        Returns:
            temperature of the panel in Celsius
        """
        temperatures = get_panel_temperatures(comms=self._projectors[side].comms)
        return temperatures[side]

    @check_side
    def run_panel_ee_screening(self, side: Side) -> bool:
        """Runs the panel EE screening for the specified side.

        Args:
            side: side for which to run the panel EE screening

        Returns:
            True if the screening passed, False otherwise
        """
        return run_panel_ee_screening(side=side, comms=self._projectors[side].comms)

    @check_side
    def get_alarms(self, side: Side) -> list[Alarm]:
        """Returns the list of alarms for the specified side.

        Args:
            side: side for which to get the alarms

        Returns:
            list of the alarms currently active for the specified side
        """
        alarms: list[TestStation.Alarm] = []
        data = self._get(comms=self._projectors[side].comms, target=Targets.MCU, cmd=self._Cmd.ERR)
        flags = struct.unpack("<I", data)[0]
        # EVT electronics?
        if self._projectors[side].type in [
            TestStation.ControllerType.EVT_BASEBOARD,
            TestStation.ControllerType.EVT_ROBOT_BOARD_LEFT,
            TestStation.ControllerType.EVT_ROBOT_BOARD_RIGHT,
        ]:
            offset = 0 if side == Side.LEFT else 16
            # High VFs
            alarm_type = TestStation.AlarmType.HIGH_VF
            if flags & (1 << (0 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.GREEN_LED, alarm_type))
            if flags & (1 << (1 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.BLUE_LED, alarm_type))
            if flags & (1 << (2 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.RED_LED, alarm_type))
            # High temperatures
            alarm_type = TestStation.AlarmType.HIGH_TEMPERATURE
            if flags & (1 << (4 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.GREEN_LED, alarm_type))
            if flags & (1 << (5 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.RED_LED, alarm_type))
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.BLUE_LED, alarm_type))
            if flags & (1 << (7 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.LCOS_PANEL, alarm_type))
            # Low Vfs
            alarm_type = TestStation.AlarmType.LOW_VF
            if flags & (1 << (8 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.GREEN_LED, alarm_type))
            if flags & (1 << (9 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.BLUE_LED, alarm_type))
            if flags & (1 << (10 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.RED_LED, alarm_type))
            # Low temperatures
            alarm_type = TestStation.AlarmType.LOW_TEMPERATURE
            if flags & (1 << (12 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.GREEN_LED, alarm_type))
            if flags & (1 << (13 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.RED_LED, alarm_type))
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.BLUE_LED, alarm_type))
            if flags & (1 << (15 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.LCOS_PANEL, alarm_type))
        else:
            # ProtoA.. this is fun!
            offset = 0 if side == Side.LEFT else 5
            # High VFs
            alarm_type = TestStation.AlarmType.HIGH_VF
            if flags & (1 << (0 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.GREEN_LED, alarm_type))
            if flags & (1 << (1 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.BLUE_LED, alarm_type))
            if flags & (1 << (2 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.RED_LED, alarm_type))
            # Low Vfs
            alarm_type = TestStation.AlarmType.LOW_VF
            if flags & (1 << (8 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.GREEN_LED, alarm_type))
            if flags & (1 << (9 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.BLUE_LED, alarm_type))
            if flags & (1 << (10 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.RED_LED, alarm_type))
            # High temperatures
            offset = 0 if side == Side.LEFT else 2
            alarm_type = TestStation.AlarmType.HIGH_TEMPERATURE
            if flags & (1 << (16 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.GREEN_LED, alarm_type))
            if flags & (1 << (17 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.RED_LED, alarm_type))
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.BLUE_LED, alarm_type))
            # Low temperatures
            alarm_type = TestStation.AlarmType.LOW_TEMPERATURE
            if flags & (1 << (24 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.GREEN_LED, alarm_type))
            if flags & (1 << (25 + offset)):
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.RED_LED, alarm_type))
                alarms.append(TestStation.Alarm(TestStation.AlarmTarget.BLUE_LED, alarm_type))
        return alarms

    def get_led_stand_status(self, side: Side) -> bool:
        """Returns the status of the LED stand for the specified side.

        Args:
            side: side for which to get the LED stand status

        Returns:
            True if the LED stand is detected and in the upright position, False otherwise

        Raises:
            NotImplementedError: if the LED stand status is not supported by the hardware
        """
        return self._get_digital_input(self._LED_STAND_INPUT_PINS[side])

    def get_vacuum_status(self, side: Side) -> bool:
        """Returns the status of the vacuum sensor for the specified side.

        Args:
            side: side for which to get the vacuum status

        Returns:
            True if the level of vacuum is adequate, False otherwise

        Raises:
            NotImplementedError: if the vacuum status is not supported by the hardware
        """
        return self._get_digital_input(self._VACUUM_INPUT_PINS[side])

    def set_digital_output(self, output: DigitalOutput, state: bool) -> None:
        """Sets the state of a digital output.

        Args:
            output: digital output to set
            state: True if the output should be on, False otherwise

        Raises:
            NotImplementedError: if the digital output is not supported by the hardware
        """
        for pin in self._OUTPUT_PINS[output]:
            self._set_digital_output(pin, state)
