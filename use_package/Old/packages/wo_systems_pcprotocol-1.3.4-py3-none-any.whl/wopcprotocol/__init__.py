from importlib.metadata import PackageNotFoundError, version

from wopcprotocol.protocol import Commands, Protocol, Targets

try:
    __version__ = version("wo-systems-pcprotocol")
except PackageNotFoundError:
    __version__ = "unknown"

__all__ = ["__version__", "Protocol", "Commands", "Targets"]
