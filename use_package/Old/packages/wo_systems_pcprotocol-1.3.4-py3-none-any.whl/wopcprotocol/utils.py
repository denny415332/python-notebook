import logging
from collections.abc import Callable
from dataclasses import dataclass
from struct import pack, unpack
from typing import Any, TypeVar, cast

from wopcprotocol.common import OrientAlign, Side
from wopcprotocol.errors import NotAcknowledgedError
from wopcprotocol.protocol import Commands, Hardware, Protocol, Targets
from wopcprotocol.raw_spi import SPIDevices
from wopcprotocol.raw_spi import read as spi_read

logger = logging.getLogger(__name__)


@dataclass(frozen=True, kw_only=True)
class McuStatus:
    """Status of the MCU in a projector-driving device.

    Args:
        display_adapter: the status of the display adapter
        panels: whether the left and right panels are connected
        last_reset: last reset reason (bit field encoded)
        last_timeout_task: if the last reset was due to a watchdog timeout, the task that timed out
    """

    display_adapter: bool
    panels: dict[Side, bool]
    last_reset: int
    last_timeout_task: int


def get_mcu_status(comms: Protocol) -> McuStatus:
    """Get the status of the MCU in a projector-driving device.

    Args:
        comms: reference to the com port object to use
    """
    response = comms.send(command=Commands.GET_STATUS, target=Targets.MCU)
    data = unpack("<BBBxBB", response.payload)
    return McuStatus(
        display_adapter=bool(data[0]),
        panels={Side.LEFT: bool(data[1]), Side.RIGHT: bool(data[2])},
        last_reset=data[3],
        last_timeout_task=data[4],
    )


def reboot_mcu(comms: Protocol) -> None:
    """Reboot the MCU.

    Args:
        comms: reference to the com port object to use
    """
    comms.send(command=Commands.REBOOT_DEVICE, target=Targets.MCU)


def reboot_to_dfu(comms: Protocol) -> None:
    """Reboot the MCU into DFU mode.

    Args:
        comms: reference to the com port object to use
    """
    comms.send(command=Commands.REBOOT_DEVICE_DFU, target=Targets.MCU)


def set_orient_align(side: Side, orient_align: OrientAlign, comms: Protocol) -> None:
    """Set the orientation and alignment of a projector.

    Args:
        side: the side of the projector to set
        orient_align: the orientation and alignment to set
        comms: reference to the com port object to use
    """
    payload = pack(
        "<??bb",
        orient_align.short_axis_flip,
        orient_align.long_axis_flip,
        orient_align.short_axis_shift,
        orient_align.long_axis_shift,
    )
    comms.send(command=Commands.SET_ORIENT_ALIGN, target=Targets(side.value), payload=payload)


def get_orient_align(side: Side, comms: Protocol) -> OrientAlign:
    """Get the orientation and alignment of a projector.

    Args:
        side: the side of the projector to get
        comms: reference to the com port object to use

    Returns:
        the orientation and alignment of the projector
    """
    response = comms.send(command=Commands.GET_ORIENT_ALIGN, target=Targets(side.value))
    short_axis_flip, long_axis_flip, short_axis_shift, long_axis_shift = unpack("<??bb", response.payload)
    return OrientAlign(
        short_axis_flip=short_axis_flip,
        long_axis_flip=long_axis_flip,
        short_axis_shift=short_axis_shift,
        long_axis_shift=long_axis_shift,
    )


def get_lcos_power_status(comms: Protocol) -> bool:
    """Return the status of the LCoS power.

    Args:
        comms: reference to the com port object to use

    Returns:
        True if the panel is powered, False otherwise.
    """
    response = comms.send(
        command=Commands.GET_HARDWARE_STATE, target=Targets.MCU, payload=bytes([Hardware.PANEL_DRIVERS])
    )
    return not bool(response.payload[1])


def disable_lcos_power(comms: Protocol) -> None:
    """Power down the LCoS.

    Args:
        comms: reference to the com port object to use

    Returns:
        None.
    """
    comms.send(command=Commands.SET_HARDWARE_STATE, target=Targets.MCU, payload=bytes([Hardware.PANEL_DRIVERS, 1]))


def get_panel_temperatures(comms: Protocol) -> dict[Side, float]:
    """Get the temperatures of the left and right panels.

    Args:
        comms: reference to the com port object to use

    Returns:
        dictionary with the temperatures of the left and right panels
    """
    response = comms.send(command=Commands.GET_ADC_READINGS, target=Targets.MCU)
    return dict(
        zip(
            [Side.LEFT, Side.RIGHT],
            [round(value / 100.0, 1) for value in unpack("<HH", response.payload[18:22])],
            strict=False,
        )
    )


F = TypeVar("F", bound=Callable[..., Any])


def catch_nak(
    logger: Callable[[Any], Any] | None = None, message: str | None = None, reraise: bool = True
) -> Callable[[F], F]:
    """This function is thought to be used as a decorator to other functions or class methods that might raise a [`NotAcknowledgedError`][wopcprotocol.errors.NotAcknowledgedError] exception.

    Args:
        logger: callable used to print the message if the exception is caught
        message: message to be printed by the passed logger
        reraise: raise the original exception after logging the message if True, suppresses the exception otherwise
    """  # noqa: E501

    def inner_dec(func: F) -> F:
        def wrapped(*args: Any, **kwargs: Any) -> Any:
            try:
                return func(*args, **kwargs)
            except NotAcknowledgedError:
                if logger is not None:
                    msg = f"NAK in {func.__module__}:{func.__name__}" if message is None else message
                    logger(msg)
                if reraise:
                    raise

        return cast(F, wrapped)

    return inner_dec


def run_panel_ee_screening(side: Side, comms: Protocol) -> bool:
    """Run a built-in EE screening test on the panel.

    Args:
        side: which panel to test
        comms: reference to the com port object to use
    """

    def header_count_test(side: Side, comms: Protocol) -> bool:
        n_tests = 3
        counts = []
        try:
            for _ in range(n_tests):
                data = spi_read(target=side, device=SPIDevices.PANEL_LCOS, addr=0x005D, size=2, comms=comms)
                counts.append(unpack("<H", data)[0])
            # Check that all the counts are different
            if len(counts) != len(set(counts)):
                return False
        except NotAcknowledgedError:
            return False
        return True

    def crc_test(side: Side, comms: Protocol) -> bool:
        try:
            data = spi_read(target=side, device=SPIDevices.PANEL_LCOS, addr=0x005F, size=2, comms=comms)
            crc = unpack("<H", data)[0]
            if crc > 0:
                return False
        except NotAcknowledgedError:
            return False
        return True

    def panel_temperature_test(side: Side, comms: Protocol) -> bool:
        t_min = 10.0
        t_max = 70.0
        temperature = get_panel_temperatures(comms)[side]
        return temperature >= t_min and temperature <= t_max

    tests = [header_count_test, crc_test, panel_temperature_test]
    for test in tests:
        if not test(side, comms):
            logger.warning(f"EE screening failed: {test.__name__.replace('_', ' ')}")
            return False
    return True
