"""This module is used to fetch and parse Compound Photonics (CP) sequence meta information.

The electronics stores the CRC of the sequence file (used as unique ID)
which is then used to look for the file in the local filesystem or on the remote server.
"""

import json
import logging
import pkgutil
import re
import tempfile
from dataclasses import dataclass
from pathlib import Path
from struct import unpack
from typing import Any

import requests
from typing_extensions import Self

from wopcprotocol.common import LedDutyCycle, Side
from wopcprotocol.errors import SequenceNotFoundError
from wopcprotocol.protocol import Commands, Protocol

_cache = {}

logger = logging.getLogger(__name__)


def _crc_int_to_str(crc: int) -> str:
    return f"{crc:08x}"


@dataclass(frozen=True, kw_only=True)
class CPSequence:
    """Dataclass for information on a sequence.

    Args:
        filename: name of the sequence file
        crc: CRC of the sequence file
        resolution: resolution of the sequence
        refresh_rate: refresh rate of the sequence in Hz
        is_binocular: whether the sequence is binocular (if available)
        duty_cycle: duty cycle of the sequence
        index: index of the sequence (if available)
        data: raw json file of the sequence containing all the information
    """

    filename: str
    crc: str
    resolution: tuple[int, int]
    refresh_rate: int
    is_binocular: bool | None
    duty_cycle: LedDutyCycle
    index: int | None
    data: object

    @staticmethod
    def _parse_duty_cycle(value: str) -> LedDutyCycle:
        match_object = re.search(r"([RGB])([RGB])([RGB])(\d{2})(\d{2})(\d{2})", value)
        if match_object is None:
            raise ValueError("cannot parse duty cycle string")
        duty_cycle_dict = dict(
            zip(
                [match_object[1], match_object[2], match_object[3]],
                [match_object[4], match_object[5], match_object[6]],
                strict=False,
            )
        )
        return LedDutyCycle(
            red=float(duty_cycle_dict["R"]), green=float(duty_cycle_dict["G"]), blue=float(duty_cycle_dict["B"])
        )

    @classmethod
    def parse(cls, json_dict: dict[str, Any], crc: str) -> Self:
        """Parses a json dictionary into a CPSequence object.

        Args:
            json_dict: dictionary containing the sequence information
            crc: CRC of the sequence file
        """
        resolution_field = "resolution" if "resolution" in json_dict["cpdr file info"] else "hostOutputResolution"
        if "csfTiming" in json_dict["cpdr file info"]:
            duty_cycle_dict = {
                key: float(json_dict["cpdr file info"]["csfTiming"][key]["dutyCycle"])
                for key in ["red", "green", "blue"]
            }
            duty_cycle = LedDutyCycle(**duty_cycle_dict)
        else:
            duty_cycle = CPSequence._parse_duty_cycle(json_dict["LedDutyCycle"])
        return cls(
            filename=json_dict["file_name"] if "file_name" in json_dict else json_dict["filename"],
            crc=crc,
            resolution=(
                int(json_dict["cpdr file info"][resolution_field][0]),
                int(json_dict["cpdr file info"][resolution_field][1]),
            ),
            refresh_rate=json_dict["cpdr file info"][resolution_field][2],
            is_binocular=json_dict["cpdr file info"]["isBinocular"] != 0
            if "isBinocular" in json_dict["cpdr file info"]
            else None,
            duty_cycle=duty_cycle,
            index=json_dict.get("index"),
            data=json_dict,
        )


@dataclass(frozen=True)
class CPTestImage:
    """Contains information on a test image.

    Args:
        name: name of the test image
        index: index of the test image
    """

    name: str
    index: int

    @classmethod
    def parse(cls, json: dict[str, Any]) -> Self:
        """Parses a json dictionary into a CPTestImage object.

        Args:
            json: dictionary containing the test image information
        """
        return cls(name=json["name"], index=json["index"])

    @property
    def printable_name(self) -> str:
        """Returns a printable name for the test image."""
        match = re.search(r"^(SPLASH_SCREEN_)(\w+)$", self.name)
        if match:
            return match.group(2).lower().capitalize()
        return self.name


@dataclass(frozen=True)
class CPTestImages:
    """Contains information on a list of test images.

    Args:
        filename: name of the binary file containing the test images
        images: list of test images
        crc: CRC of the test image file
    """

    filename: str
    images: list[CPTestImage]
    crc: str

    @classmethod
    def parse(cls, json: dict[str, Any], crc: str) -> Self:
        """Parses a json dictionary into a CPTestImages object.

        Args:
            json: dictionary containing the test images information
            crc: CRC of the test image file
        """
        return cls(filename=json["filename"], images=list(map(CPTestImage.parse, json["images"])), crc=crc)


@dataclass(frozen=True, kw_only=True)
class CPPanelData:
    """Represents a data pack for driving a panel and it is composed of a list of sequences and test images.

    Args:
        filename: name of the panel data file (if available)
        crc: CRC of the file
        sequences: list of sequences in the panel data
        test_images: test images in the panel data
        data: raw json file of the image file containing all the information
    """

    filename: str
    crc: str
    sequences: list[CPSequence]
    test_images: CPTestImages | None
    data: object

    @classmethod
    def parse(cls, json: dict[str, Any], crc: str) -> Self:
        """Parses a json dictionary into a CPPanelData object.

        Args:
            json: dictionary containing the panel data information
            crc: CRC of the file
        """
        filename = ""
        if "img filename" in json:
            filename = json["img filename"]
        elif "Img Filename" in json:
            filename = json["Img Filename"]

        test_images = None
        if "Images" in json:
            test_images = CPTestImages(filename=filename, images=list(map(CPTestImage.parse, json["Images"])), crc=crc)
        elif "Test Images" in json:
            test_images = CPTestImages.parse(json["Test Images"], json["Test Images"]["crc"])
        return cls(
            filename=filename,
            crc=crc,
            sequences=[CPSequence.parse(seq_json, seq_json.get("crc", crc)) for seq_json in json["Sequences"]]
            if "Sequences" in json
            else [],
            test_images=test_images,
            data=json,
        )


def _get_filename(crc: str) -> str:
    return crc + ".json"


def _get_tmp_dir() -> Path:
    return Path(tempfile.gettempdir()) / "cp_sequences"


def _fetch_from_server(crc: str) -> CPPanelData:
    url = f"https://waveoptics.bitbucket.io/cp_sequences/{_get_filename(crc)}"
    response = requests.get(url)
    if response.status_code != requests.status_codes.codes["ok"]:
        raise Exception(f"return code {response.status_code}")
    json_data = json.loads(response.text)
    _cache[crc] = CPPanelData.parse(json_data, crc)
    _save_to_tmp_dir(json_data, crc)
    return _cache[crc]


def _read_from_tmp_dir(crc: str) -> CPPanelData:
    file_path = _get_tmp_dir() / _get_filename(crc)
    if not file_path.is_file():
        raise FileNotFoundError
    with file_path.open() as f:
        _cache[crc] = CPPanelData.parse(json.load(f), crc)
    return _cache[crc]


def _save_to_tmp_dir(sequence: dict[str, object], crc: str) -> None:
    temp_dir = _get_tmp_dir()
    temp_dir.mkdir(parents=True, exist_ok=True)
    file_path = temp_dir / _get_filename(crc)
    with file_path.open(mode="w") as f:
        json.dump(sequence, f)


def _read_from_local_fs(crc: str) -> CPPanelData:
    file_path = Path(_get_filename(crc))
    if not file_path.is_file():
        raise FileNotFoundError
    with file_path.open() as f:
        _cache[crc] = CPPanelData.parse(json.load(f), crc)
    return _cache[crc]


def _read_from_package(crc: str) -> CPPanelData:
    bin_data = pkgutil.get_data(
        __package__,
        str(
            (Path(__file__).parent / "resources" / "cp_sequences" / _get_filename(crc)).relative_to(
                Path(__file__).parent
            )
        ),
    )
    if bin_data is None:
        raise FileNotFoundError
    data = bin_data.decode()
    _cache[crc] = CPPanelData.parse(json.loads(data), crc)
    return _cache[crc]


def get_sequence_crc(side: Side, comms: Protocol) -> int:
    """Retrieves the CRC of the sequence image file from the device.

    Args:
        side: side for which to retrieve the crc of the sequence
        comms: reference to the com port object to use

    Returns:
        the CRC of the sequence image file

    Raises:
        NotAcknowledgedError: if the CRC could not be retrieved

    Note:
        On Avalon panels it is assumed that the sequence is the same for both sides (cause the sequence is actually stored on the electronics's SPI memory).
        On Comet, each panel stores both sequence and test images information, so the left and right sides CRCs are potentially different.
    """  # noqa: E501
    response = comms.send(command=Commands.GET_DEVICE_VERSION, target=side)
    crc: int = unpack("<12xI", response.payload)[0]
    return crc


def get_sequence(crc: str | int) -> CPPanelData:
    """Retrieves the sequence image file (json) from the local filesystem or from the remote server.

    The json file is looked for in the following order:

    - cache
    - local filesystem (in the same folder as the main script)
    - temporary folder (OS dependent)
    - remote server
    - package

    Args:
        crc: the CRC of the sequence image file

    Returns:
        the file parsed as a `CPSequenceImg` object

    Raises:
        SequenceNotFoundError: if the sequence image file could not be found
    """
    if isinstance(crc, int):
        # Convert to string
        crc = _crc_int_to_str(crc)
    # Check cache
    if crc in _cache:
        return _cache[crc]
    # Check local fs
    try:
        return _read_from_local_fs(crc)
    except FileNotFoundError:
        logger.debug(f"{crc} sequence not found in local file system")
    # Try from temporary folder
    try:
        return _read_from_tmp_dir(crc)
    except FileNotFoundError:
        logger.debug(f"{crc} sequence not found in temporary folder")
    # Try to fetch it from server
    try:
        return _fetch_from_server(crc)
    except Exception as e:
        logger.debug(f"{crc} sequence not found on remote server: {e}")
    # Check in the package
    try:
        return _read_from_package(crc)
    except FileNotFoundError:
        logger.debug(f"{crc} sequence not found in package")
    raise SequenceNotFoundError
