import logging
import sys
from enum import IntEnum
from struct import unpack

from crc import Calculator, Crc16

from wopcprotocol.errors import NotAcknowledgedError
from wopcprotocol.protocol import Commands, Protocol, Targets

logger = logging.getLogger(__name__)


class FlashCommands(IntEnum):
    COMMAND_FLASH_ACCESS = 0x00
    COMMAND_FLASH_ERASE = 0x01
    COMMAND_FLASH_READ_CRC = 0x02
    COMMAND_FLASH_WRITE = 0x03
    COMMAND_FLASH_THROUGHPUT_TEST = 0xFF


def flash_write(filename: str, target: Targets, comms: Protocol) -> bool:
    # enable access to flash
    comms.send(command=Commands.FLASH_UPDATE, target=target, payload=bytes([FlashCommands.COMMAND_FLASH_ACCESS, 0x01]))
    # erase flash
    logger.info("erasing flash (upto 20s)")
    comms.send(
        command=Commands.FLASH_UPDATE,
        target=target,
        payload=bytes([FlashCommands.COMMAND_FLASH_ERASE, 0xFF, 0xFF]),
        timeout=200.0,
    )
    logger.info("writing to flash")
    file = open(filename, "rb").read()
    if not _write_file(file, target, comms):
        logger.error("file write error")
        return False
    logger.info("verifying (upto 20s)")
    if not _check_file(file, target, comms):
        logger.error("verify failure")
        return False

    logger.info("flash write successful")
    return True


def _write_file(
    file: bytes, target: Targets, comms: Protocol, *, flash_blank_sectors: bool = True, show_progressbar: bool = True
) -> bool:
    packet_num = 0
    file_len = len(file)
    flash_pkt_size = min(file_len, 1024)
    payload = bytearray(flash_pkt_size + 5)
    while file:
        address = packet_num * flash_pkt_size
        payload[0] = FlashCommands.COMMAND_FLASH_WRITE
        payload[1] = address & 0xFF
        payload[2] = (address >> 8) & 0xFF
        payload[3] = (address >> 16) & 0xFF
        payload[4] = (address >> 24) & 0xFF
        transmit = flash_blank_sectors

        for i in range(flash_pkt_size):
            if (i + address) == file_len:
                break
            payload[i + 5] = file[i + address]
            if not transmit and file[i + address] != 0xFF:
                transmit = True
        if transmit:
            try:
                comms.send(command=Commands.FLASH_UPDATE, target=target, payload=payload)
            except NotAcknowledgedError:
                return False
        packet_num += 1
        bytes_written = address + flash_pkt_size
        # update progress bar
        if show_progressbar:
            _progress(bytes_written, file_len)
    if show_progressbar:
        sys.stdout.write("\n")
    return True


def _check_file(file: bytes, target: Targets, comms: Protocol) -> bool:
    payload = bytes([FlashCommands.COMMAND_FLASH_READ_CRC])
    payload += len(file).to_bytes(4, byteorder="little")
    try:
        response = comms.send(command=Commands.FLASH_UPDATE, target=target, payload=payload, timeout=30.0)
        crc = unpack("<xH", response.payload[:3])[0]
        if Calculator(Crc16.IBM_3740.value).verify(file, crc):
            return True
    except NotAcknowledgedError:
        pass
    return False


def _progress(count: int, total: int, suffix: str = "") -> None:
    if count > total:
        count = total
    bar_len = 60
    filled_len = int(round(bar_len * count / float(total)))

    percents = round(100.0 * count / float(total), 1)
    bar = "=" * filled_len + "-" * (bar_len - filled_len)

    logger.debug(f"current progress={percents}%")

    sys.stdout.write(f"[{bar}] {percents}% {suffix}\r")
    sys.stdout.flush()
