"""This module contains common definitions and data structures shared across different class of devices."""

from typing import Any, Literal

from wopcprotocol.protocol import Commands, DeviceInfo, Electronics, Hardware, Protocol, Targets

Fan = Literal[Hardware.FAN_INTERNAL, Hardware.FAN_EXTERNAL]


class Device:
    """Base class for all the devices."""

    _ELECTRONICS: tuple[Electronics, ...] = (Electronics.HADES, Electronics.AGNI, Electronics.BLAZE)

    @classmethod
    def list_devices(cls) -> tuple[DeviceInfo, ...]:
        """List all the devices connected to the system.

        Returns:
            list of `DeviceInfo` objects related to the devices connected
        """
        return Protocol.list_devices_by_electronics(cls._ELECTRONICS)

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """Initialize the device.

        Args:
            *args: arguments to be passed down to the [`Protocol`][wopcprotocol.protocol.Protocol] constructor
            **kwargs: keyword arguments to be passed down to the [`Protocol`][wopcprotocol.protocol.Protocol] constructor

        Raises:
            ConnectionError: if the device type is not in the list of supported devices
        """
        self.comms = Protocol(*args, **kwargs)
        if self.comms.electronics not in self._ELECTRONICS:
            raise ConnectionError(f"device type is not in ({self._ELECTRONICS})")

    def close(self) -> None:
        """Close the connection to the device."""
        self.comms.close()


def set_fan(fan: Fan, enable: bool, comms: Protocol) -> None:
    """Set the state of the fan.

    Args:
        fan: the fan to control
        enable: the state to set the fan to
        comms: reference to the comms object
    """
    comms.send(command=Commands.SET_HARDWARE_STATE, target=Targets.MCU, payload=bytearray([fan.value, int(enable)]))


def get_fan(fan: Fan, comms: Protocol) -> bool:
    """Returns the state of the fan.

    Args:
        fan: the fan to query
        comms: reference to the comms object
    """
    response = comms.send(command=Commands.GET_HARDWARE_STATE, target=Targets.MCU, payload=bytes([fan.value]))
    return bool(response.payload[1])
