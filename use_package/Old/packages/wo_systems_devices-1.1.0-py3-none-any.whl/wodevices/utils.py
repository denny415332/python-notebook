"""This module provides utility functions for the wodevices package."""

import logging

from wopcprotocol.protocol import Electronics, Protocol

from wodevices import Agni, Blaze, Hades
from wodevices.common import Device

logger = logging.getLogger(__name__)


def connect() -> Device | None:
    """Attempt to automatically connect to one of the devices provided and returns a handle to it.

    Returns:
        instance of the device found and opened or `None` if the device is not compatible or no devices are found
    """
    device: Device | None = None
    all_devices_info = Protocol.list_devices_by_electronics([Electronics.HADES, Electronics.AGNI, Electronics.BLAZE])
    if len(all_devices_info) == 0:
        logger.warning("no devices found")
        return None
    for device_info in all_devices_info:
        if device_info.electronics == Electronics.HADES:
            device = Hades(device_info.serial_number)
        elif device_info.electronics == Electronics.AGNI:
            device = Agni(device_info.serial_number)
        elif device_info.electronics == Electronics.BLAZE:
            device = Blaze(device_info.serial_number)
        else:
            logger.warning("device is not compatible")
        if device is not None:
            break
    return device
