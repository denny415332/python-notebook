from importlib.metadata import PackageNotFoundError, version

from wodevices.hades import Hades
from wodevices.led_driver import Agni, Blaze

try:
    __version__ = version(__name__)
except PackageNotFoundError:
    __version__ = "unknown"

__all__ = ["__version__", "Hades", "Agni", "Blaze"]
