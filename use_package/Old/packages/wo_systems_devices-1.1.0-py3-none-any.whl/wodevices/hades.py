"""This module contains classes, methods, and definitions to control a Hades board.

Refer to the [Installation](index.md#Installation) section to install the package and the system's requirements.
Also few examples are provided to cover the most common operating modes.

!!! example "Examples"
    === "Connect to Hades"
        ``` python
        from wodevices import Hades

        # Connect
        hades = Hades()
        # or
        hades = Hades(device_id='0028005F303150102039354D')
        # to connect to a device with a given serial number
        # or
        boards = [Hades(device_id=0), Hades(device_id=1)]
        # to connect to multiple boards
        ```
    === "Current Control"
        ``` python
        from wodevices import Hades

        # Driver to target
        DRIVER = Hades.CurrentDriver.ULED_DRIVER

        # Connect
        hades = Hades()
        # Enable the micro-LED current driver
        hades.set_current_driver(DRIVER, True)
        # Enable individual outputs
        hades.set_output(DRIVER, [True, False, False, True])
        # Set the DAC register
        hades.set_dac_register(DRIVER, [4096, 0, 0, 65535])
        ```
    === "Forward Voltage Measurement"
        ``` python
        from wodevices import Hades
        import time

        # Driver to target and current dac register
        DRIVER = Hades.CurrentDriver.MEASUREMENT_DIODE_DRIVER
        CURRENT_DAC = 4095
        N_MEASUREMENTS = 10

        # Connect
        hades = Hades()
        # Enable the diode current driver
        hades.set_current_driver(DRIVER, True)
        # Enable individual outputs
        hades.set_output(DRIVER, [True, True, True, True])
        # Set the DAC register
        hades.set_dac_register(DRIVER, [CURRENT_DAC]*Hades.Module.MODULE_N)

        # Measure
        for i in range(N_MEASUREMENTS):
            print(hades.get_diode_forward_voltage())
            time.sleep(1)
        ```
    === "Temperature Control"
        ``` python
        import time

        from wodevices import Hades
        from wodevices.temperature_ctrl import PidLimits, PidParameters

        # The module to target
        MODULE = Hades.Module.MODULE_1

        # Connect
        hades = Hades()
        # Turn off temperature control before changing the settings
        hades.temperature_controllers[MODULE].set(False)
        # Set the PID parameters and operating limits
        hades.temperature_controllers[MODULE].set_pid_parameters(PidParameters(kp=5.0, ki=1.2, kd=0.0))
        hades.temperature_controllers[MODULE].set_pid_limits(PidLimits(min=-5.0, max=5.0))
        # Enable temperature control
        hades.temperature_controllers[MODULE].set(True)
        # Change the temperature set point
        hades.temperature_controllers[MODULE].set_temperature_ref(35.0)
        # Wait for the temperature to settle
        while True:
            if hades.temperature_controllers[MODULE].get_status().temperature_stable:
                break
            time.sleep(1)
```
"""

import logging
import sys
from collections.abc import Sequence
from dataclasses import dataclass
from enum import IntEnum
from struct import calcsize, pack, unpack
from typing import Any, ClassVar, TypedDict

if sys.version_info >= (3, 11):
    from typing import Self
else:
    from typing_extensions import Self

from wopcprotocol.protocol import Commands, Electronics, Hardware, Targets

from wodevices.common import Device
from wodevices.temperature_ctrl import TemperatureController, TemperatureCtrlStatus, TemperatureSensorType

logger = logging.getLogger(__name__)


class Hades(Device):
    """A class to connect and control a Hades board."""

    class _Commands(IntEnum):
        GET_DIODE_FORWARD_VOLTAGE = 0x80

    class CurrentDriver(IntEnum):
        """Identifier for the current drivers."""

        ULED_DRIVER = 0
        """Targets the micro-LED current driver"""
        MEASUREMENT_DIODE_DRIVER = 1
        """Targets the temperature-measurement-diode current driver"""

    class Module(IntEnum):
        """Identifier for the modules plugged into Hades."""

        MODULE_1 = 0
        """Module labelled as 'MOUNT CH 1'"""
        MODULE_2 = 1
        """Module labelled as 'MOUNT CH 2'"""
        MODULE_3 = 2
        """Module labelled as 'MOUNT CH 3'"""
        MODULE_4 = 3
        """Module labelled as 'MOUNT CH 4'"""
        MODULE_N = 4
        """Number of modules"""

    @dataclass
    class AdcReadings:
        """Collection of periodically acquired ADC readings.

        Args:
            timestamp: milliseconds since the MCU boot
            mcu_temperature: temperature as recorded from the internal MCU sensor
            i2c_sensors: temperatures of the I2C sensors of the external modules
            diode_sensors: temperatures from the sensing diodes of the external modules
        """

        timestamp: int
        mcu_temperature: float
        i2c_sensors: tuple[float | None, ...]
        diode_sensors: tuple[float | None, ...]

        @classmethod
        def unpack(cls, payload: bytes) -> Self:
            """Parse the a binary packet and returns the structure.

            Args:
                payload: binary packet received from the electronics

            Returns:
                the structure instantiated from the binary packet
            """
            data = unpack("<IhhhhhHHhhhh", payload)
            return cls(
                timestamp=data[0],
                mcu_temperature=data[1] / 10.0,
                i2c_sensors=tuple(None if x <= -32768 else x / 10.0 for x in data[2:6]),
                diode_sensors=tuple(None if x <= -32768 else x / 10.0 for x in data[8:12]),
            )

    class _LinearInterpolation(TypedDict):
        gain: float
        offset: float

    _CURRENT_DRIVER_DAC_MAX_COUNT = 0xFFFF
    _CURRENT_MAX_MA: ClassVar[dict[CurrentDriver, float]] = {
        CurrentDriver.ULED_DRIVER: 250.0,
        CurrentDriver.MEASUREMENT_DIODE_DRIVER: 0.250,
    }
    _CURRENT_COUNT_TO_MA: ClassVar[dict[CurrentDriver, _LinearInterpolation]] = {
        CurrentDriver.ULED_DRIVER: _LinearInterpolation(gain=0.004153311045, offset=-3.075637706),
        CurrentDriver.MEASUREMENT_DIODE_DRIVER: _LinearInterpolation(gain=0.000004589404528, offset=-0.01435339349),
    }

    _SUPPORTED_TEMPERATURE_SENSORS = (
        TemperatureSensorType.AUTO,
        TemperatureSensorType.I2C,
        TemperatureSensorType.DIODE,
    )

    _ELECTRONICS: tuple[Electronics, ...] = (Electronics.HADES,)

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """Initializes the connection to the device and the temperature controllers.

        Args:
            *args: arguments to be passed down to the parent class
            **kwargs: keyword arguments to be passed down to the parent class
        """
        super().__init__(*args, **kwargs)
        self.temperature_controllers = [
            TemperatureController(self.comms, self._SUPPORTED_TEMPERATURE_SENSORS, i)
            for i in range(self.Module.MODULE_N)
        ]

    @staticmethod
    def _current_to_dac(driver: CurrentDriver, current_ma: float) -> int:
        if current_ma >= 0.0 and current_ma <= Hades._CURRENT_MAX_MA[driver]:
            dac = int(
                (current_ma - Hades._CURRENT_COUNT_TO_MA[driver]["offset"]) / Hades._CURRENT_COUNT_TO_MA[driver]["gain"]
            )
            if dac < 0:
                logger.warning("DAC clipped to 0 during current to DAC conversion")
                dac = 0
            elif dac > Hades._CURRENT_DRIVER_DAC_MAX_COUNT:
                logger.warning(f"DAC clipped to {Hades._CURRENT_DRIVER_DAC_MAX_COUNT} during current to DAC conversion")
                dac = Hades._CURRENT_DRIVER_DAC_MAX_COUNT
            return dac
        raise ValueError(f"{driver.name} current must be a float between 0 and {Hades._CURRENT_MAX_MA[driver]}mA")

    @staticmethod
    def _dac_to_current(driver: CurrentDriver, dac: int) -> float:
        if isinstance(dac, int) and dac >= 0 and dac <= Hades._CURRENT_DRIVER_DAC_MAX_COUNT:
            current = dac * Hades._CURRENT_COUNT_TO_MA[driver]["gain"] + Hades._CURRENT_COUNT_TO_MA[driver]["offset"]
            if current < 0.0:
                logger.warning("current clipped to 0.0 during DAC to current conversion")
                current = 0.0
            return current
        raise ValueError(
            f"{driver.name} DAC register needs to be an int between 0 and {Hades._CURRENT_DRIVER_DAC_MAX_COUNT}"
        )

    def set_current_driver(self, driver: CurrentDriver, enable: bool) -> None:
        """Controls the status of the targeted current driver.

        Args:
            driver: current driver to be targeted
            enable: status of the driver
        """
        payload = pack("<BB", Hardware.LED_DRIVER, 1 if enable else 0)
        self.comms.send(command=Commands.SET_HARDWARE_STATE, target=driver, payload=payload)

    def get_current_driver(self, driver: CurrentDriver) -> bool:
        """Get the status of the targeted current driver.

        Args:
            driver: current driver to be targeted

        Returns:
            True if the driver is enabled, False otherwise
        """
        response = self.comms.send(
            command=Commands.GET_HARDWARE_STATE, target=driver, payload=bytes([Hardware.LED_DRIVER])
        )
        return bool(response.payload[1] & 0x1)

    def set_output(self, driver: CurrentDriver, outputs: Sequence[bool]) -> None:
        """Control individual outputs of a current driver.

        Args:
            driver: current driver to be targeted
            outputs: states of the outputs

        Raises:
            ValueError: if the length of the list does not match the number of modules
        """
        if len(outputs) != self.Module.MODULE_N:
            raise ValueError(f"a list of {self.Module.MODULE_N} booleans must be provided")
        status = 0x00
        for index, led in enumerate(outputs):
            if led:
                status |= 1 << index
        self.comms.send(command=Commands.SET_RGB_ENABLE, target=driver, payload=bytearray([status]))

    def get_output(self, driver: CurrentDriver) -> tuple[bool, ...]:
        """Get the status of the current driver outputs.

        Args:
            driver: current driver to be targeted

        Returns:
            status of the outputs
        """
        response = self.comms.send(command=Commands.GET_RGB_ENABLE, target=driver)
        status = response.payload[0]
        return (
            (status & 0x1) != 0,
            (status & 0x2) != 0,
            (status & 0x4) != 0,
            (status & 0x8) != 0,
        )

    def set_dac_register(self, driver: CurrentDriver, regs: Sequence[int]) -> None:
        """Set the DAC registers for all the outputs of the targeted driver.

        Args:
            driver: current driver to be targeted
            regs: registers for all the outputs

        Raises:
            ValueError: if the length of the list does not match the number of modules or the provided values are out range
        """
        if len(regs) != self.Module.MODULE_N:
            raise ValueError(f"a list of {self.Module.MODULE_N} int must be provided")
        if (
            len(list(filter(lambda x: x >= 0 and x <= self._CURRENT_DRIVER_DAC_MAX_COUNT, regs)))
            != self.Module.MODULE_N
        ):
            raise ValueError(f"register values must be between 0 and {self._CURRENT_DRIVER_DAC_MAX_COUNT}")
        payload = pack("<HHHHB", regs[0], regs[1], regs[2], regs[3], 0)
        self.comms.send(command=Commands.SET_RGB_CURRENT, target=driver, payload=payload)

    def get_dac_register(self, driver: CurrentDriver) -> tuple[int, ...]:
        """Returns the DAC registers for all the outputs of the targeted driver.

        Args:
            driver: current driver to be targeted

        Returns:
            dac settings for all the outputs
        """
        response = self.comms.send(command=Commands.GET_RGB_CURRENT, target=driver)
        return unpack("<HHHHx", response.payload)

    def set_current(self, driver: CurrentDriver, currents_ma: Sequence[float | int]) -> None:
        """Set the current for all the outputs of the targeted driver.

        Args:
            driver: current driver to be targeted
            currents_ma: current for all the outputs in mA

        !!! note
            The function converts the provided current values to a set of DAC registers and
            then calls [`set_dac_register`][wodevices.hades.Hades.set_dac_register]
        """
        regs = [self._current_to_dac(driver, x) for x in currents_ma]
        self.set_dac_register(driver, regs)

    def get_current(self, driver: CurrentDriver) -> tuple[float, ...]:
        """Get the current for all the outputs of the targeted driver.

        Args:
            driver: current driver to be targeted

        Returns:
            current values of the outputs

        !!! note
            The functions calls [`get_dac_register`][wodevices.hades.Hades.get_dac_register] and converts the returned
            values to mA
        """
        regs = self.get_dac_register(driver)
        return tuple(self._dac_to_current(driver, x) for x in regs)

    def get_diode_forward_voltage(self) -> tuple[float, ...]:
        """Returns the most recent readings of the diodes forward voltages.

        Returns:
            forward voltages for all modules in V

        !!! warning

            The function might return incorrect/unexpected values if the outputs are disabled or not connected
        """
        response = self.comms.send(command=self._Commands.GET_DIODE_FORWARD_VOLTAGE, target=Targets.MCU)
        return unpack("<ffffxxxx", response.payload)

    def get_temperature_ctrl_status_all(
        self,
    ) -> tuple[TemperatureCtrlStatus, ...]:
        """Get the full status of all temperature controllers.

        Returns:
            tuple of temperature controller statuses
        """
        response = self.comms.send(
            command=Commands.TEMPERATURE_CTRL,
            target=self.Module.MODULE_1,
            payload=bytearray([TemperatureController.Commands.GET_STATUS_ALL]),
        )
        payload = response.payload[1:]
        chunk_size = calcsize("<Bh")
        if len(payload) // chunk_size != self.Module.MODULE_N:
            raise ValueError("unexpected payload length")
        return tuple(
            TemperatureCtrlStatus.unpack(payload[i * chunk_size : (i + 1) * chunk_size])
            for i in range(self.Module.MODULE_N)
        )

    def get_adc_readings(self) -> AdcReadings:
        """Returns the most up to date ADC readings.

        Returns:
            most recent readings
        """
        response = self.comms.send(command=Commands.GET_ADC_READINGS, target=Targets.MCU)
        return self.AdcReadings.unpack(response.payload)
