"""Interactive shell for wodevices."""

import argparse
import sys

try:
    import IPython
    from traitlets.config import Config
except ModuleNotFoundError as e:
    raise ModuleNotFoundError("Install wo-systems-devices[shell] to use the interactive shell.") from e


def _start_shell(exec_lines: tuple[str, ...] = ()) -> None:
    c = Config()
    c.InteractiveShellApp.exec_lines = [
        "%load_ext autoreload",
        "%autoreload 2",
        "from wodevices import Hades, Agni, Blaze",
        "from wodevices.temperature_ctrl import TemperatureSensorType, PidParameters, PidLimits",
        "from wodevices.utils import connect",
    ]
    c.InteractiveShellApp.exec_lines += exec_lines
    IPython.start_ipython(config=c)  # type: ignore[no-untyped-call]


def main() -> None:
    """Entry point for the interactive shell."""
    parser = argparse.ArgumentParser(prog="wodevices shell")
    parser.add_argument("-c", "--connect", action="store_true")
    args = parser.parse_args()

    # iPython likes to capture argv, so lets reset it so that we don't accidentally send params to ipython
    sys.argv = [sys.argv[0]]

    # Launch IPython
    _start_shell(("device=connect()",) if args.connect else ())


if __name__ == "__main__":
    main()
