"""This module contains the errors used in the package."""


class WODevicesError(Exception):
    """Base class for all the error raised by `wodevices`."""


class UncalibratedTemperatureSensorError(WODevicesError):
    """Raised when the electronics does not have valid calibration data for the temperature sensor."""
