"""This module provides the interface to control Agni and Blaze led drivers.

Refer to the [Installation](index.md#Installation) section to install the package and the system's requirements.
Also few examples are provided to cover the most common operating modes.

!!! example "Examples"
    === "Connect"
        ``` python
        from wodevices import Agni, Blaze

        # Connect
        blaze = Blaze()
        agni = Agni()
        # or
        agni = Agni(device_id='0028005F303150102039354D')
        # to connect to a device with a given serial number
        # or
        blazes = [Blaze(device_id=0), Blaze(device_id=1)]
        # to connect to multiple boards
        ```

    === "LED control"
        ``` python
        from wopcprotocol.common import LedCurrent, LedDutyCycle, LedState
        from wodevices import Blaze

        # Connect
        blaze = Blaze()
        # Turn on the LED driver
        blaze.set_led_driver(True)
        # Turn on only the red LED
        blaze.set_led_state(LedState(red=True))
        # Turn on all LEDs
        blaze.set_led_state(LedState.all())
        # Set the currents
        blaze.set_led_current(LedCurrent(red=20.0, green=30.0, blue=40.0, green2=50.0))
        # Set the duty cycles
        blaze.set_led_duty_cycle(LedDutyCycle(red=10, green=20, blue=30, green2=20))
        # Read the vf
        print(blaze.read_led_voltage())
        # Turn off the LED driver
        blaze.set_led_driver(False)
        ```

    === "Temperature control"
        ``` python
        import time
        from wodevices import Blaze
        from wodevices.temperature_ctrl import PidLimits, PidParameters, TemperatureSensorType, ThermistorType

        # Connect
        blaze = Blaze()

        # Disable temperature control
        blaze.temperature_controller.set(False)
        # Set tempererature sensor
        blaze.temperature_controller.set_sensor_type(TemperatureSensorType.THERMISTOR_0)
        blaze.temperature_controller.set_thermistor_type(ThermistorType.THERMISTOR_100k)
        # Set temperature set point
        blaze.temperature_controller.set_temperature_ref(35.0)
        # Set PID parameters and limits
        blaze.temperature_controller.set_pid_parameters(PidParameters(kp=2.0, ki=0.5, kd=0.0))
        blaze.temperature_controller.set_pid_limits(PidLimits(min=-5.0, max=5.0))
        # Enable temperature control
        blaze.temperature_controller.set(True)
        # Wait for the temperature to settle
        while True:
            if blaze.temperature_controller.get_status().temperature_stable:
                break
            time.sleep(1)
        ```
"""

import sys
from dataclasses import dataclass
from enum import IntEnum
from struct import unpack
from typing import Any, ClassVar

if sys.version_info >= (3, 11):
    from typing import Self
else:
    from typing_extensions import Self

import wopcprotocol.brightness as bt
from wopcprotocol.common import LedBrightness, LedCurrent, LedDutyCycle, LedState, LedVoltage, Side
from wopcprotocol.protocol import Commands, Electronics, Hardware, Targets
from wopcprotocol.thermistors import THERMISTORS

from wodevices.common import Device, get_fan, set_fan
from wodevices.temperature_ctrl import TemperatureController, TemperatureSensorType, ThermistorType


def _adc_to_rpull_down(adc: int, adc_max: int, rpull_up: float) -> float:
    return rpull_up * adc / (adc_max - adc)


class LedMode(IntEnum):
    """LED driving mode."""

    CW = 0
    "Continuous wave mode"
    PWM = 1
    "Pulse width modulation mode"


class LedDriver(Device):
    """This class provides the interface to control a generic LED driver."""

    _ELECTRONICS: tuple[Electronics, ...] = (Electronics.AGNI, Electronics.BLAZE)

    _SUPPORTED_TEMPERATURE_SENSORS: tuple[TemperatureSensorType, ...] = TemperatureController.DEFAULT_SUPPORTED_SENSORS

    @dataclass
    class RawAdcReadings:
        """Raw ADC readings.

        Args:
            timestamp: timestamp of the readings
            adc_values: raw ADC values
            vref_cal: vref factory calibration value
            vref_data: vref calibration data value
        """

        timestamp: int
        adc_values: tuple[int, int, int, int, int]
        vref_cal: int
        vref_data: int

        ADC_MAX: ClassVar[int] = 4095

        @classmethod
        def unpack(cls, data: bytes) -> Self:
            """Unpack the raw ADC readings from a bytes stream.

            Args:
                data: the data to unpack
            """
            values = unpack("<IHHHHHHH", data)
            return cls(timestamp=values[0], adc_values=values[1:6], vref_cal=values[6], vref_data=values[7])

        @property
        def vref(self) -> float:
            """Value of vref in Volts."""
            return (3.0 * self.vref_cal) / self.vref_data

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """Initialize the LED driver.

        Args:
            *args: arguments to pass to the parent class
            **kwargs: keyword arguments to pass to the parent class
        """
        super().__init__(*args, **kwargs)
        self.temperature_controller = TemperatureController(self.comms, self._SUPPORTED_TEMPERATURE_SENSORS)

    def set_led_driver(self, enable: bool) -> None:
        """Enable or disable the LED driver.

        Args:
            enable: `True` to enable the LED driver, `False` to disable it
        """
        bt.set_led_driver(Side.LEFT, enable, self.comms)

    def get_led_driver(self) -> bool:
        """Get the state of the LED driver.

        Returns:
            `True` if the LED driver is enabled, `False` otherwise
        """
        return bt.get_led_driver(Side.LEFT, self.comms)

    def set_led_state(self, state: LedState) -> None:
        """Set the state of the invidual LEDs.

        Args:
            state: the state of the LEDs
        """
        bt.set_led_state(Side.LEFT, state, self.comms)

    def get_led_state(self) -> LedState:
        """Get the state of the individual LEDs.

        Returns:
            the state of the LEDs
        """
        return bt.get_led_state(Side.LEFT, self.comms)

    def set_led_brightness(self, brightness: LedBrightness) -> None:
        """Set the brightness of the individual LEDs.

        Args:
            brightness: the brightness value to set
        """
        bt.set_led_brightness(side=Side.LEFT, brightness=brightness, use_nvm=False, comms=self.comms)

    def get_led_brightness(self) -> LedBrightness:
        """Get the brightness of the individual LEDs.

        Returns:
            the brightness of the individual LEDs
        """
        return bt.get_led_brightness(side=Side.LEFT, use_nvm=False, comms=self.comms)

    def set_led_current(self, current: LedCurrent) -> None:
        """Set the current of the individual LEDs.

        Args:
            current: the current value to set
        """
        bt.set_led_current(side=Side.LEFT, current=current, use_nvm=False, comms=self.comms)

    def get_led_current(self) -> LedCurrent:
        """Get the current of the individual LEDs.

        Returns:
            the current value of the individual LEDs
        """
        return bt.get_led_current(side=Side.LEFT, use_nvm=False, comms=self.comms)

    def set_led_duty_cycle(self, duty_cycle: LedDutyCycle) -> None:
        """Set the duty cycle of the individual LEDs.

        Args:
            duty_cycle: the duty cycle value to set
        """
        bt.set_led_duty_cycle(Side.LEFT, duty_cycle, self.comms)

    def get_led_duty_cycle(self) -> LedDutyCycle:
        """Get the duty cycle of the individual LEDs.

        Returns:
            the duty cycle of the individual LEDs
        """
        return bt.get_led_duty_cycle(Side.LEFT, self.comms)

    def set_led_pwm_frequency(self, frequency: int) -> None:
        """Set the PWM frequency of the LED driver.

        Args:
            frequency: the frequency value to set
        """
        bt.set_led_pwm_frequency(Side.LEFT, frequency, self.comms)

    def get_led_pwm_frequency(self) -> int:
        """Get the PWM frequency of the LED driver.

        Returns:
            the frequency value
        """
        return bt.get_led_pwm_frequency(Side.LEFT, self.comms)

    def set_led_mode(self, mode: LedMode) -> None:
        """Set the LED driving mode.

        Args:
            mode: driving mode

        !!! warning
            In Agni, all LEDs can be driven in CW mode simultenously, while Blaze can only drive one LED in
            CW mode at a time.
        """
        self.comms.send(
            command=Commands.SET_HARDWARE_STATE, target=Targets.LEFT, payload=bytes([Hardware.LED_MODE, mode << 1])
        )

    def get_led_mode(self) -> LedMode:
        """Get the LED driving mode.

        Returns:
            driving mode
        """
        response = self.comms.send(
            command=Commands.GET_HARDWARE_STATE, target=Targets.LEFT, payload=bytes([Hardware.LED_MODE])
        )
        return LedMode((response.payload[1] >> 1) & 0x3)

    def run_led_test(self) -> LedState:
        """Run the LED test.

        Returns:
            `LedState` object with the functional status of the LEDs (`True` if the LED is functional,
            `False` otherwise)
        """
        return bt.run_led_test(Side.LEFT, self.comms)

    def set_fan(self, enable: bool) -> None:
        """Enable or disable the internal fan of the device.

        Args:
            enable: `True` to enable the fan, `False` to disable it

        !!! note
            The internal fan is only available in Agni and in Blaze when used together with Hovez. The speed of the fan can be controlled only for Agni, while for Blaze the fan either on or off.
        """
        set_fan(Hardware.FAN_INTERNAL, enable, self.comms)

    def get_fan(self) -> bool:
        """Get the state of the internal fan of the device.

        Returns:
            `True` if the fan is enabled, `False` otherwise
        """
        return get_fan(Hardware.FAN_INTERNAL, self.comms)

    def get_raw_adc_readings(self) -> RawAdcReadings:
        """Return the latest raw ADC readings.

        Returns:
            the raw ADC readings
        """
        response = self.comms.send(command=Commands.GET_ADC_READINGS, target=Targets.MCU)
        return self.RawAdcReadings.unpack(response.payload)


class Agni(LedDriver):
    """This class provides the interface to control the Agni LED driver."""

    _ELECTRONICS: tuple[Electronics, ...] = (Electronics.AGNI,)

    _SUPPORTED_TEMPERATURE_SENSORS = (
        TemperatureSensorType.AUTO,
        TemperatureSensorType.I2C,
        TemperatureSensorType.THERMISTOR_AUTO,
        TemperatureSensorType.THERMISTOR_0,
    )

    class LedDriverFeedback(IntEnum):
        """Feedback value to be used by the LED driver."""

        CURRENT = 0
        """Current feedback"""
        PHOTODIODE_RGB = 1
        """Photodiode RGB feedback"""
        PHOTODIODE_RED = 2
        """Photodiode red feedback"""

    @dataclass
    class AdcReadings(LedDriver.RawAdcReadings):
        """ADC readings for Agni.

        Args:
            led_driver_red_temperature: red LED driver temperature in Celsius
            led_driver_green_temperature: green LED driver temperature in Celsius
            led_driver_blue_temperature: blue LED driver temperature in Celsius
            system_current: system current in mA
        """

        led_driver_red_temperature: float
        led_driver_green_temperature: float
        led_driver_blue_temperature: float
        system_current: float

        @classmethod
        def from_raw_adc_readings(cls, adc_readings: LedDriver.RawAdcReadings) -> Self:
            """Create an `AdcReadings` object from raw ADC readings.

            Args:
                adc_readings: the raw ADC readings
            """
            rpull_up = 10_000
            thermistor = THERMISTORS["ERTJ0EG103FA"]
            voltage_to_current = 0.5
            return cls(
                timestamp=adc_readings.timestamp,
                vref_cal=adc_readings.vref_cal,
                vref_data=adc_readings.vref_data,
                adc_values=adc_readings.adc_values,
                led_driver_red_temperature=thermistor.ohm_to_celsius(
                    _adc_to_rpull_down(adc_readings.adc_values[1], cls.ADC_MAX, rpull_up)
                ),
                led_driver_green_temperature=thermistor.ohm_to_celsius(
                    _adc_to_rpull_down(adc_readings.adc_values[2], cls.ADC_MAX, rpull_up)
                ),
                led_driver_blue_temperature=thermistor.ohm_to_celsius(
                    _adc_to_rpull_down(adc_readings.adc_values[3], cls.ADC_MAX, rpull_up)
                ),
                system_current=(adc_readings.adc_values[4] * adc_readings.vref / adc_readings.ADC_MAX)
                / voltage_to_current
                * 1000,
            )

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """Initialize the Agni LED driver.

        Args:
            *args: arguments to pass to the parent class
            **kwargs: keyword arguments to pass to the parent class
        """
        super().__init__(*args, **kwargs)

    def set_led_driver_feedback(self, feedback: LedDriverFeedback) -> None:
        """Set the feedback of the LED driver.

        Args:
            feedback: the feedback value to set
        """
        payload = bytes([Hardware.LED_FEEDBACK, feedback << 3])
        self.comms.send(command=Commands.SET_HARDWARE_STATE, target=Targets.LEFT, payload=payload)

    def get_led_driver_feedback(self) -> LedDriverFeedback:
        """Get the feedback of the LED driver.

        Returns:
            the feedback value
        """
        response = self.comms.send(
            command=Commands.GET_HARDWARE_STATE, target=Targets.LEFT, payload=bytes([Hardware.LED_FEEDBACK])
        )
        return self.LedDriverFeedback(response.payload[1] >> 3)

    def read_led_current(self) -> LedCurrent:
        """Read the current of the individual LEDs from the on-board current sensor.

        Returns:
            the current value measured by the sensor
        """
        return bt.read_led_current(Side.LEFT, self.comms)

    def read_photodiode(self) -> LedBrightness:
        """Read the photodiode value.

        Returns:
            the photodiode value
        """
        response = self.comms.send(command=Commands.READ_RGB_PHOTODIODE, target=Targets.LEFT)
        values = unpack("<" + "H" * (len(response.payload) // 2), response.payload)
        return LedBrightness(
            red=values[0], green=values[2], blue=values[1], green2=values[3] if len(values) >= 4 else None
        )

    def get_adc_readings(self) -> AdcReadings:
        """Return the latest ADC readings.

        Returns:
            the ADC readings
        """
        return self.AdcReadings.from_raw_adc_readings(self.get_raw_adc_readings())


class Blaze(LedDriver):
    """This class provides the interface to control the Blaze LED driver."""

    _ELECTRONICS: tuple[Electronics, ...] = (Electronics.BLAZE,)

    _SUPPORTED_TEMPERATURE_SENSORS = (
        TemperatureSensorType.AUTO,
        TemperatureSensorType.I2C,
        TemperatureSensorType.THERMISTOR_AUTO,
        TemperatureSensorType.THERMISTOR_0,
        TemperatureSensorType.THERMISTOR_1,
    )

    @dataclass
    class AdcReadings(LedDriver.RawAdcReadings):
        """ADC readings for Blaze.

        Args:
            led_driver_temperature: LED driver temperature in Celsius
            thermistor_0: temperature of thermistor 0 in Celsius or `None` if the reading is invalid
            thermistor_1: temperature of thermistor 1 in Celsius or `None` if the reading is invalid
        """

        led_driver_temperature: float
        thermistor_0: float | None
        thermistor_1: float | None

        @classmethod
        def from_raw_adc_readings(cls, adc_readings: LedDriver.RawAdcReadings, thermistor_type: ThermistorType) -> Self:
            """Create an `AdcReadings` object from raw ADC readings.

            Args:
                adc_readings: the raw ADC readings
                thermistor_type: the type of thermistor used
            """

            def is_valid_adc_temperature(adc: int) -> bool:
                return adc < 4040

            thermistor = THERMISTORS[
                "ERTJ0EG103FA" if thermistor_type == ThermistorType.THERMISTOR_10k else "NTCG064EF104FTBX"
            ]
            rpull_up = 10_000
            return cls(
                timestamp=adc_readings.timestamp,
                vref_cal=adc_readings.vref_cal,
                vref_data=adc_readings.vref_data,
                adc_values=adc_readings.adc_values,
                led_driver_temperature=THERMISTORS["ERTJ0EG103FA"].ohm_to_celsius(
                    _adc_to_rpull_down(adc_readings.adc_values[1], cls.ADC_MAX, rpull_up)
                ),
                thermistor_0=thermistor.ohm_to_celsius(
                    _adc_to_rpull_down(adc_readings.adc_values[2], cls.ADC_MAX, rpull_up)
                )
                if is_valid_adc_temperature(adc_readings.adc_values[2])
                else None,
                thermistor_1=thermistor.ohm_to_celsius(
                    _adc_to_rpull_down(adc_readings.adc_values[3], cls.ADC_MAX, rpull_up)
                )
                if is_valid_adc_temperature(adc_readings.adc_values[3])
                else None,
            )

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """Initialize the Blaze LED driver.

        Args:
            *args: arguments to pass to the parent class
            **kwargs: keyword arguments to pass to the parent class
        """
        super().__init__(*args, **kwargs)

    def set_led_driver_rlim(self, rlim: bt.Rlim) -> None:
        """Set the value of the current limiting resistor of the LED driver.

        Args:
            rlim: value of the current limiting resistor
        """
        bt.set_led_driver_rlim(Side.LEFT, rlim, self.comms)

    def get_led_driver_rlim(self) -> bt.Rlim:
        """Get value of the current limiting resistor of the LED driver.

        Returns:
            the current limiting resistor
        """
        return bt.get_led_driver_rlim(Side.LEFT, self.comms)

    def read_led_voltage(self) -> LedVoltage:
        """Read the forward voltage of the individual LEDs.

        Returns:
            the voltage of the individual LEDs
        """
        return bt.read_led_voltage(Side.LEFT, self.comms)

    def get_adc_readings(self) -> AdcReadings:
        """Return the latest ADC readings.

        Returns:
            the ADC readings
        """
        return self.AdcReadings.from_raw_adc_readings(
            self.get_raw_adc_readings(), self.temperature_controller.get_thermistor_type()
        )
